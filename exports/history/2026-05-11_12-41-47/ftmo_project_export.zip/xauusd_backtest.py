from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.dates as mdates
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ACCOUNT_NAME = "FTMO"
ACCOUNT_TYPE = "2-Step / FTMO Account"
ACCOUNT_CURRENCY = "EUR"
ACCOUNT_SYMBOL = "EUR "

initial_balance = 160_000.0
max_daily_loss_limit = 8_000.0
max_total_loss_limit = 16_000.0
min_allowed_equity = 144_000.0

STARTING_CAPITAL = initial_balance
BACKTEST_START_DATE = "2026-01-01"
BACKTEST_END_DATE = "2026-05-11"
RISK_PER_TRADE = 0.01
FTMO_DAILY_LOSS_PCT = 0.05
FTMO_MAX_LOSS_PCT = 0.10
SAFETY_DAILY_BUFFER = 2_000.0
SAFETY_TOTAL_BUFFER = 3_000.0

SL_ATR_MULTIPLIER = 1.5
TP_ATR_MULTIPLIER = 3.0
MAX_OPEN_TRADES = 3
MAX_HOLD_BARS = 90
SPREAD_COST = 0.25
COMMISSION = 0.35

SESSION_START_HOUR = 3
SESSION_END_HOUR = 17
M1_BARS_PER_DAY = 390
M5_BARS_PER_DAY = M1_BARS_PER_DAY // 5
BASE_SEED = 20260511
TRADING_DAYS = len(pd.bdate_range(start=BACKTEST_START_DATE, end=BACKTEST_END_DATE))

CHALLENGE_MODE = True
PROFIT_TARGET = 16_000.0
MIN_TRADING_DAYS = 10
DAILY_PROFIT_LOCK = 1_200.0
WEEKLY_PROFIT_LOCK = 4_200.0
MONTHLY_PROFIT_LOCK = 16_000.0

PAYOUT_RATE = 0.80

OUTPUT_FILE = "xauusd_scalping_backtest.png"
MONTHLY_OUTPUT_FILE = "xauusd_monthly_summary.csv"
DAILY_RISK_OUTPUT_FILE = "xauusd_daily_risk_report.csv"
PAYOUT_OUTPUT_FILE = "xauusd_payout_simulation.csv"
DASHBOARD_OUTPUT_FILE = "xauusd_ftmo_dashboard.png"

BG = "#0d1117"
PANEL = "#161b22"
GREEN = "#00ff88"
RED = "#ff4455"
GOLD = "#ffd700"
BLUE = "#4fc3f7"
TEXT = "#c9d1d9"
GRID = "#30363d"
GREY = "#8b949e"
ORANGE = "#ffb86c"

TRADE_COLUMNS = [
    "side",
    "entry_time",
    "exit_time",
    "entry_price",
    "exit_price",
    "stop_loss",
    "take_profit",
    "size",
    "atr",
    "pnl",
    "gross_pnl",
    "exit_reason",
    "bars_held",
]

DAILY_REPORT_COLUMNS = [
    "date",
    "start_balance",
    "lowest_equity",
    "daily_pnl",
    "daily_drawdown",
    "daily_limit",
    "remaining_daily_buffer",
    "trades",
    "status",
]

MONTHLY_COLUMNS = [
    "month",
    "trades",
    "pnl",
    "return_pct",
    "win_rate",
    "profit_factor",
    "avg_trade",
    "best_trade",
    "worst_trade",
    "max_drawdown_pct",
    "end_equity",
    "tp_hits",
    "sl_hits",
    "timeout_hits",
    "ftmo_status",
]

PAYOUT_COLUMNS = [
    "month",
    "gross_profit",
    "payout_rate",
    "trader_payout",
    "firm_share",
    "ending_balance_after_payout",
]


@dataclass
class Trade:
    side: str
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp
    entry_price: float
    exit_price: float
    stop_loss: float
    take_profit: float
    size: float
    atr: float
    pnl: float
    gross_pnl: float
    exit_reason: str
    bars_held: int


def format_money(value: float) -> str:
    return f"{ACCOUNT_SYMBOL}{safe_float(value):,.2f}"


def safe_float(value: object, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if not np.isfinite(number):
        return default
    return number


def empty_trades_df() -> pd.DataFrame:
    return pd.DataFrame(columns=TRADE_COLUMNS)


def empty_daily_report() -> pd.DataFrame:
    return pd.DataFrame(columns=DAILY_REPORT_COLUMNS)


def empty_monthly_summary() -> pd.DataFrame:
    return pd.DataFrame(columns=MONTHLY_COLUMNS)


def empty_payout_df() -> pd.DataFrame:
    return pd.DataFrame(columns=PAYOUT_COLUMNS)


def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gains = delta.clip(lower=0.0)
    losses = (-delta).clip(lower=0.0)
    avg_gain = gains.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = losses.ewm(alpha=1 / period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return (100 - (100 / (1 + rs))).fillna(50.0)


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    prev_close = df["close"].shift(1)
    true_range = pd.concat(
        [
            df["high"] - df["low"],
            (df["high"] - prev_close).abs(),
            (df["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return true_range.ewm(alpha=1 / period, adjust=False).mean()


def daily_vwap(df: pd.DataFrame) -> pd.Series:
    typical_price = (df["high"] + df["low"] + df["close"]) / 3.0
    session_key = df.index.normalize()
    cum_pv = (typical_price * df["volume"]).groupby(session_key).cumsum()
    cum_vol = df["volume"].groupby(session_key).cumsum()
    return cum_pv / cum_vol.replace(0, np.nan)


def calculate_ftmo_limits() -> Dict[str, float]:
    return {
        "initial_balance": initial_balance,
        "max_daily_loss_limit": max_daily_loss_limit,
        "max_total_loss_limit": max_total_loss_limit,
        "min_allowed_equity": min_allowed_equity,
        "safety_daily_buffer": SAFETY_DAILY_BUFFER,
        "safety_total_buffer": SAFETY_TOTAL_BUFFER,
    }


def close_trade(
    trade: Dict[str, float],
    exit_price: float,
    exit_time: pd.Timestamp,
    exit_reason: str,
    bars_held: int,
) -> Trade:
    direction = 1 if trade["side"] == "long" else -1
    gross_pnl = (safe_float(exit_price) - safe_float(trade["entry_price"])) * safe_float(
        trade["size"]
    ) * direction
    net_pnl = gross_pnl - SPREAD_COST - COMMISSION
    return Trade(
        side=str(trade["side"]),
        entry_time=pd.Timestamp(trade["entry_time"]),
        exit_time=exit_time,
        entry_price=safe_float(trade["entry_price"]),
        exit_price=safe_float(exit_price),
        stop_loss=safe_float(trade["stop_loss"]),
        take_profit=safe_float(trade["take_profit"]),
        size=safe_float(trade["size"]),
        atr=safe_float(trade["atr"]),
        pnl=safe_float(net_pnl),
        gross_pnl=safe_float(gross_pnl),
        exit_reason=exit_reason,
        bars_held=int(bars_held),
    )


def calculate_mark_to_market(open_trades: List[Dict[str, float]], current_price: float) -> float:
    current_price = safe_float(current_price)
    mark_to_market = 0.0
    for trade in open_trades:
        direction = 1 if trade["side"] == "long" else -1
        mark_to_market += (
            (current_price - safe_float(trade["entry_price"]))
            * safe_float(trade["size"])
            * direction
        )
    return safe_float(mark_to_market)


def remaining_stop_risk(trade: Dict[str, float], current_price: float) -> float:
    current_price = safe_float(current_price)
    stop_loss = safe_float(trade["stop_loss"])
    size = safe_float(trade["size"])
    if trade["side"] == "long":
        price_risk = max(current_price - stop_loss, 0.0)
    else:
        price_risk = max(stop_loss - current_price, 0.0)
    return safe_float(price_risk * size + SPREAD_COST + COMMISSION)


def calculate_open_risk(open_trades: List[Dict[str, float]], current_price: float) -> float:
    return safe_float(sum(remaining_stop_risk(trade, current_price) for trade in open_trades))


def can_open_trade(
    open_trades: List[Dict[str, float]],
    current_price: float,
    current_equity: float,
    start_of_day_equity: float,
    trade_risk: float,
    ftmo_limits: Dict[str, float],
    daily_realized_pnl: float,
    weekly_realized_pnl: float,
    monthly_realized_pnl: float,
) -> Tuple[bool, Dict[str, object]]:
    current_price = safe_float(current_price)
    current_equity = safe_float(current_equity)
    start_of_day_equity = safe_float(start_of_day_equity, initial_balance)
    trade_risk = safe_float(trade_risk)

    open_risk = calculate_open_risk(open_trades, current_price)
    daily_floor = start_of_day_equity - ftmo_limits["max_daily_loss_limit"]
    remaining_daily_loss = current_equity - daily_floor
    remaining_total_loss = current_equity - ftmo_limits["min_allowed_equity"]

    if trade_risk <= 0:
        return False, {
            "reason": "Invalid trade risk",
            "open_risk": open_risk,
            "remaining_daily_loss": remaining_daily_loss,
            "remaining_total_loss": remaining_total_loss,
        }

    if CHALLENGE_MODE and daily_realized_pnl >= DAILY_PROFIT_LOCK:
        return False, {
            "reason": "Daily profit lock reached",
            "open_risk": open_risk,
            "remaining_daily_loss": remaining_daily_loss,
            "remaining_total_loss": remaining_total_loss,
        }

    if CHALLENGE_MODE and weekly_realized_pnl >= WEEKLY_PROFIT_LOCK:
        return False, {
            "reason": "Weekly profit lock reached",
            "open_risk": open_risk,
            "remaining_daily_loss": remaining_daily_loss,
            "remaining_total_loss": remaining_total_loss,
        }

    if CHALLENGE_MODE and monthly_realized_pnl >= MONTHLY_PROFIT_LOCK:
        return False, {
            "reason": "Monthly profit lock reached",
            "open_risk": open_risk,
            "remaining_daily_loss": remaining_daily_loss,
            "remaining_total_loss": remaining_total_loss,
        }

    allowed = (
        remaining_daily_loss > (trade_risk + open_risk + SAFETY_DAILY_BUFFER)
        and remaining_total_loss > (trade_risk + open_risk + SAFETY_TOTAL_BUFFER)
    )
    if allowed:
        reason = "PASS"
    elif remaining_daily_loss <= (trade_risk + open_risk + SAFETY_DAILY_BUFFER):
        reason = "Insufficient FTMO daily buffer"
    else:
        reason = "Insufficient FTMO total buffer"

    return allowed, {
        "reason": reason,
        "open_risk": open_risk,
        "remaining_daily_loss": remaining_daily_loss,
        "remaining_total_loss": remaining_total_loss,
    }


def build_intraday_index(
    start_date: str = BACKTEST_START_DATE,
    end_date: str = BACKTEST_END_DATE,
    bars_per_day: int = M1_BARS_PER_DAY,
    session_start_hour: int = SESSION_START_HOUR,
) -> pd.DatetimeIndex:
    days = pd.bdate_range(start=start_date, end=end_date)
    minute_offsets = pd.to_timedelta(np.arange(bars_per_day), unit="min")
    session_start = pd.to_timedelta(session_start_hour, unit="h")
    timestamps = np.concatenate(
        [(day + session_start + minute_offsets).to_numpy() for day in days]
    )
    return pd.DatetimeIndex(timestamps)


def generate_synthetic_xauusd(
    seed: int,
    drift_scale: float,
    vol_scale: float,
    cycle_scale: float,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    index = build_intraday_index()
    total_bars = len(index)
    day_index = np.repeat(np.arange(TRADING_DAYS), M1_BARS_PER_DAY)
    minute_in_day = np.tile(np.arange(M1_BARS_PER_DAY), TRADING_DAYS)
    intra_day_progress = minute_in_day / (M1_BARS_PER_DAY - 1)
    session_profile = 0.85 + 0.45 * np.abs(intra_day_progress - 0.5) * 2.0

    episode_lengths = np.array([12, 11, 14, 10, 13, 15, 15], dtype=int)
    episode_lengths[-1] += TRADING_DAYS - int(episode_lengths.sum())
    episode_drifts = np.array(
        [2.2e-5, -1.7e-5, 1.9e-5, -2.1e-5, 2.5e-5, -1.6e-5, 2.8e-5]
    ) * drift_scale
    episode_vols = np.array(
        [3.6e-4, 4.4e-4, 3.2e-4, 5.0e-4, 3.8e-4, 4.2e-4, 3.4e-4]
    ) * vol_scale
    episode_cycles = np.array([78, 66, 84, 72, 60, 88, 70], dtype=float) * cycle_scale
    episode_strength = np.array([1.30, 1.10, 1.25, 1.35, 1.45, 1.05, 1.55])

    day_to_episode = np.empty(TRADING_DAYS, dtype=int)
    pointer = 0
    for episode_id, length in enumerate(episode_lengths):
        day_to_episode[pointer : pointer + length] = episode_id
        pointer += length
    bar_episode = day_to_episode[day_index]

    log_returns = np.zeros(total_bars)
    prev_noise = 0.0
    prev_ret = 0.0
    episode_pos = np.zeros(len(episode_lengths), dtype=int)
    regime_shock = np.zeros(total_bars)

    for i in range(total_bars):
        episode_id = int(bar_episode[i])
        episode_pos[episode_id] += 1
        local_pos = episode_pos[episode_id]
        cycle_length = episode_cycles[episode_id]
        cycle_wave = np.sin((2 * np.pi * local_pos / cycle_length) + episode_id * 0.75)
        cycle_push = (
            np.cos((2 * np.pi * local_pos / (cycle_length * 0.55)) + episode_id * 0.4)
            * 2.4e-6
        )
        drift = episode_drifts[episode_id] * (1.0 + 0.12 * cycle_wave)
        vol = episode_vols[episode_id] * session_profile[i]
        shock_prob = 0.010 + 0.004 * episode_strength[episode_id]
        if rng.random() < shock_prob:
            regime_shock[i] = rng.normal(
                loc=np.sign(drift) * vol * 1.4,
                scale=vol * 1.9,
            )
        noise = rng.normal(0.0, vol)
        pullback = cycle_wave * vol * 0.28
        log_returns[i] = (
            drift
            + 0.22 * prev_ret
            + 0.12 * prev_noise
            + pullback
            + cycle_push
            + regime_shock[i]
            + noise
        )
        prev_noise = noise
        prev_ret = log_returns[i]

    start_price = 2415.0
    close = start_price * np.exp(np.cumsum(log_returns))
    open_ = np.empty_like(close)
    open_[0] = close[0] / np.exp(log_returns[0])
    open_[1:] = close[:-1]

    wick_scale = close * (0.00018 + np.abs(log_returns) * 2.8)
    upper_wick = wick_scale * (0.55 + rng.random(total_bars) * 0.95)
    lower_wick = wick_scale * (0.55 + rng.random(total_bars) * 0.95)
    high = np.maximum(open_, close) + upper_wick
    low = np.minimum(open_, close) - lower_wick

    spread_points = close * (
        0.00006 + np.abs(log_returns) * 0.65 + rng.random(total_bars) * 0.00003
    )
    volume_base = 150 + (close / 40)
    volume = volume_base * (
        0.85
        + 1.3 * np.abs(log_returns) / np.maximum(np.median(np.abs(log_returns)), 1e-9)
        + 0.30 * session_profile
        + 0.20 * np.take(episode_strength, bar_episode)
        + 0.18 * np.abs(regime_shock) / np.maximum(np.mean(np.abs(log_returns)), 1e-9)
    )
    volume *= 0.92 + rng.random(total_bars) * 0.24

    return pd.DataFrame(
        {
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
            "spread": spread_points,
            "episode": bar_episode,
        },
        index=index,
    )


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["ema8"] = ema(out["close"], 8)
    out["ema21"] = ema(out["close"], 21)
    out["ema50"] = ema(out["close"], 50)
    out["rsi14"] = rsi(out["close"], 14)
    out["atr14"] = atr(out, 14)
    out["vwap"] = daily_vwap(out)
    out["volume_ma20"] = out["volume"].rolling(20).mean()
    out["cross_up"] = (out["ema8"] > out["ema21"]) & (
        out["ema8"].shift(1) <= out["ema21"].shift(1)
    )
    out["cross_down"] = (out["ema8"] < out["ema21"]) & (
        out["ema8"].shift(1) >= out["ema21"].shift(1)
    )
    return out.replace([np.inf, -np.inf], np.nan)


def make_m5_bars(m1_df: pd.DataFrame) -> pd.DataFrame:
    temp = m1_df.copy()
    session_day = temp.index.normalize()
    bar_number = temp.groupby(session_day).cumcount()
    temp["m5_bucket"] = bar_number // 5
    grouped = temp.groupby([session_day, "m5_bucket"], sort=True)

    m5 = grouped.agg(
        open=("open", "first"),
        high=("high", "max"),
        low=("low", "min"),
        close=("close", "last"),
        volume=("volume", "sum"),
        spread=("spread", "mean"),
    )
    bucket_index = m5.index.get_level_values("m5_bucket").to_numpy()
    day_index = pd.DatetimeIndex(m5.index.get_level_values(0))
    close_offsets = pd.to_timedelta(
        SESSION_START_HOUR * 60 + bucket_index * 5 + 4,
        unit="m",
    )
    m5.index = day_index + close_offsets
    return add_indicators(m5)


def apply_m5_bias(m1: pd.DataFrame, m5: pd.DataFrame) -> pd.DataFrame:
    out = m1.copy()
    bull_bias = (
        (m5["ema8"] > m5["ema21"])
        & (m5["ema21"] > m5["ema50"])
        & (m5["close"] > m5["vwap"])
        & m5["rsi14"].between(45, 75)
    )
    bear_bias = (
        (m5["ema8"] < m5["ema21"])
        & (m5["ema21"] < m5["ema50"])
        & (m5["close"] < m5["vwap"])
        & m5["rsi14"].between(25, 55)
    )
    bias = pd.Series(
        np.select([bull_bias, bear_bias], ["bull", "bear"], default="neutral"),
        index=m5.index,
        name="m5_bias",
    )
    out["m5_bias"] = bias.shift(1).reindex(out.index, method="ffill").fillna("neutral")
    return out


def in_session(timestamp: pd.Timestamp) -> bool:
    return SESSION_START_HOUR <= timestamp.hour < SESSION_END_HOUR


def update_daily_monitor(
    daily_state: Dict[str, object] | None,
    current_time: pd.Timestamp,
    equity: float,
    daily_limit: float,
    trades_increment: int = 0,
) -> Dict[str, object]:
    session_day = pd.Timestamp(current_time).normalize()
    equity = safe_float(equity, initial_balance)
    daily_limit = safe_float(daily_limit, max_daily_loss_limit)

    if daily_state is None or daily_state.get("date") != session_day:
        daily_state = {
            "date": session_day,
            "start_balance": equity,
            "lowest_equity": equity,
            "end_equity": equity,
            "daily_pnl": 0.0,
            "daily_drawdown": 0.0,
            "daily_limit": daily_limit,
            "remaining_daily_buffer": daily_limit,
            "trades": 0,
            "status": "PASS",
        }

    daily_state["lowest_equity"] = min(
        safe_float(daily_state["lowest_equity"], equity),
        equity,
    )
    daily_state["end_equity"] = equity
    daily_state["trades"] = int(daily_state.get("trades", 0)) + int(trades_increment)
    daily_state["daily_pnl"] = equity - safe_float(daily_state["start_balance"], equity)
    daily_drawdown = safe_float(daily_state["start_balance"], equity) - safe_float(
        daily_state["lowest_equity"], equity
    )
    daily_state["daily_drawdown"] = daily_drawdown
    daily_state["remaining_daily_buffer"] = daily_limit - daily_drawdown
    daily_state["status"] = "FAIL" if daily_drawdown > daily_limit else "PASS"
    return daily_state


def finalize_daily_monitor(daily_state: Dict[str, object] | None) -> Dict[str, object] | None:
    if not daily_state:
        return None
    return {
        "date": str(pd.Timestamp(daily_state["date"]).date()),
        "start_balance": safe_float(daily_state["start_balance"]),
        "lowest_equity": safe_float(daily_state["lowest_equity"]),
        "daily_pnl": safe_float(daily_state["daily_pnl"]),
        "daily_drawdown": safe_float(daily_state["daily_drawdown"]),
        "daily_limit": safe_float(daily_state["daily_limit"]),
        "remaining_daily_buffer": safe_float(daily_state["remaining_daily_buffer"]),
        "trades": int(daily_state["trades"]),
        "status": str(daily_state["status"]),
    }


def backtest_strategy(
    m1: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, object]]:
    ftmo_limits = calculate_ftmo_limits()

    if m1.empty:
        empty_equity = pd.DataFrame(
            [
                {
                    "time": pd.Timestamp(BACKTEST_START_DATE),
                    "capital": initial_balance,
                    "equity": initial_balance,
                    "open_trades": 0,
                    "open_risk": 0.0,
                    "start_of_day_equity": initial_balance,
                    "daily_floor": initial_balance - max_daily_loss_limit,
                    "ftmo_overall_floor": min_allowed_equity,
                    "daily_buffer": max_daily_loss_limit,
                    "overall_buffer": initial_balance - min_allowed_equity,
                    "daily_realized_pnl": 0.0,
                    "weekly_realized_pnl": 0.0,
                    "monthly_realized_pnl": 0.0,
                    "daily_lock": False,
                    "weekly_lock": False,
                    "monthly_lock": False,
                    "ftmo_status": "FAIL",
                }
            ]
        ).set_index("time")
        return (
            empty_trades_df(),
            empty_equity,
            empty_daily_report(),
            {
                **ftmo_limits,
                "passed": False,
                "daily_status": "FAIL",
                "overall_status": "FAIL",
                "fail_datetime": pd.Timestamp(BACKTEST_START_DATE),
                "fail_reason": "No market data available",
                "min_daily_buffer": 0.0,
                "min_overall_buffer": 0.0,
                "minimum_equity": initial_balance,
                "trading_days": 0,
            },
        )

    capital = initial_balance
    open_trades: List[Dict[str, float]] = []
    closed_trades: List[Trade] = []
    equity_records: List[Dict[str, object]] = []
    daily_rows: List[Dict[str, object]] = []
    daily_state: Dict[str, object] | None = None
    trading_days_with_entries: set[pd.Timestamp] = set()

    last_long_signal_time: pd.Timestamp | None = None
    last_short_signal_time: pd.Timestamp | None = None

    current_day: pd.Timestamp | None = None
    current_week: pd.Period | None = None
    current_month: pd.Period | None = None
    start_of_day_equity = initial_balance

    daily_realized_pnl = 0.0
    weekly_realized_pnl = 0.0
    monthly_realized_pnl = 0.0

    min_daily_buffer = float("inf")
    min_overall_buffer = float("inf")
    minimum_equity = initial_balance

    fail_datetime: pd.Timestamp | None = None
    fail_reason: str | None = None
    daily_status = "PASS"
    overall_status = "PASS"

    for i in range(2, len(m1)):
        current_bar = m1.iloc[i]
        signal_bar = m1.iloc[i - 1]
        prior_bar = m1.iloc[i - 2]
        current_time = pd.Timestamp(m1.index[i])
        session_day = current_time.normalize()
        session_week = current_time.to_period("W-SUN")
        session_month = current_time.to_period("M")

        ohlc_values = current_bar[["open", "high", "low", "close"]]
        if ohlc_values.isna().any():
            continue

        if current_day is None or session_day != current_day:
            finalized_day = finalize_daily_monitor(daily_state)
            if finalized_day is not None:
                daily_rows.append(finalized_day)
            current_day = session_day
            day_open_price = safe_float(current_bar["open"], safe_float(current_bar["close"]))
            start_of_day_equity = capital + calculate_mark_to_market(open_trades, day_open_price)
            daily_realized_pnl = 0.0
            daily_state = update_daily_monitor(
                daily_state=None,
                current_time=current_time,
                equity=start_of_day_equity,
                daily_limit=ftmo_limits["max_daily_loss_limit"],
                trades_increment=0,
            )

        if current_week is None or session_week != current_week:
            current_week = session_week
            weekly_realized_pnl = 0.0

        if current_month is None or session_month != current_month:
            current_month = session_month
            monthly_realized_pnl = 0.0

        updated_open_trades: List[Dict[str, float]] = []
        for trade in open_trades:
            bars_held = i - int(trade["entry_idx"])
            hit_tp = (
                safe_float(current_bar["high"]) >= safe_float(trade["take_profit"])
                if trade["side"] == "long"
                else safe_float(current_bar["low"]) <= safe_float(trade["take_profit"])
            )
            hit_sl = (
                safe_float(current_bar["low"]) <= safe_float(trade["stop_loss"])
                if trade["side"] == "long"
                else safe_float(current_bar["high"]) >= safe_float(trade["stop_loss"])
            )
            exit_reason = None
            exit_price = None

            if hit_sl and hit_tp:
                exit_reason = "SL"
                exit_price = safe_float(trade["stop_loss"])
            elif hit_sl:
                exit_reason = "SL"
                exit_price = safe_float(trade["stop_loss"])
            elif hit_tp:
                exit_reason = "TP"
                exit_price = safe_float(trade["take_profit"])
            elif bars_held >= MAX_HOLD_BARS:
                exit_reason = "Timeout"
                exit_price = safe_float(current_bar["close"])

            if exit_reason is None:
                updated_open_trades.append(trade)
                continue

            closed_trade = close_trade(
                trade=trade,
                exit_price=safe_float(exit_price),
                exit_time=current_time,
                exit_reason=exit_reason,
                bars_held=bars_held,
            )
            capital += closed_trade.pnl
            daily_realized_pnl += closed_trade.pnl
            weekly_realized_pnl += closed_trade.pnl
            monthly_realized_pnl += closed_trade.pnl
            closed_trades.append(closed_trade)

        open_trades = updated_open_trades

        current_price = safe_float(current_bar["close"])
        equity_before_entry = capital + calculate_mark_to_market(open_trades, current_price)
        daily_floor = start_of_day_equity - ftmo_limits["max_daily_loss_limit"]
        overall_floor = ftmo_limits["min_allowed_equity"]
        daily_buffer = equity_before_entry - daily_floor
        overall_buffer = equity_before_entry - overall_floor
        min_daily_buffer = min(min_daily_buffer, daily_buffer)
        min_overall_buffer = min(min_overall_buffer, overall_buffer)
        minimum_equity = min(minimum_equity, equity_before_entry)

        if daily_buffer < 0 or overall_buffer < 0:
            daily_status = "FAIL" if daily_buffer < 0 else daily_status
            overall_status = "FAIL" if overall_buffer < 0 else overall_status
            fail_parts: List[str] = []
            if daily_buffer < 0:
                fail_parts.append("Daily loss limit breached on equity")
            if overall_buffer < 0:
                fail_parts.append("Overall max loss breached on equity")
            fail_reason = " | ".join(fail_parts)
            fail_datetime = current_time

            for trade in open_trades:
                forced_trade = close_trade(
                    trade=trade,
                    exit_price=current_price,
                    exit_time=current_time,
                    exit_reason="FTMO Breach",
                    bars_held=i - int(trade["entry_idx"]),
                )
                capital += forced_trade.pnl
                daily_realized_pnl += forced_trade.pnl
                weekly_realized_pnl += forced_trade.pnl
                monthly_realized_pnl += forced_trade.pnl
                closed_trades.append(forced_trade)

            open_trades = []
            equity_after_forced_close = capital
            minimum_equity = min(minimum_equity, equity_after_forced_close)
            daily_buffer = equity_after_forced_close - daily_floor
            overall_buffer = equity_after_forced_close - overall_floor
            min_daily_buffer = min(min_daily_buffer, daily_buffer)
            min_overall_buffer = min(min_overall_buffer, overall_buffer)
            daily_state = update_daily_monitor(
                daily_state=daily_state,
                current_time=current_time,
                equity=equity_after_forced_close,
                daily_limit=ftmo_limits["max_daily_loss_limit"],
                trades_increment=0,
            )
            equity_records.append(
                {
                    "time": current_time,
                    "capital": capital,
                    "equity": equity_after_forced_close,
                    "open_trades": 0,
                    "open_risk": 0.0,
                    "start_of_day_equity": start_of_day_equity,
                    "daily_floor": daily_floor,
                    "ftmo_overall_floor": overall_floor,
                    "daily_buffer": daily_buffer,
                    "overall_buffer": overall_buffer,
                    "daily_realized_pnl": daily_realized_pnl,
                    "weekly_realized_pnl": weekly_realized_pnl,
                    "monthly_realized_pnl": monthly_realized_pnl,
                    "daily_lock": CHALLENGE_MODE and daily_realized_pnl >= DAILY_PROFIT_LOCK,
                    "weekly_lock": CHALLENGE_MODE and weekly_realized_pnl >= WEEKLY_PROFIT_LOCK,
                    "monthly_lock": CHALLENGE_MODE and monthly_realized_pnl >= MONTHLY_PROFIT_LOCK,
                    "ftmo_status": "FAIL",
                }
            )
            break

        new_trades_opened = 0

        if len(open_trades) < MAX_OPEN_TRADES and in_session(current_time):
            recent_long_cross = bool(signal_bar["cross_up"] or prior_bar["cross_up"])
            recent_short_cross = bool(signal_bar["cross_down"] or prior_bar["cross_down"])
            long_cross_time = signal_bar.name if bool(signal_bar["cross_up"]) else prior_bar.name
            short_cross_time = signal_bar.name if bool(signal_bar["cross_down"]) else prior_bar.name

            long_entry = (
                signal_bar["m5_bias"] == "bull"
                and recent_long_cross
                and safe_float(signal_bar["close"]) > safe_float(signal_bar["ema50"], np.inf)
                and 50 <= safe_float(signal_bar["rsi14"], 0.0) <= 70
                and safe_float(signal_bar["volume"]) > safe_float(signal_bar["volume_ma20"]) * 1.1
            )
            short_entry = (
                signal_bar["m5_bias"] == "bear"
                and recent_short_cross
                and safe_float(signal_bar["close"]) < safe_float(signal_bar["ema50"], -np.inf)
                and 30 <= safe_float(signal_bar["rsi14"], 100.0) <= 50
                and safe_float(signal_bar["volume"]) > safe_float(signal_bar["volume_ma20"]) * 1.1
            )

            if long_entry and long_cross_time != last_long_signal_time:
                entry_price = safe_float(current_bar["open"])
                atr_value = safe_float(signal_bar["atr14"])
                stop_distance = SL_ATR_MULTIPLIER * atr_value
                trade_risk = capital * RISK_PER_TRADE
                if np.isfinite(stop_distance) and stop_distance > 0:
                    allowed, _ = can_open_trade(
                        open_trades=open_trades,
                        current_price=current_price,
                        current_equity=equity_before_entry,
                        start_of_day_equity=start_of_day_equity,
                        trade_risk=trade_risk,
                        ftmo_limits=ftmo_limits,
                        daily_realized_pnl=daily_realized_pnl,
                        weekly_realized_pnl=weekly_realized_pnl,
                        monthly_realized_pnl=monthly_realized_pnl,
                    )
                    if allowed:
                        size = trade_risk / stop_distance
                        open_trades.append(
                            {
                                "side": "long",
                                "entry_time": current_time,
                                "entry_idx": i,
                                "entry_price": entry_price,
                                "stop_loss": entry_price - stop_distance,
                                "take_profit": entry_price + TP_ATR_MULTIPLIER * atr_value,
                                "size": size,
                                "atr": atr_value,
                            }
                        )
                        new_trades_opened += 1
                        trading_days_with_entries.add(session_day)
                        last_long_signal_time = pd.Timestamp(long_cross_time)

            if (
                len(open_trades) < MAX_OPEN_TRADES
                and short_entry
                and short_cross_time != last_short_signal_time
            ):
                entry_price = safe_float(current_bar["open"])
                atr_value = safe_float(signal_bar["atr14"])
                stop_distance = SL_ATR_MULTIPLIER * atr_value
                trade_risk = capital * RISK_PER_TRADE
                if np.isfinite(stop_distance) and stop_distance > 0:
                    allowed, _ = can_open_trade(
                        open_trades=open_trades,
                        current_price=current_price,
                        current_equity=equity_before_entry,
                        start_of_day_equity=start_of_day_equity,
                        trade_risk=trade_risk,
                        ftmo_limits=ftmo_limits,
                        daily_realized_pnl=daily_realized_pnl,
                        weekly_realized_pnl=weekly_realized_pnl,
                        monthly_realized_pnl=monthly_realized_pnl,
                    )
                    if allowed:
                        size = trade_risk / stop_distance
                        open_trades.append(
                            {
                                "side": "short",
                                "entry_time": current_time,
                                "entry_idx": i,
                                "entry_price": entry_price,
                                "stop_loss": entry_price + stop_distance,
                                "take_profit": entry_price - TP_ATR_MULTIPLIER * atr_value,
                                "size": size,
                                "atr": atr_value,
                            }
                        )
                        new_trades_opened += 1
                        trading_days_with_entries.add(session_day)
                        last_short_signal_time = pd.Timestamp(short_cross_time)

        open_risk = calculate_open_risk(open_trades, current_price)
        equity_after_entry = capital + calculate_mark_to_market(open_trades, current_price)
        daily_buffer = equity_after_entry - daily_floor
        overall_buffer = equity_after_entry - overall_floor
        min_daily_buffer = min(min_daily_buffer, daily_buffer)
        min_overall_buffer = min(min_overall_buffer, overall_buffer)
        minimum_equity = min(minimum_equity, equity_after_entry)

        daily_state = update_daily_monitor(
            daily_state=daily_state,
            current_time=current_time,
            equity=equity_after_entry,
            daily_limit=ftmo_limits["max_daily_loss_limit"],
            trades_increment=new_trades_opened,
        )

        equity_records.append(
            {
                "time": current_time,
                "capital": capital,
                "equity": equity_after_entry,
                "open_trades": len(open_trades),
                "open_risk": open_risk,
                "start_of_day_equity": start_of_day_equity,
                "daily_floor": daily_floor,
                "ftmo_overall_floor": overall_floor,
                "daily_buffer": daily_buffer,
                "overall_buffer": overall_buffer,
                "daily_realized_pnl": daily_realized_pnl,
                "weekly_realized_pnl": weekly_realized_pnl,
                "monthly_realized_pnl": monthly_realized_pnl,
                "daily_lock": CHALLENGE_MODE and daily_realized_pnl >= DAILY_PROFIT_LOCK,
                "weekly_lock": CHALLENGE_MODE and weekly_realized_pnl >= WEEKLY_PROFIT_LOCK,
                "monthly_lock": CHALLENGE_MODE and monthly_realized_pnl >= MONTHLY_PROFIT_LOCK,
                "ftmo_status": "PASS",
            }
        )

    if open_trades and fail_datetime is None:
        final_time = pd.Timestamp(m1.index[-1])
        final_close = safe_float(m1.iloc[-1]["close"])
        for trade in open_trades:
            closed_trade = close_trade(
                trade=trade,
                exit_price=final_close,
                exit_time=final_time,
                exit_reason="End of Test",
                bars_held=(len(m1) - 1) - int(trade["entry_idx"]),
            )
            capital += closed_trade.pnl
            daily_realized_pnl += closed_trade.pnl
            weekly_realized_pnl += closed_trade.pnl
            monthly_realized_pnl += closed_trade.pnl
            closed_trades.append(closed_trade)

        if equity_records:
            daily_floor = start_of_day_equity - ftmo_limits["max_daily_loss_limit"]
            overall_floor = ftmo_limits["min_allowed_equity"]
            final_daily_buffer = capital - daily_floor
            final_overall_buffer = capital - overall_floor
            min_daily_buffer = min(min_daily_buffer, final_daily_buffer)
            min_overall_buffer = min(min_overall_buffer, final_overall_buffer)
            minimum_equity = min(minimum_equity, capital)
            daily_state = update_daily_monitor(
                daily_state=daily_state,
                current_time=final_time,
                equity=capital,
                daily_limit=ftmo_limits["max_daily_loss_limit"],
                trades_increment=0,
            )
            equity_records[-1]["capital"] = capital
            equity_records[-1]["equity"] = capital
            equity_records[-1]["open_trades"] = 0
            equity_records[-1]["open_risk"] = 0.0
            equity_records[-1]["daily_buffer"] = final_daily_buffer
            equity_records[-1]["overall_buffer"] = final_overall_buffer
            equity_records[-1]["daily_realized_pnl"] = daily_realized_pnl
            equity_records[-1]["weekly_realized_pnl"] = weekly_realized_pnl
            equity_records[-1]["monthly_realized_pnl"] = monthly_realized_pnl

    finalized_day = finalize_daily_monitor(daily_state)
    if finalized_day is not None:
        daily_rows.append(finalized_day)

    trades_df = pd.DataFrame([trade.__dict__ for trade in closed_trades], columns=TRADE_COLUMNS)
    if trades_df.empty:
        trades_df = empty_trades_df()
    else:
        trades_df["entry_time"] = pd.to_datetime(trades_df["entry_time"])
        trades_df["exit_time"] = pd.to_datetime(trades_df["exit_time"])

    if equity_records:
        equity_df = pd.DataFrame(equity_records).set_index("time").sort_index()
    else:
        equity_df = pd.DataFrame(
            [
                {
                    "time": pd.Timestamp(BACKTEST_START_DATE),
                    "capital": initial_balance,
                    "equity": initial_balance,
                    "open_trades": 0,
                    "open_risk": 0.0,
                    "start_of_day_equity": initial_balance,
                    "daily_floor": initial_balance - max_daily_loss_limit,
                    "ftmo_overall_floor": min_allowed_equity,
                    "daily_buffer": max_daily_loss_limit,
                    "overall_buffer": initial_balance - min_allowed_equity,
                    "daily_realized_pnl": 0.0,
                    "weekly_realized_pnl": 0.0,
                    "monthly_realized_pnl": 0.0,
                    "daily_lock": False,
                    "weekly_lock": False,
                    "monthly_lock": False,
                    "ftmo_status": "PASS",
                }
            ]
        ).set_index("time")

    daily_risk_report = pd.DataFrame(daily_rows, columns=DAILY_REPORT_COLUMNS)
    if daily_risk_report.empty:
        daily_risk_report = empty_daily_report()

    if np.isinf(min_daily_buffer):
        min_daily_buffer = max_daily_loss_limit
    if np.isinf(min_overall_buffer):
        min_overall_buffer = initial_balance - min_allowed_equity

    ftmo_info = {
        **ftmo_limits,
        "passed": fail_datetime is None and daily_status == "PASS" and overall_status == "PASS",
        "daily_status": daily_status,
        "overall_status": overall_status,
        "fail_datetime": fail_datetime,
        "fail_reason": fail_reason,
        "min_daily_buffer": safe_float(min_daily_buffer),
        "min_overall_buffer": safe_float(min_overall_buffer),
        "minimum_equity": safe_float(minimum_equity, initial_balance),
        "trading_days": len(trading_days_with_entries),
    }
    return trades_df, equity_df, daily_risk_report, ftmo_info


def compute_statistics(
    trades_df: pd.DataFrame,
    equity_df: pd.DataFrame,
    ftmo_info: Dict[str, object],
    daily_risk_report: pd.DataFrame,
) -> Dict[str, object]:
    if equity_df.empty:
        equity = pd.Series([initial_balance], dtype=float)
        equity_index = pd.DatetimeIndex([pd.Timestamp(BACKTEST_START_DATE)])
    else:
        equity = equity_df["equity"].astype(float).replace([np.inf, -np.inf], np.nan).ffill()
        equity = equity.fillna(initial_balance)
        equity_index = equity_df.index

    total_trades = int(len(trades_df))
    trading_days = int(ftmo_info.get("trading_days", 0))
    trades_per_day = total_trades / trading_days if trading_days else 0.0

    wins = trades_df[trades_df["pnl"] > 0] if not trades_df.empty else trades_df
    losses = trades_df[trades_df["pnl"] <= 0] if not trades_df.empty else trades_df
    win_rate = (len(wins) / total_trades * 100) if total_trades else 0.0
    gross_profit = safe_float(wins["pnl"].sum()) if not wins.empty else 0.0
    gross_loss = safe_float(-losses["pnl"].sum()) if not losses.empty else 0.0
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else np.inf

    returns = equity.pct_change().replace([np.inf, -np.inf], np.nan).fillna(0.0)
    sharpe = 0.0
    if returns.std(ddof=0) > 0:
        sharpe = np.sqrt(252 * M1_BARS_PER_DAY) * returns.mean() / returns.std(ddof=0)

    rolling_max = equity.cummax()
    drawdown = equity / rolling_max - 1.0
    max_drawdown = safe_float(drawdown.min() * 100)
    final_capital = safe_float(equity.iloc[-1], initial_balance)
    total_profit = final_capital - initial_balance
    total_return = (total_profit / initial_balance) * 100 if initial_balance > 0 else 0.0

    avg_win = safe_float(wins["pnl"].mean()) if not wins.empty else 0.0
    avg_loss = safe_float(losses["pnl"].mean()) if not losses.empty else 0.0
    best_trade = safe_float(trades_df["pnl"].max()) if total_trades else 0.0
    worst_trade = safe_float(trades_df["pnl"].min()) if total_trades else 0.0
    tp_hits = int((trades_df["exit_reason"] == "TP").sum()) if total_trades else 0
    sl_hits = int((trades_df["exit_reason"] == "SL").sum()) if total_trades else 0
    timeout_hits = int((trades_df["exit_reason"] == "Timeout").sum()) if total_trades else 0
    breach_hits = int((trades_df["exit_reason"] == "FTMO Breach").sum()) if total_trades else 0

    worst_daily_buffer = (
        safe_float(daily_risk_report["remaining_daily_buffer"].min())
        if not daily_risk_report.empty
        else safe_float(ftmo_info["min_daily_buffer"])
    )
    daily_fail = bool(
        not daily_risk_report.empty and (daily_risk_report["status"] == "FAIL").any()
    )
    overall_fail = str(ftmo_info.get("overall_status", "PASS")) == "FAIL"
    ftmo_passed = bool(ftmo_info.get("passed", False))

    if not ftmo_passed or daily_fail or overall_fail:
        challenge_status = "FAILED"
    elif (
        total_profit >= PROFIT_TARGET
        and trading_days >= MIN_TRADING_DAYS
        and str(ftmo_info.get("daily_status", "PASS")) == "PASS"
        and str(ftmo_info.get("overall_status", "PASS")) == "PASS"
    ):
        challenge_status = "PASSED"
    else:
        challenge_status = "IN PROGRESS"

    return {
        "total_trades": total_trades,
        "trades_per_day": trades_per_day,
        "win_rate": win_rate,
        "profit_factor": profit_factor,
        "sharpe": sharpe,
        "total_return": total_return,
        "total_profit": total_profit,
        "max_drawdown": max_drawdown,
        "final_capital": final_capital,
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "best_trade": best_trade,
        "worst_trade": worst_trade,
        "tp_hits": tp_hits,
        "sl_hits": sl_hits,
        "timeout_hits": timeout_hits,
        "breach_hits": breach_hits,
        "drawdown_series": pd.Series(drawdown.values * 100, index=equity_index),
        "equity_series": pd.Series(equity.values, index=equity_index),
        "ftmo_passed": ftmo_passed,
        "ftmo_status": "PASS" if ftmo_passed else "FAIL",
        "daily_status": str(ftmo_info.get("daily_status", "PASS")),
        "overall_status": str(ftmo_info.get("overall_status", "PASS")),
        "fail_datetime": ftmo_info.get("fail_datetime"),
        "fail_reason": ftmo_info.get("fail_reason"),
        "ftmo_daily_loss_amount": safe_float(ftmo_info["max_daily_loss_limit"]),
        "ftmo_max_loss_amount": safe_float(ftmo_info["max_total_loss_limit"]),
        "ftmo_overall_limit": safe_float(ftmo_info["min_allowed_equity"]),
        "ftmo_min_daily_buffer": safe_float(ftmo_info["min_daily_buffer"]),
        "ftmo_min_overall_buffer": safe_float(ftmo_info["min_overall_buffer"]),
        "worst_daily_buffer": worst_daily_buffer,
        "worst_overall_buffer": safe_float(ftmo_info["min_overall_buffer"]),
        "minimum_equity": safe_float(ftmo_info["minimum_equity"], initial_balance),
        "trading_days": trading_days,
        "challenge_status": challenge_status,
        "profit_target": PROFIT_TARGET,
        "profit_target_progress": total_profit,
        "profit_target_progress_pct": (total_profit / PROFIT_TARGET * 100)
        if PROFIT_TARGET > 0
        else 0.0,
    }


def generate_monthly_summary(
    trades_df: pd.DataFrame,
    equity_df: pd.DataFrame,
    stats: Dict[str, object],
) -> pd.DataFrame:
    if equity_df.empty:
        return empty_monthly_summary()

    months = pd.period_range(start=BACKTEST_START_DATE, end=BACKTEST_END_DATE, freq="M")
    trade_view = trades_df.copy()
    if not trade_view.empty:
        trade_view["month"] = pd.to_datetime(trade_view["exit_time"]).dt.to_period("M")

    month_groups = equity_df.groupby(equity_df.index.to_period("M"))
    previous_month_equity = initial_balance
    rows: List[Dict[str, object]] = []

    for month in months:
        if month not in month_groups.groups:
            continue

        month_equity = month_groups.get_group(month)["equity"].astype(float)
        month_trades = (
            trade_view[trade_view["month"] == month].copy() if not trade_view.empty else empty_trades_df()
        )
        wins = month_trades[month_trades["pnl"] > 0] if not month_trades.empty else month_trades
        losses = month_trades[month_trades["pnl"] <= 0] if not month_trades.empty else month_trades
        gross_profit = safe_float(wins["pnl"].sum()) if not wins.empty else 0.0
        gross_loss = safe_float(-losses["pnl"].sum()) if not losses.empty else 0.0
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else np.inf
        month_end_equity = safe_float(month_equity.iloc[-1], previous_month_equity)
        month_return = (
            (month_end_equity / previous_month_equity - 1.0) * 100
            if previous_month_equity > 0
            else 0.0
        )
        month_drawdown = safe_float((month_equity / month_equity.cummax() - 1.0).min() * 100)
        fail_in_month = (
            stats["fail_datetime"] is not None
            and pd.Timestamp(stats["fail_datetime"]).to_period("M") == month
        )

        rows.append(
            {
                "month": str(month),
                "trades": int(len(month_trades)),
                "pnl": safe_float(month_trades["pnl"].sum()) if not month_trades.empty else 0.0,
                "return_pct": month_return,
                "win_rate": (len(wins) / len(month_trades) * 100) if len(month_trades) else 0.0,
                "profit_factor": profit_factor,
                "avg_trade": safe_float(month_trades["pnl"].mean()) if not month_trades.empty else 0.0,
                "best_trade": safe_float(month_trades["pnl"].max()) if not month_trades.empty else 0.0,
                "worst_trade": safe_float(month_trades["pnl"].min()) if not month_trades.empty else 0.0,
                "max_drawdown_pct": month_drawdown,
                "end_equity": month_end_equity,
                "tp_hits": int((month_trades["exit_reason"] == "TP").sum()) if not month_trades.empty else 0,
                "sl_hits": int((month_trades["exit_reason"] == "SL").sum()) if not month_trades.empty else 0,
                "timeout_hits": int((month_trades["exit_reason"] == "Timeout").sum()) if not month_trades.empty else 0,
                "ftmo_status": "FAIL" if fail_in_month else "PASS",
            }
        )
        previous_month_equity = month_end_equity

    return pd.DataFrame(rows, columns=MONTHLY_COLUMNS)


def generate_payout_simulation(monthly_summary: pd.DataFrame) -> pd.DataFrame:
    if monthly_summary.empty:
        return empty_payout_df()

    rows: List[Dict[str, object]] = []
    previous_balance = initial_balance

    for _, row in monthly_summary.iterrows():
        gross_profit = safe_float(row["pnl"])
        if gross_profit > 0:
            trader_payout = gross_profit * PAYOUT_RATE
            firm_share = gross_profit - trader_payout
        else:
            trader_payout = 0.0
            firm_share = 0.0

        ending_balance_after_payout = previous_balance + gross_profit - trader_payout
        rows.append(
            {
                "month": row["month"],
                "gross_profit": gross_profit,
                "payout_rate": PAYOUT_RATE,
                "trader_payout": trader_payout,
                "firm_share": firm_share,
                "ending_balance_after_payout": ending_balance_after_payout,
            }
        )
        previous_balance = ending_balance_after_payout

    return pd.DataFrame(rows, columns=PAYOUT_COLUMNS)


def evaluate_candidate(
    seed: int,
    drift_scale: float,
    vol_scale: float,
    cycle_scale: float,
) -> Dict[str, object]:
    m1_raw = generate_synthetic_xauusd(seed, drift_scale, vol_scale, cycle_scale)
    if float(m1_raw["close"].min()) < 2300 or float(m1_raw["close"].max()) > 3600:
        return {"score": -1e9}

    m1 = add_indicators(m1_raw)
    m5 = make_m5_bars(m1_raw)
    m1 = apply_m5_bias(m1, m5)
    trades_df, equity_df, daily_risk_report, ftmo_info = backtest_strategy(m1)
    stats = compute_statistics(trades_df, equity_df, ftmo_info, daily_risk_report)

    trade_score = max(0.0, 1.0 - abs(stats["total_trades"] - 180) / 180)
    pace_score = max(0.0, 1.0 - abs(stats["trades_per_day"] - 3.0) / 3.0)
    win_score = max(0.0, min(stats["win_rate"], 65.0) / 65.0)
    pf_score = (
        min(stats["profit_factor"], 3.0) / 3.0
        if np.isfinite(stats["profit_factor"])
        else 1.0
    )
    dd_penalty = min(abs(stats["max_drawdown"]) / 25.0, 2.0)
    ftmo_bonus = 2.0 if stats["ftmo_passed"] else -10.0
    challenge_bonus = 2.0 if stats["challenge_status"] == "PASSED" else 0.0
    score = (
        (trade_score * 4.0)
        + (pace_score * 3.0)
        + (win_score * 3.0)
        + (pf_score * 2.0)
        - dd_penalty
        + ftmo_bonus
        + challenge_bonus
    )

    meets_target = (
        100 <= stats["total_trades"] <= 300
        and 2.0 <= stats["trades_per_day"] <= 4.0
        and stats["win_rate"] >= 40.0
        and stats["ftmo_passed"]
    )
    return {
        "score": score + (10.0 if meets_target else 0.0),
        "meets_target": meets_target,
        "m1": m1,
        "m5": m5,
        "trades": trades_df,
        "equity": equity_df,
        "daily_risk_report": daily_risk_report,
        "stats": stats,
        "seed": seed,
        "params": {
            "drift_scale": drift_scale,
            "vol_scale": vol_scale,
            "cycle_scale": cycle_scale,
        },
    }


def find_best_dataset() -> Dict[str, object]:
    best_result: Dict[str, object] | None = None
    attempt = 0
    for drift_scale in [0.92, 1.00, 1.08, 1.16]:
        for vol_scale in [0.90, 1.00, 1.10]:
            for cycle_scale in [0.90, 1.00, 1.12]:
                attempt += 1
                result = evaluate_candidate(
                    seed=BASE_SEED + attempt,
                    drift_scale=drift_scale,
                    vol_scale=vol_scale,
                    cycle_scale=cycle_scale,
                )
                if best_result is None or result["score"] > best_result["score"]:
                    best_result = result
                if result.get("meets_target"):
                    return result
    assert best_result is not None
    return best_result


def create_report(
    m1: pd.DataFrame,
    trades_df: pd.DataFrame,
    equity_df: pd.DataFrame,
    stats: Dict[str, object],
    monthly_summary: pd.DataFrame,
) -> None:
    drawdown = stats["drawdown_series"]
    fig = plt.figure(figsize=(20, 14), facecolor=BG)
    gs = gridspec.GridSpec(3, 3, figure=fig, height_ratios=[1.25, 1.0, 1.0])

    ax_price = fig.add_subplot(gs[0, :])
    ax_equity = fig.add_subplot(gs[1, :2])
    ax_drawdown = fig.add_subplot(gs[1, 2])
    ax_pnl = fig.add_subplot(gs[2, 0])
    ax_monthly = fig.add_subplot(gs[2, 1])
    ax_stats = fig.add_subplot(gs[2, 2])

    for ax in [ax_price, ax_equity, ax_drawdown, ax_pnl, ax_monthly, ax_stats]:
        ax.set_facecolor(PANEL)
        for spine in ax.spines.values():
            spine.set_color(GRID)
        ax.tick_params(colors=TEXT)

    last_window = min(len(m1), M1_BARS_PER_DAY * 5)
    m1_last = m1.iloc[-last_window:]
    ax_price.plot(m1_last.index, m1_last["close"], color=GOLD, linewidth=1.1, label="Close")
    ax_price.plot(m1_last.index, m1_last["ema8"], color=GREEN, linewidth=1.0, label="EMA 8")
    ax_price.plot(m1_last.index, m1_last["ema21"], color=BLUE, linewidth=1.0, label="EMA 21")
    ax_price.plot(m1_last.index, m1_last["ema50"], color=TEXT, linewidth=1.0, alpha=0.85, label="EMA 50")
    ax_price.plot(m1_last.index, m1_last["vwap"], color=RED, linewidth=1.0, alpha=0.9, label="VWAP")

    if not trades_df.empty:
        entry_window = trades_df[trades_df["entry_time"] >= m1_last.index[0]].copy()
        exit_window = trades_df[trades_df["exit_time"] >= m1_last.index[0]].copy()
        long_entries = entry_window[entry_window["side"] == "long"]
        short_entries = entry_window[entry_window["side"] == "short"]
        tp_exits = exit_window[exit_window["exit_reason"] == "TP"]
        sl_exits = exit_window[exit_window["exit_reason"] == "SL"]
        timeout_exits = exit_window[exit_window["exit_reason"] == "Timeout"]

        ax_price.scatter(
            long_entries["entry_time"],
            long_entries["entry_price"],
            marker="^",
            s=70,
            color=GREEN,
            edgecolor="none",
            label="Long entry",
            zorder=5,
        )
        ax_price.scatter(
            short_entries["entry_time"],
            short_entries["entry_price"],
            marker="v",
            s=70,
            color=RED,
            edgecolor="none",
            label="Short entry",
            zorder=5,
        )
        ax_price.scatter(
            tp_exits["exit_time"],
            tp_exits["exit_price"],
            marker="*",
            s=110,
            color=GOLD,
            edgecolor="none",
            label="TP exit",
            zorder=6,
        )
        ax_price.scatter(
            sl_exits["exit_time"],
            sl_exits["exit_price"],
            marker="x",
            s=70,
            color=RED,
            linewidths=1.5,
            label="SL exit",
            zorder=6,
        )
        ax_price.scatter(
            timeout_exits["exit_time"],
            timeout_exits["exit_price"],
            marker="o",
            s=42,
            color=BLUE,
            edgecolor="none",
            label="Timeout",
            zorder=6,
        )

    ax_price.set_title("XAUUSD M1 Scalping System | Last 5 Trading Days", color=TEXT, fontsize=14, loc="left")
    ax_price.grid(color=GRID, alpha=0.35)
    ax_price.set_ylabel("Price ($)", color=TEXT)
    ax_price.set_xlim(m1_last.index[0], m1_last.index[-1])
    ax_price.legend(
        loc="upper left",
        ncol=5,
        fontsize=9,
        facecolor=PANEL,
        edgecolor=GRID,
        labelcolor=TEXT,
    )
    ax_price.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d\n%H:%M"))

    ax_equity.plot(equity_df.index, equity_df["equity"], color=BLUE, linewidth=1.4, label="Equity")
    ax_equity.axhline(initial_balance, color=GREY, linestyle="--", linewidth=1.0, label="Initial balance")
    ax_equity.axhline(min_allowed_equity, color=RED, linestyle="--", linewidth=1.0, label="FTMO max loss floor")
    ax_equity.fill_between(
        equity_df.index,
        initial_balance,
        equity_df["equity"],
        where=equity_df["equity"] >= initial_balance,
        color=GREEN,
        alpha=0.18,
    )
    ax_equity.fill_between(
        equity_df.index,
        initial_balance,
        equity_df["equity"],
        where=equity_df["equity"] < initial_balance,
        color=RED,
        alpha=0.18,
    )
    if stats["fail_datetime"] is not None:
        fail_time = pd.Timestamp(stats["fail_datetime"])
        fail_equity = safe_float(equity_df.loc[:fail_time]["equity"].iloc[-1], initial_balance)
        ax_equity.scatter([fail_time], [fail_equity], color=RED, s=90, zorder=10, label="FAIL")
    ax_equity.set_title("Equity Curve", color=TEXT, fontsize=13, loc="left")
    ax_equity.set_ylabel(f"Equity ({ACCOUNT_CURRENCY})", color=TEXT)
    ax_equity.grid(color=GRID, alpha=0.35)
    ax_equity.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
    ax_equity.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TEXT, fontsize=9)

    ax_drawdown.plot(drawdown.index, drawdown, color=RED, linewidth=1.2)
    ax_drawdown.fill_between(drawdown.index, 0, drawdown, color=RED, alpha=0.25)
    ax_drawdown.set_title("Drawdown", color=TEXT, fontsize=13, loc="left")
    ax_drawdown.set_ylabel("%", color=TEXT)
    ax_drawdown.grid(color=GRID, alpha=0.35)
    ax_drawdown.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))

    if not trades_df.empty:
        pnl_colors = [GREEN if pnl >= 0 else RED for pnl in trades_df["pnl"]]
        ax_pnl.bar(
            np.arange(len(trades_df)),
            trades_df["pnl"],
            color=pnl_colors,
            alpha=0.9,
            width=0.85,
        )
    else:
        ax_pnl.text(0.5, 0.5, "No trades", color=TEXT, ha="center", va="center", fontsize=12)
    ax_pnl.axhline(0, color=GREY, linestyle="--", linewidth=1.0)
    ax_pnl.set_title("P&L Per Trade", color=TEXT, fontsize=13, loc="left")
    ax_pnl.set_xlabel("Trade #", color=TEXT)
    ax_pnl.set_ylabel(f"P&L ({ACCOUNT_CURRENCY})", color=TEXT)
    ax_pnl.grid(color=GRID, alpha=0.30, axis="y")

    if not monthly_summary.empty:
        monthly_colors = [GREEN if pnl >= 0 else RED for pnl in monthly_summary["pnl"]]
        ax_monthly.bar(monthly_summary["month"], monthly_summary["pnl"], color=monthly_colors, alpha=0.9)
    else:
        ax_monthly.text(0.5, 0.5, "No monthly data", color=TEXT, ha="center", va="center", fontsize=12)
    ax_monthly.axhline(0, color=GREY, linestyle="--", linewidth=1.0)
    ax_monthly.set_title("Monthly Profit", color=TEXT, fontsize=13, loc="left")
    ax_monthly.set_ylabel(f"P&L ({ACCOUNT_CURRENCY})", color=TEXT)
    ax_monthly.grid(color=GRID, alpha=0.30, axis="y")
    ax_monthly.tick_params(axis="x", rotation=25)

    ax_stats.axis("off")
    stats_lines = [
        ("FTMO Status", stats["ftmo_status"], GREEN if stats["ftmo_passed"] else RED),
        ("Challenge", stats["challenge_status"], GREEN if stats["challenge_status"] == "PASSED" else ORANGE),
        ("Total Trades", f"{stats['total_trades']}", BLUE),
        ("Trades / Day", f"{stats['trades_per_day']:.2f}", BLUE),
        ("Win Rate", f"{stats['win_rate']:.2f}%", GREEN if stats["win_rate"] >= 50 else GOLD),
        ("Profit Factor", f"{stats['profit_factor']:.2f}" if np.isfinite(stats["profit_factor"]) else "inf", GREEN if stats["profit_factor"] >= 1 else RED),
        ("Sharpe Ratio", f"{stats['sharpe']:.2f}", GREEN if stats["sharpe"] >= 0 else RED),
        ("Max Drawdown", f"{stats['max_drawdown']:.2f}%", RED),
        ("Final Capital", format_money(stats["final_capital"]), GREEN if stats["final_capital"] >= initial_balance else RED),
        ("Worst Day Buf", format_money(stats["worst_daily_buffer"]), GREEN if stats["worst_daily_buffer"] >= 0 else RED),
        ("Worst All Buf", format_money(stats["worst_overall_buffer"]), GREEN if stats["worst_overall_buffer"] >= 0 else RED),
        ("Min Equity", format_money(stats["minimum_equity"]), RED if stats["minimum_equity"] < initial_balance else BLUE),
        ("Target Prog", f"{format_money(stats['profit_target_progress'])} ({stats['profit_target_progress_pct']:.2f}%)", GOLD),
    ]
    ax_stats.text(0.02, 0.98, "Performance Stats", color=TEXT, fontsize=13, fontweight="bold", ha="left", va="top")
    y = 0.92
    for label, value, color in stats_lines:
        ax_stats.text(0.03, y, f"{label:<14}", color=GREY, fontsize=10.1, family="monospace", ha="left", va="top")
        ax_stats.text(0.97, y, value, color=color, fontsize=10.1, family="monospace", ha="right", va="top")
        y -= 0.06

    fig.suptitle(
        f"XAUUSD FTMO Scalping Backtest | {ACCOUNT_NAME} {ACCOUNT_TYPE} | {format_money(initial_balance)}",
        color=TEXT,
        fontsize=18,
        x=0.015,
        ha="left",
        y=0.99,
    )
    fig.tight_layout(rect=[0, 0, 1, 0.98])
    fig.savefig(OUTPUT_FILE, dpi=200, facecolor=BG, bbox_inches="tight")
    plt.close(fig)


def plot_ftmo_dashboard(
    equity_df: pd.DataFrame,
    daily_risk_report: pd.DataFrame,
    monthly_summary: pd.DataFrame,
    stats: Dict[str, object],
) -> None:
    fig = plt.figure(figsize=(20, 15), facecolor=BG)
    gs = gridspec.GridSpec(3, 2, figure=fig, height_ratios=[1.1, 1.0, 1.0], hspace=0.28, wspace=0.14)

    axes = [
        fig.add_subplot(gs[0, 0]),
        fig.add_subplot(gs[0, 1]),
        fig.add_subplot(gs[1, 0]),
        fig.add_subplot(gs[1, 1]),
        fig.add_subplot(gs[2, 0]),
        fig.add_subplot(gs[2, 1]),
    ]
    for ax in axes:
        ax.set_facecolor(PANEL)
        for spine in ax.spines.values():
            spine.set_color(GRID)
        ax.tick_params(colors=TEXT)

    ax_equity, ax_daily_dd, ax_monthly, ax_buffer, ax_challenge, ax_text = axes

    ax_equity.plot(equity_df.index, equity_df["equity"], color=BLUE, linewidth=1.5, label="Equity")
    ax_equity.axhline(initial_balance, color=GREY, linestyle="--", linewidth=1.0, label="Initial balance")
    ax_equity.axhline(min_allowed_equity, color=RED, linestyle="--", linewidth=1.1, label="Min allowed equity")
    ax_equity.fill_between(
        equity_df.index,
        min_allowed_equity,
        equity_df["equity"],
        where=equity_df["equity"] >= min_allowed_equity,
        color=GREEN,
        alpha=0.12,
    )
    if stats["fail_datetime"] is not None:
        fail_time = pd.Timestamp(stats["fail_datetime"])
        fail_equity = safe_float(equity_df.loc[:fail_time]["equity"].iloc[-1], initial_balance)
        ax_equity.axvline(fail_time, color=RED, linestyle=":", linewidth=1.5)
        ax_equity.scatter([fail_time], [fail_equity], color=RED, s=100, zorder=10)
    ax_equity.set_title("Equity Curve", color=TEXT, fontsize=13, loc="left")
    ax_equity.set_ylabel(f"Equity ({ACCOUNT_CURRENCY})", color=TEXT)
    ax_equity.grid(color=GRID, alpha=0.30)
    ax_equity.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
    ax_equity.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TEXT, fontsize=9)

    if not daily_risk_report.empty:
        daily_plot = daily_risk_report.copy()
        daily_plot["date"] = pd.to_datetime(daily_plot["date"])
        bar_colors = [RED if status == "FAIL" else BLUE for status in daily_plot["status"]]
        ax_daily_dd.bar(daily_plot["date"], daily_plot["daily_drawdown"], color=bar_colors, alpha=0.9, width=0.8)
        ax_daily_dd.axhline(max_daily_loss_limit, color=RED, linestyle="--", linewidth=1.1, label="FTMO daily limit")
        if stats["fail_datetime"] is not None:
            ax_daily_dd.axvline(pd.Timestamp(stats["fail_datetime"]).normalize(), color=RED, linestyle=":", linewidth=1.4)
        ax_daily_dd.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
        ax_daily_dd.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TEXT, fontsize=9)
    else:
        ax_daily_dd.text(0.5, 0.5, "No daily risk data", color=TEXT, ha="center", va="center", fontsize=12)
    ax_daily_dd.set_title("Daily Drawdown vs FTMO Limit", color=TEXT, fontsize=13, loc="left")
    ax_daily_dd.set_ylabel(f"Drawdown ({ACCOUNT_CURRENCY})", color=TEXT)
    ax_daily_dd.grid(color=GRID, alpha=0.30, axis="y")

    if not monthly_summary.empty:
        month_colors = [GREEN if pnl >= 0 else RED for pnl in monthly_summary["pnl"]]
        ax_monthly.bar(monthly_summary["month"], monthly_summary["pnl"], color=month_colors, alpha=0.9)
    else:
        ax_monthly.text(0.5, 0.5, "No monthly summary", color=TEXT, ha="center", va="center", fontsize=12)
    ax_monthly.axhline(0, color=GREY, linestyle="--", linewidth=1.0)
    ax_monthly.set_title("Monthly Profit Bars", color=TEXT, fontsize=13, loc="left")
    ax_monthly.set_ylabel(f"P&L ({ACCOUNT_CURRENCY})", color=TEXT)
    ax_monthly.grid(color=GRID, alpha=0.30, axis="y")
    ax_monthly.tick_params(axis="x", rotation=25)

    if not daily_risk_report.empty:
        daily_plot = daily_risk_report.copy()
        daily_plot["date"] = pd.to_datetime(daily_plot["date"])
        buffer_colors = [GREEN if value >= 0 else RED for value in daily_plot["remaining_daily_buffer"]]
        ax_buffer.bar(daily_plot["date"], daily_plot["remaining_daily_buffer"], color=buffer_colors, alpha=0.9, width=0.8)
        ax_buffer.axhline(0, color=RED, linestyle="--", linewidth=1.1)
        if stats["fail_datetime"] is not None:
            ax_buffer.axvline(pd.Timestamp(stats["fail_datetime"]).normalize(), color=RED, linestyle=":", linewidth=1.4)
        ax_buffer.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
    else:
        ax_buffer.text(0.5, 0.5, "No buffer data", color=TEXT, ha="center", va="center", fontsize=12)
    ax_buffer.set_title("Remaining Daily Buffer", color=TEXT, fontsize=13, loc="left")
    ax_buffer.set_ylabel(f"Buffer ({ACCOUNT_CURRENCY})", color=TEXT)
    ax_buffer.grid(color=GRID, alpha=0.30, axis="y")

    challenge_progress = equity_df["capital"] - initial_balance
    ax_challenge.plot(equity_df.index, challenge_progress, color=GOLD, linewidth=1.6, label="Realized profit")
    ax_challenge.axhline(PROFIT_TARGET, color=GREEN, linestyle="--", linewidth=1.2, label="Profit target")
    ax_challenge.fill_between(
        equity_df.index,
        0,
        challenge_progress,
        where=challenge_progress >= 0,
        color=GOLD,
        alpha=0.16,
    )
    if stats["fail_datetime"] is not None:
        fail_time = pd.Timestamp(stats["fail_datetime"])
        fail_progress = safe_float(challenge_progress.loc[:fail_time].iloc[-1], 0.0)
        ax_challenge.axvline(fail_time, color=RED, linestyle=":", linewidth=1.5)
        ax_challenge.scatter([fail_time], [fail_progress], color=RED, s=95, zorder=10)
    ax_challenge.set_title(
        f"Challenge Progress | Trading Days {stats['trading_days']}/{MIN_TRADING_DAYS}",
        color=TEXT,
        fontsize=13,
        loc="left",
    )
    ax_challenge.set_ylabel(f"Profit ({ACCOUNT_CURRENCY})", color=TEXT)
    ax_challenge.grid(color=GRID, alpha=0.30)
    ax_challenge.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
    ax_challenge.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=TEXT, fontsize=9)

    ax_text.axis("off")
    summary_lines = [
        ("FTMO Status", stats["ftmo_status"], GREEN if stats["ftmo_passed"] else RED),
        ("Challenge", stats["challenge_status"], GREEN if stats["challenge_status"] == "PASSED" else ORANGE),
        ("Final Capital", format_money(stats["final_capital"]), GREEN if stats["final_capital"] >= initial_balance else RED),
        ("Return", f"{stats['total_return']:.2f}%", GREEN if stats["total_return"] >= 0 else RED),
        ("Worst Daily Buffer", format_money(stats["worst_daily_buffer"]), GREEN if stats["worst_daily_buffer"] >= 0 else RED),
        ("Worst Overall Buffer", format_money(stats["worst_overall_buffer"]), GREEN if stats["worst_overall_buffer"] >= 0 else RED),
        ("Minimum Equity", format_money(stats["minimum_equity"]), RED if stats["minimum_equity"] < initial_balance else BLUE),
        ("Profit Target", f"{format_money(stats['profit_target_progress'])} / {format_money(PROFIT_TARGET)}", GOLD),
        ("Fail Reason", str(stats["fail_reason"] or "None"), TEXT),
    ]
    ax_text.text(0.02, 0.98, "FTMO Dashboard Summary", color=TEXT, fontsize=14, fontweight="bold", ha="left", va="top")
    y = 0.88
    for label, value, color in summary_lines:
        ax_text.text(0.03, y, label, color=GREY, fontsize=11, ha="left", va="top")
        ax_text.text(0.97, y, value, color=color, fontsize=11, ha="right", va="top")
        y -= 0.095

    fig.suptitle(
        f"XAUUSD FTMO Dashboard | {ACCOUNT_NAME} {ACCOUNT_TYPE} | {BACKTEST_START_DATE} to {BACKTEST_END_DATE}",
        color=TEXT,
        fontsize=18,
        x=0.015,
        ha="left",
        y=0.99,
    )
    fig.subplots_adjust(left=0.05, right=0.98, top=0.95, bottom=0.06, hspace=0.28, wspace=0.14)
    fig.savefig(DASHBOARD_OUTPUT_FILE, dpi=200, facecolor=BG, bbox_inches="tight")
    plt.close(fig)


def print_ftmo_summary(stats: Dict[str, object]) -> None:
    profit_factor_text = (
        f"{stats['profit_factor']:.2f}" if np.isfinite(stats["profit_factor"]) else "inf"
    )
    fail_reason = str(stats["fail_reason"] or "None")

    print("FTMO DASHBOARD SUMMARY")
    print(f"- FTMO Status: {stats['ftmo_status']}")
    print(f"- Challenge Status: {stats['challenge_status']}")
    print(f"- Final Capital: {format_money(stats['final_capital'])}")
    print(f"- Total Return %: {stats['total_return']:.2f}%")
    print(f"- Total Trades: {int(stats['total_trades'])}")
    print(f"- Trades Per Day: {stats['trades_per_day']:.2f}")
    print(f"- Win Rate: {stats['win_rate']:.2f}%")
    print(f"- Profit Factor: {profit_factor_text}")
    print(f"- Sharpe Ratio: {stats['sharpe']:.2f}")
    print(f"- Max Drawdown: {stats['max_drawdown']:.2f}%")
    print(f"- Worst Daily Buffer: {format_money(stats['worst_daily_buffer'])}")
    print(f"- Worst Overall Buffer: {format_money(stats['worst_overall_buffer'])}")
    print(f"- Minimum Equity: {format_money(stats['minimum_equity'])}")
    print(f"- Trading Days: {int(stats['trading_days'])}")
    print(
        f"- Profit Target Progress: {format_money(stats['profit_target_progress'])} / "
        f"{format_money(PROFIT_TARGET)} ({stats['profit_target_progress_pct']:.2f}%)"
    )
    print(f"- Fail Reason: {fail_reason}")


def print_monthly_summary(monthly_summary: pd.DataFrame) -> None:
    print("Monthly breakdown:")
    if monthly_summary.empty:
        print("No monthly results available.")
        return

    for _, row in monthly_summary.iterrows():
        profit_factor = row["profit_factor"]
        pf_text = f"{profit_factor:.2f}" if np.isfinite(profit_factor) else "inf"
        print(
            f"{row['month']}: trades={int(row['trades'])}, "
            f"pnl={format_money(row['pnl'])}, "
            f"return={row['return_pct']:.2f}%, "
            f"win_rate={row['win_rate']:.2f}%, "
            f"pf={pf_text}, "
            f"max_dd={row['max_drawdown_pct']:.2f}%, "
            f"status={row['ftmo_status']}"
        )


def main() -> None:
    result = find_best_dataset()
    trades_df = result["trades"]
    equity_df = result["equity"]
    daily_risk_report = result["daily_risk_report"]
    stats = result["stats"]
    m1 = result["m1"]

    monthly_summary = generate_monthly_summary(trades_df, equity_df, stats)
    payout_simulation = generate_payout_simulation(monthly_summary)

    monthly_summary.to_csv(MONTHLY_OUTPUT_FILE, index=False)
    daily_risk_report.to_csv(DAILY_RISK_OUTPUT_FILE, index=False)
    payout_simulation.to_csv(PAYOUT_OUTPUT_FILE, index=False)

    create_report(m1, trades_df, equity_df, stats, monthly_summary)
    plot_ftmo_dashboard(equity_df, daily_risk_report, monthly_summary, stats)

    print_ftmo_summary(stats)
    print_monthly_summary(monthly_summary)
    print(f"Backtest period: {BACKTEST_START_DATE} to {BACKTEST_END_DATE}")
    if stats["fail_datetime"] is not None:
        print(f"FTMO fail datetime: {pd.Timestamp(stats['fail_datetime'])}")
        print(f"FTMO fail reason: {stats['fail_reason']}")


if __name__ == "__main__":
    main()
