from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List

import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
LOGGER = logging.getLogger("ftmo_backtest_monthly_report")
logging.getLogger("matplotlib").setLevel(logging.WARNING)


BASE_DIR = Path(".")
TRADE_QUALITY_FILE = BASE_DIR / "ftmo_trade_quality.csv"
RISK_FILE = BASE_DIR / "ftmo_risk_engine.csv"
MONTHLY_FILE = BASE_DIR / "xauusd_monthly_summary.csv"
REGIME_FILE = BASE_DIR / "ftmo_regime_analysis.csv"
SESSION_FILE = BASE_DIR / "ftmo_session_analysis.csv"

PDF_OUTPUT = BASE_DIR / "ftmo_backtest_monthly_review.pdf"
PNG_OUTPUT = BASE_DIR / "ftmo_backtest_monthly_review.png"


PALETTE = {
    "bg": "#061018",
    "panel": "#0b1622",
    "card": "#101d2b",
    "grid": "#243647",
    "text": "#e7edf4",
    "muted": "#8da3b8",
    "green": "#22c55e",
    "red": "#fb7185",
    "amber": "#f59e0b",
    "blue": "#60a5fa",
    "cyan": "#22d3ee",
    "violet": "#a78bfa",
    "gold": "#facc15",
    "white": "#f8fafc",
}


def format_eur(value: float) -> str:
    sign = "-" if value < 0 else ""
    return f"{sign}EUR {abs(float(value)):,.0f}"


def format_pct(value: float) -> str:
    return f"{float(value):.2f}%"


def euro_formatter() -> FuncFormatter:
    return FuncFormatter(lambda value, pos: f"EUR {value:,.0f}")


def safe_float(value: object, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if not np.isfinite(number):
        return default
    return number


def calculate_profit_factor(series: pd.Series) -> float:
    pnl = pd.Series(series).astype(float)
    gross_profit = float(pnl[pnl > 0].sum())
    gross_loss = abs(float(pnl[pnl < 0].sum()))
    if gross_loss == 0:
        return float("inf") if gross_profit > 0 else 0.0
    return gross_profit / gross_loss


def style_axes(ax: plt.Axes, title: str, subtitle: str | None = None) -> None:
    ax.set_facecolor(PALETTE["panel"])
    for spine in ax.spines.values():
        spine.set_color(PALETTE["grid"])
    ax.tick_params(colors=PALETTE["muted"], labelsize=8)
    ax.grid(True, color=PALETTE["grid"], alpha=0.25, linewidth=0.8)
    ax.set_title(title, color=PALETTE["white"], fontsize=11, fontweight="bold", loc="left", pad=9)
    if subtitle:
        ax.text(
            0.0,
            1.02,
            subtitle,
            transform=ax.transAxes,
            color=PALETTE["muted"],
            fontsize=8,
            va="bottom",
        )


def draw_metric_card(ax: plt.Axes, x: float, y: float, w: float, h: float, title: str, value: str, detail: str, accent: str) -> None:
    box = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.015,rounding_size=0.025",
        linewidth=1.0,
        edgecolor=PALETTE["grid"],
        facecolor=PALETTE["card"],
        transform=ax.transAxes,
    )
    ax.add_patch(box)
    ax.text(x + 0.02, y + h - 0.08, title, color=PALETTE["muted"], fontsize=8.5, transform=ax.transAxes)
    ax.text(x + 0.02, y + 0.08, value, color=PALETTE["white"], fontsize=14, fontweight="bold", transform=ax.transAxes)
    ax.text(x + 0.02, y + 0.025, detail, color=accent, fontsize=8.2, transform=ax.transAxes)


def load_data() -> Dict[str, pd.DataFrame]:
    LOGGER.info("Loading monthly report input datasets")
    trades = pd.read_csv(TRADE_QUALITY_FILE)
    risk = pd.read_csv(RISK_FILE)
    monthly = pd.read_csv(MONTHLY_FILE)
    regime = pd.read_csv(REGIME_FILE) if REGIME_FILE.exists() else pd.DataFrame()
    session = pd.read_csv(SESSION_FILE) if SESSION_FILE.exists() else pd.DataFrame()

    trades["entry_time"] = pd.to_datetime(trades["entry_time"])
    trades["exit_time"] = pd.to_datetime(trades["exit_time"])
    trades["entry_date"] = pd.to_datetime(trades["entry_date"])
    risk["date"] = pd.to_datetime(risk["date"])
    monthly["month"] = monthly["month"].astype(str)
    trades["month"] = trades["month"].astype(str)
    risk["month"] = risk["month"].astype(str)
    return {
        "trades": trades,
        "risk": risk,
        "monthly": monthly,
        "regime": regime,
        "session": session,
    }


def build_monthly_review(trades: pd.DataFrame, risk: pd.DataFrame, monthly: pd.DataFrame) -> pd.DataFrame:
    LOGGER.info("Building month-by-month review dataset")
    rows: List[Dict[str, object]] = []
    for month in monthly["month"].tolist():
        month_trades = trades[trades["month"] == month].copy()
        month_risk = risk[risk["month"] == month].copy()
        base_row = monthly[monthly["month"] == month].iloc[0]
        if month_trades.empty:
            continue

        regime_pnl = month_trades.groupby("regime_label")["pnl"].sum().sort_values(ascending=False)
        session_pnl = month_trades.groupby("session_label")["pnl"].sum().sort_values(ascending=False)
        worst_regime = regime_pnl.index[-1] if len(regime_pnl) else "N/A"
        best_regime = regime_pnl.index[0] if len(regime_pnl) else "N/A"
        best_session = session_pnl.index[0] if len(session_pnl) else "N/A"
        worst_session = session_pnl.index[-1] if len(session_pnl) else "N/A"

        rows.append(
            {
                "month": month,
                "baseline_pnl": safe_float(base_row["pnl"]),
                "baseline_return_pct": safe_float(base_row["return_pct"]),
                "baseline_pf": safe_float(base_row["profit_factor"]),
                "baseline_win_rate": safe_float(base_row["win_rate"]),
                "trade_count": int(len(month_trades)),
                "v3_pnl": float(month_trades["v3_pnl"].sum()),
                "v3_pf": calculate_profit_factor(month_trades["v3_pnl"]),
                "executed_trades": int(month_trades["v3_executed"].sum()),
                "blocked_trades": int(month_trades["suppressed"].sum()),
                "suppression_rate": float(month_trades["suppressed"].mean() * 100.0),
                "avg_quality_score": float(month_trades["trade_quality_score"].mean()),
                "avg_suppression_score": float(month_trades["suppression_score"].mean()),
                "avg_dynamic_risk_pct": float(month_trades["dynamic_risk_pct"].mean() * 100.0),
                "total_execution_cost": float(month_trades["execution_cost"].sum()),
                "avg_execution_cost": float(month_trades["execution_cost"].mean()),
                "drawdown_cluster_days": int(month_risk["drawdown_cluster_active"].fillna(False).sum()),
                "danger_days": int((month_risk["risk_mode"] == "EMERGENCY").sum() + (month_risk["ftmo_buffer_zone"] == "DANGER").sum()),
                "warning_days": int((month_risk["ftmo_buffer_zone"] == "WARNING").sum()),
                "max_stress_score": float(month_risk["stress_score"].max()) if not month_risk.empty else 0.0,
                "avg_fail_probability": float(month_risk["fail_probability"].mean() * 100.0) if not month_risk.empty else 0.0,
                "best_regime": best_regime,
                "worst_regime": worst_regime,
                "best_session": best_session,
                "worst_session": worst_session,
                "dominant_regime": month_trades["regime_label"].mode().iloc[0],
                "best_day": float(month_risk["daily_pnl"].max()) if not month_risk.empty else 0.0,
                "worst_day": float(month_risk["daily_pnl"].min()) if not month_risk.empty else 0.0,
            }
        )
    return pd.DataFrame(rows)


def month_label(month: str) -> str:
    return pd.Timestamp(f"{month}-01").strftime("%B %Y").upper()


def build_month_narrative(row: pd.Series) -> List[str]:
    narrative: List[str] = []
    pf = safe_float(row["baseline_pf"])
    ret = safe_float(row["baseline_return_pct"])
    suppression = safe_float(row["suppression_rate"])

    if pf >= 1.60 and ret > 6.0:
        narrative.append("Sterke quality month: edge zat in lijn met regime-structuur en capital efficiency was hoog.")
    elif pf < 1.05:
        narrative.append("Kwetsbare month: expectancy werd bijna volledig geabsorbeerd door slechte marktcondities.")
    else:
        narrative.append("Gemengde month: edge bleef positief, maar selectiviteit was nog niet institutioneel strak.")

    if suppression >= 40:
        narrative.append("V3 moest agressief blokkeren: duidelijke indicatie van overtrading in baseline-flow.")
    elif suppression >= 25:
        narrative.append("V3 blokkeerde een materieel deel van de flow, vooral om chop en low-quality continuations te vermijden.")
    else:
        narrative.append("Relatief nette flow: minder suppression nodig omdat de marktstructuur al schoner was.")

    narrative.append(f"Beste regime: {row['best_regime']} | Zwakste regime: {row['worst_regime']}.")
    narrative.append(f"Beste sessie: {row['best_session']} | Zwakste sessie: {row['worst_session']}.")

    if safe_float(row["drawdown_cluster_days"]) > 2:
        narrative.append("Drawdown kwam geclusterd binnen, niet random; dat wijst op regime-mismatch in plaats van puur variance.")
    else:
        narrative.append("Drawdown bleef relatief controleerbaar en minder geclusterd dan in de stressmaanden.")

    return narrative


def render_cover_page(pdf: PdfPages, review: pd.DataFrame, trades: pd.DataFrame, risk: pd.DataFrame) -> None:
    fig = plt.figure(figsize=(16, 10), facecolor=PALETTE["bg"])
    gs = gridspec.GridSpec(3, 4, figure=fig, height_ratios=[0.72, 1.0, 1.0], hspace=0.28, wspace=0.24)

    ax_header = fig.add_subplot(gs[0, :])
    ax_header.axis("off")
    ax_header.text(0.0, 0.92, "FTMO XAUUSD Backtest Review", color=PALETTE["white"], fontsize=22, fontweight="bold", transform=ax_header.transAxes)
    ax_header.text(0.0, 0.78, "Month-by-month institutional review based on the Version 3 analytics stack", color=PALETTE["muted"], fontsize=11, transform=ax_header.transAxes)

    baseline_pnl = float(review["baseline_pnl"].sum())
    v3_pnl = float(review["v3_pnl"].sum())
    suppression_rate = float(trades["suppressed"].mean() * 100.0)
    pf = calculate_profit_factor(trades["pnl"])
    v3_pf = calculate_profit_factor(trades["v3_pnl"])

    card_specs = [
        ("Baseline Net", format_eur(baseline_pnl), "Original backtest result", PALETTE["blue"]),
        ("V3 Net", format_eur(v3_pnl), "After suppression and risk controls", PALETTE["green"]),
        ("Baseline PF", f"{pf:.2f}", "Raw edge quality", PALETTE["amber"]),
        ("V3 PF", f"{v3_pf:.2f}", "Controlled capital efficiency", PALETTE["green"]),
        ("Suppression", format_pct(suppression_rate), "Bad trades filtered", PALETTE["red"]),
        ("Stress Peak", f"{safe_float(risk['stress_score'].max()):.1f}", "Worst daily risk pressure", PALETTE["violet"]),
    ]
    xs = [0.00, 0.17, 0.34, 0.51, 0.68, 0.85]
    for x, (title, value, detail, accent) in zip(xs, card_specs):
        draw_metric_card(ax_header, x, 0.15, 0.13, 0.45, title, value, detail, accent)

    ax_monthly = fig.add_subplot(gs[1, :2])
    style_axes(ax_monthly, "Monthly Net PnL", "Baseline vs V3 by month")
    month_names = [pd.Timestamp(f"{month}-01").strftime("%b") for month in review["month"]]
    positions = np.arange(len(review))
    ax_monthly.bar(positions - 0.18, review["baseline_pnl"], width=0.36, color=PALETTE["blue"], label="Baseline")
    ax_monthly.bar(positions + 0.18, review["v3_pnl"], width=0.36, color=PALETTE["green"], label="V3")
    ax_monthly.set_xticks(positions)
    ax_monthly.set_xticklabels(month_names)
    ax_monthly.axhline(0.0, color=PALETTE["grid"], linewidth=1.0)
    ax_monthly.yaxis.set_major_formatter(euro_formatter())
    ax_monthly.legend(loc="upper right", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"], fontsize=8.5)

    ax_pf = fig.add_subplot(gs[1, 2:])
    style_axes(ax_pf, "Monthly Profit Factor And Suppression", "Where quality improved the most")
    ax_pf.plot(review["month"], review["baseline_pf"], color=PALETTE["amber"], linewidth=2.0, marker="o", label="Baseline PF")
    ax_pf.plot(review["month"], review["v3_pf"], color=PALETTE["green"], linewidth=2.0, marker="o", label="V3 PF")
    ax_pf.bar(review["month"], review["suppression_rate"] / 100.0, alpha=0.18, color=PALETTE["red"], label="Suppression rate")
    ax_pf.axhline(1.0, color=PALETTE["grid"], linewidth=1.0, linestyle="--")
    ax_pf.legend(loc="upper left", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"], fontsize=8)

    ax_text = fig.add_subplot(gs[2, :])
    ax_text.set_facecolor(PALETTE["panel"])
    ax_text.axis("off")
    strongest = review.sort_values("baseline_pnl", ascending=False).iloc[0]
    weakest = review.sort_values("baseline_pnl", ascending=True).iloc[0]
    summary_lines = [
        f"Best month: {month_label(strongest['month'])} | baseline {format_eur(strongest['baseline_pnl'])} | PF {strongest['baseline_pf']:.2f}",
        f"Weakest month: {month_label(weakest['month'])} | baseline {format_eur(weakest['baseline_pnl'])} | PF {weakest['baseline_pf']:.2f}",
        "Primary takeaway: de backtest verdient geld, maar de performance wordt onevenredig gedragen door de trend/expansion-fases.",
        "Institutionele diagnose: drawdown is regime-geclusterd, niet random. Dat is gunstig, want het is vaak beter te onderdrukken dan te 'fixen' met nieuwe entries.",
        "V3-conclusie: minder trades was duidelijk efficiënter dan meer trades, vooral rond February-style chop en session transitions.",
    ]
    ax_text.text(
        0.03,
        0.92,
        "Executive Readout",
        color=PALETTE["white"],
        fontsize=13,
        fontweight="bold",
        transform=ax_text.transAxes,
    )
    ax_text.text(
        0.03,
        0.80,
        "\n".join(summary_lines),
        color=PALETTE["text"],
        fontsize=10,
        va="top",
        transform=ax_text.transAxes,
        bbox=dict(facecolor=PALETTE["card"], edgecolor=PALETTE["grid"], boxstyle="round,pad=0.45"),
    )

    pdf.savefig(fig, facecolor=PALETTE["bg"], bbox_inches="tight")
    fig.savefig(PNG_OUTPUT, dpi=220, facecolor=PALETTE["bg"], bbox_inches="tight")
    plt.close(fig)


def render_month_page(pdf: PdfPages, month: str, review_row: pd.Series, trades: pd.DataFrame, risk: pd.DataFrame) -> None:
    month_trades = trades[trades["month"] == month].copy()
    month_risk = risk[risk["month"] == month].copy()
    fig = plt.figure(figsize=(16, 10), facecolor=PALETTE["bg"])
    gs = gridspec.GridSpec(3, 4, figure=fig, height_ratios=[0.55, 1.0, 1.0], hspace=0.30, wspace=0.24)

    ax_top = fig.add_subplot(gs[0, :])
    ax_top.axis("off")
    title = month_label(month)
    ax_top.text(0.0, 0.92, title, color=PALETTE["white"], fontsize=21, fontweight="bold", transform=ax_top.transAxes)
    ax_top.text(0.0, 0.75, f"Dominant regime: {review_row['dominant_regime']} | Best regime: {review_row['best_regime']} | Weakest regime: {review_row['worst_regime']}", color=PALETTE["muted"], fontsize=10, transform=ax_top.transAxes)

    cards = [
        ("Baseline", format_eur(review_row["baseline_pnl"]), f"PF {review_row['baseline_pf']:.2f}", PALETTE["blue"]),
        ("V3", format_eur(review_row["v3_pnl"]), f"PF {review_row['v3_pf']:.2f}", PALETTE["green"]),
        ("Trades", f"{int(review_row['trade_count'])}", f"Executed {int(review_row['executed_trades'])}", PALETTE["gold"]),
        ("Suppression", format_pct(review_row["suppression_rate"]), f"Blocked {int(review_row['blocked_trades'])}", PALETTE["red"]),
        ("Stress", f"{review_row['max_stress_score']:.1f}", f"Fail avg {review_row['avg_fail_probability']:.1f}%", PALETTE["violet"]),
    ]
    xs = [0.00, 0.19, 0.38, 0.57, 0.76]
    for x, (label, value, detail, accent) in zip(xs, cards):
        draw_metric_card(ax_top, x, 0.10, 0.16, 0.48, label, value, detail, accent)

    ax_regime = fig.add_subplot(gs[1, :2])
    style_axes(ax_regime, "Regime Contribution", "Baseline vs V3 PnL by regime")
    regime_table = month_trades.groupby("regime_label")[["pnl", "v3_pnl"]].sum().sort_values("pnl", ascending=False)
    positions = np.arange(len(regime_table))
    ax_regime.barh(positions - 0.18, regime_table["pnl"], height=0.36, color=PALETTE["blue"], label="Baseline")
    ax_regime.barh(positions + 0.18, regime_table["v3_pnl"], height=0.36, color=PALETTE["green"], label="V3")
    ax_regime.set_yticks(positions)
    ax_regime.set_yticklabels(regime_table.index)
    ax_regime.axvline(0.0, color=PALETTE["grid"], linewidth=1.0)
    ax_regime.xaxis.set_major_formatter(euro_formatter())
    ax_regime.legend(loc="lower right", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"], fontsize=8)

    ax_session = fig.add_subplot(gs[1, 2:])
    style_axes(ax_session, "Session Contribution", "PnL by trading session")
    session_table = month_trades.groupby("session_label")[["pnl", "v3_pnl"]].sum().sort_values("pnl", ascending=False)
    ax_session.bar(session_table.index, session_table["pnl"], color=PALETTE["blue"], alpha=0.65, label="Baseline")
    ax_session.bar(session_table.index, session_table["v3_pnl"], color=PALETTE["green"], alpha=0.75, label="V3")
    ax_session.axhline(0.0, color=PALETTE["grid"], linewidth=1.0)
    ax_session.yaxis.set_major_formatter(euro_formatter())
    ax_session.legend(loc="upper right", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"], fontsize=8)

    ax_daily = fig.add_subplot(gs[2, :2])
    style_axes(ax_daily, "Daily PnL And Stress", "Where the month accelerated or destabilised")
    if not month_risk.empty:
        ax_daily.bar(month_risk["date"], month_risk["daily_pnl"], color=np.where(month_risk["daily_pnl"] >= 0, PALETTE["green"], PALETTE["red"]), alpha=0.65, label="Daily PnL")
        ax_daily.plot(month_risk["date"], month_risk["stress_score"], color=PALETTE["amber"], linewidth=1.8, label="Stress score")
        ax_daily.axhline(0.0, color=PALETTE["grid"], linewidth=1.0)
        ax_daily.legend(loc="upper left", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"], fontsize=8)

    ax_notes = fig.add_subplot(gs[2, 2:])
    ax_notes.set_facecolor(PALETTE["panel"])
    ax_notes.axis("off")
    notes = build_month_narrative(review_row)
    note_text = "\n".join([f"- {line}" for line in notes])
    extra = [
        f"- Best day: {format_eur(review_row['best_day'])}",
        f"- Worst day: {format_eur(review_row['worst_day'])}",
        f"- Avg quality score: {review_row['avg_quality_score']:.1f}",
        f"- Avg suppression score: {review_row['avg_suppression_score']:.1f}",
        f"- Avg dynamic risk: {review_row['avg_dynamic_risk_pct']:.3f}%",
        f"- Total execution cost: {format_eur(review_row['total_execution_cost'])}",
    ]
    ax_notes.text(0.03, 0.92, "Monthly Diagnosis", color=PALETTE["white"], fontsize=12.5, fontweight="bold", transform=ax_notes.transAxes)
    ax_notes.text(
        0.03,
        0.84,
        note_text + "\n" + "\n".join(extra),
        color=PALETTE["text"],
        fontsize=9.4,
        va="top",
        transform=ax_notes.transAxes,
        bbox=dict(facecolor=PALETTE["card"], edgecolor=PALETTE["grid"], boxstyle="round,pad=0.45"),
    )

    pdf.savefig(fig, facecolor=PALETTE["bg"], bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    data = load_data()
    review = build_monthly_review(data["trades"], data["risk"], data["monthly"])

    LOGGER.info("Rendering monthly PDF and image outputs")
    with PdfPages(PDF_OUTPUT) as pdf:
        render_cover_page(pdf, review, data["trades"], data["risk"])
        for month in review["month"].tolist():
            render_month_page(pdf, month, review[review["month"] == month].iloc[0], data["trades"], data["risk"])

    LOGGER.info("Generated %s and %s", PDF_OUTPUT.name, PNG_OUTPUT.name)


if __name__ == "__main__":
    main()
