from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import pandas as pd


@dataclass(frozen=True)
class AccountConfig:
    start_capital: float = 160000.0
    end_capital: float = 205068.76
    gross_profit_total: float = 171660.74
    gross_loss_total: float = -126591.98
    net_profit_total: float = 45068.76
    total_return_pct: float = 28.17
    ftmo_daily_loss_limit: float = 8000.0
    ftmo_max_loss_limit: float = 16000.0
    ftmo_min_equity: float = 144000.0
    payout_rate: float = 0.80
    period_label: str = "1 januari 2026 t/m 11 mei 2026"


def load_backtest_data() -> Tuple[pd.DataFrame, AccountConfig]:
    config = AccountConfig()
    data = [
        {
            "month": "2026-01",
            "trades": 36,
            "gross_profit": 49328.08,
            "gross_loss": -32749.11,
            "net_result": 16578.97,
            "max_drawdown_eur": -7116.04,
            "max_drawdown_pct": -4.14,
        },
        {
            "month": "2026-02",
            "trades": 31,
            "gross_profit": 34803.20,
            "gross_loss": -34862.30,
            "net_result": -59.09,
            "max_drawdown_eur": -12012.68,
            "max_drawdown_pct": -6.49,
        },
        {
            "month": "2026-03",
            "trades": 28,
            "gross_profit": 38735.05,
            "gross_loss": -30368.55,
            "net_result": 8366.50,
            "max_drawdown_eur": -7976.22,
            "max_drawdown_pct": -4.41,
        },
        {
            "month": "2026-04",
            "trades": 18,
            "gross_profit": 32133.65,
            "gross_loss": -16606.98,
            "net_result": 15526.68,
            "max_drawdown_eur": -10784.65,
            "max_drawdown_pct": -5.79,
        },
        {
            "month": "2026-05",
            "trades": 11,
            "gross_profit": 16660.76,
            "gross_loss": -12005.05,
            "net_result": 4655.70,
            "max_drawdown_eur": -10113.95,
            "max_drawdown_pct": -4.95,
        },
    ]
    return pd.DataFrame(data), config


def calculate_monthly_balances(df: pd.DataFrame, start_capital: float) -> pd.DataFrame:
    report = df.copy()
    start_balances: List[float] = []
    end_balances: List[float] = []
    estimated_min_equity: List[float] = []
    running_balance = start_capital

    for row in report.itertuples(index=False):
        start_balances.append(running_balance)
        running_balance += row.net_result
        end_balances.append(running_balance)
        estimated_min_equity.append(start_balances[-1] - abs(row.max_drawdown_eur))

    report["start_balance"] = start_balances
    report["end_balance"] = end_balances
    report["estimated_min_equity"] = estimated_min_equity
    report["monthly_return_pct"] = (report["net_result"] / report["start_balance"]) * 100
    return report


def calculate_metrics(df: pd.DataFrame, config: AccountConfig) -> Tuple[pd.DataFrame, Dict[str, object]]:
    report = df.copy()
    report["gross_loss_abs"] = report["gross_loss"].abs()
    report["drawdown_abs"] = report["max_drawdown_eur"].abs()
    report["drawdown_pct_abs"] = report["max_drawdown_pct"].abs()
    report["profit_factor"] = report["gross_profit"] / report["gross_loss_abs"]
    report["gross_profit_share_pct"] = (report["gross_profit"] / report["gross_profit"].sum()) * 100
    report["gross_loss_share_pct"] = (report["gross_loss_abs"] / report["gross_loss_abs"].sum()) * 100

    avg_trades = report["trades"].mean()
    median_trades = report["trades"].median()
    report["daily_limit_warning"] = report["drawdown_abs"] >= config.ftmo_daily_loss_limit * 0.80
    report["daily_limit_proxy_breach"] = report["drawdown_abs"] > config.ftmo_daily_loss_limit
    report["max_loss_breach"] = report["drawdown_abs"] > config.ftmo_max_loss_limit
    report["min_equity_breach"] = report["estimated_min_equity"] < config.ftmo_min_equity
    report["ftmo_status"] = report.apply(
        lambda row: "FAIL" if row["max_loss_breach"] or row["min_equity_breach"] else "PASS",
        axis=1,
    )

    report["danger_score"] = (
        (report["net_result"] <= 0).astype(int)
        + (report["profit_factor"] < 1.10).astype(int)
        + (report["drawdown_abs"] > config.ftmo_daily_loss_limit).astype(int)
        + (report["trades"] > avg_trades * 1.15).astype(int)
    )
    report["danger_month"] = report["danger_score"] >= 2
    report["high_quality_month"] = (
        (report["net_result"] > 0)
        & (report["profit_factor"] >= 1.50)
        & (report["drawdown_pct_abs"] < 6.00)
        & (report["trades"] <= median_trades)
    )

    profit_factor_total = config.gross_profit_total / abs(config.gross_loss_total)
    best_month_row = report.loc[report["net_result"].idxmax()]
    worst_month_row = report.loc[report["net_result"].idxmin()]
    highest_drawdown_row = report.loc[report["drawdown_abs"].idxmax()]
    danger_months = report.loc[report["danger_month"], "month"].tolist()
    daily_proxy_breach_months = report.loc[report["daily_limit_proxy_breach"], "month"].tolist()
    high_quality_months = report.loc[report["high_quality_month"], "month"].tolist()

    overall_ftmo_status = "PASS"
    if report["ftmo_status"].eq("FAIL").any():
        overall_ftmo_status = "FAIL"
    elif daily_proxy_breach_months:
        overall_ftmo_status = "PASS WITH DAILY LOSS CAUTION"

    metrics: Dict[str, object] = {
        "period": config.period_label,
        "start_capital": config.start_capital,
        "end_capital": config.end_capital,
        "gross_profit_total": config.gross_profit_total,
        "gross_loss_total": config.gross_loss_total,
        "net_profit_total": config.net_profit_total,
        "total_return_pct": config.total_return_pct,
        "profit_factor_total": profit_factor_total,
        "average_monthly_profit": report["net_result"].mean(),
        "average_trades_per_month": avg_trades,
        "best_month": best_month_row["month"],
        "best_month_net": best_month_row["net_result"],
        "worst_month": worst_month_row["month"],
        "worst_month_net": worst_month_row["net_result"],
        "highest_drawdown_month": highest_drawdown_row["month"],
        "highest_drawdown_eur": highest_drawdown_row["drawdown_abs"],
        "highest_drawdown_pct": highest_drawdown_row["drawdown_pct_abs"],
        "positive_month_ratio": (report["net_result"] > 0).mean(),
        "danger_months": danger_months,
        "daily_proxy_breach_months": daily_proxy_breach_months,
        "high_quality_months": high_quality_months,
        "overall_ftmo_status": overall_ftmo_status,
        "overtrading_signal": "JA" if (report["trades"] > avg_trades * 1.15).any() else "NEE",
    }
    return report, metrics


def calculate_payouts(df: pd.DataFrame, payout_rate: float, start_capital: float) -> pd.DataFrame:
    payout_rows: List[Dict[str, float]] = []
    balance_after_payout = start_capital

    for row in df.itertuples(index=False):
        balance_before_payout = balance_after_payout + row.net_result
        positive_profit = max(row.net_result, 0.0)
        trader_payout = positive_profit * payout_rate
        firm_share = positive_profit - trader_payout
        balance_after_payout = balance_before_payout - trader_payout
        payout_rows.append(
            {
                "month": row.month,
                "gross_profit": row.gross_profit,
                "net_result": row.net_result,
                "trader_payout": trader_payout,
                "firm_share": firm_share,
                "balance_after_payout": balance_after_payout,
            }
        )

    return pd.DataFrame(payout_rows)


def format_eur(value: float) -> str:
    sign = "-" if value < 0 else ""
    return f"{sign}EUR {abs(value):,.2f}"


def format_pct(value: float) -> str:
    return f"{value:.2f}%"


def month_label(month_text: str) -> str:
    year, month = month_text.split("-")
    return f"{month}/{year[-2:]}"


def add_month_highlights(ax: plt.Axes, months: List[str]) -> None:
    labels = [month_label(m) for m in months]
    if "02/26" in labels:
        idx = labels.index("02/26")
        ax.axvspan(idx - 0.45, idx + 0.45, color="#f8d7da", alpha=0.35, zorder=0)
    if "04/26" in labels:
        idx = labels.index("04/26")
        ax.axvspan(idx - 0.45, idx + 0.45, color="#d1e7dd", alpha=0.30, zorder=0)


def add_kpi_cards(ax: plt.Axes, metrics: Dict[str, object]) -> None:
    ax.set_axis_off()
    card_items = [
        ("Startkapitaal", format_eur(metrics["start_capital"]), None),
        ("Eindkapitaal", format_eur(metrics["end_capital"]), None),
        ("Netto winst", format_eur(metrics["net_profit_total"]), None),
        ("Totale return", format_pct(metrics["total_return_pct"]), None),
        ("Bruto winst", format_eur(metrics["gross_profit_total"]), None),
        ("Bruto verlies", format_eur(metrics["gross_loss_total"]), None),
        ("Profit factor", f"{metrics['profit_factor_total']:.2f}", None),
        ("Gem. maandwinst", format_eur(metrics["average_monthly_profit"]), None),
        ("Beste maand", f"{metrics['best_month']} | {format_eur(metrics['best_month_net'])}", None),
        ("Slechtste maand", f"{metrics['worst_month']} | {format_eur(metrics['worst_month_net'])}", None),
        (
            "Hoogste drawdown",
            f"{format_eur(-metrics['highest_drawdown_eur'])} | {format_pct(metrics['highest_drawdown_pct'])}",
            None,
        ),
        ("FTMO status", str(metrics["overall_ftmo_status"]), None),
    ]

    cols = 4
    card_w = 0.235
    card_h = 0.36
    x_gap = 0.015
    y_positions = [0.56, 0.10, -0.36]

    for idx, (title, value, _) in enumerate(card_items):
        row = idx // cols
        col = idx % cols
        x0 = col * (card_w + x_gap)
        y0 = y_positions[row]
        if title == "FTMO status":
            face = "#fff3cd" if "CAUTION" in value else "#d1e7dd"
        elif title in {"Bruto verlies", "Hoogste drawdown", "Slechtste maand"}:
            face = "#f8d7da"
        else:
            face = "#ffffff"
        box = FancyBboxPatch(
            (x0, y0),
            card_w,
            card_h,
            boxstyle="round,pad=0.012,rounding_size=0.02",
            linewidth=1.0,
            edgecolor="#d0d7de",
            facecolor=face,
            transform=ax.transAxes,
            clip_on=False,
        )
        ax.add_patch(box)
        ax.text(
            x0 + 0.015,
            y0 + 0.24,
            title,
            transform=ax.transAxes,
            fontsize=10,
            fontweight="bold",
            color="#3b4252",
            va="center",
        )
        ax.text(
            x0 + 0.015,
            y0 + 0.10,
            value,
            transform=ax.transAxes,
            fontsize=14,
            fontweight="bold",
            color="#111827",
            va="center",
        )


def style_axes(ax: plt.Axes, title: str) -> None:
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left")
    ax.grid(True, axis="y", linestyle="--", alpha=0.25)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def create_dashboard(
    monthly_report: pd.DataFrame,
    payout_report: pd.DataFrame,
    metrics: Dict[str, object],
    config: AccountConfig,
    output_path: str = "ftmo_dashboard.png",
) -> None:
    plt.rcParams["font.family"] = "DejaVu Sans"
    months = [month_label(month) for month in monthly_report["month"]]

    fig = plt.figure(figsize=(24, 16), facecolor="#f4f6f8")
    gs = fig.add_gridspec(4, 4, height_ratios=[1.15, 1.15, 1.15, 1.6], hspace=0.52, wspace=0.28)
    ax_kpi = fig.add_subplot(gs[0, :])
    ax_equity = fig.add_subplot(gs[1, 0:2])
    ax_net = fig.add_subplot(gs[1, 2])
    ax_gross = fig.add_subplot(gs[1, 3])
    ax_drawdown = fig.add_subplot(gs[2, 0])
    ax_pf = fig.add_subplot(gs[2, 1])
    ax_cum = fig.add_subplot(gs[2, 2:4])
    ax_table = fig.add_subplot(gs[3, 0:2])
    ax_risk = fig.add_subplot(gs[3, 2])
    ax_payout = fig.add_subplot(gs[3, 3])

    fig.suptitle(
        "FTMO XAUUSD Dashboard | EUR 160.000 account",
        fontsize=22,
        fontweight="bold",
        x=0.02,
        ha="left",
        y=0.985,
    )
    fig.text(0.02, 0.956, f"Periode: {metrics['period']}", fontsize=11, color="#4b5563")
    fig.text(
        0.98,
        0.956,
        "Proxy-opmerking: daily loss kan met maanddata alleen indicatief worden gemarkeerd.",
        fontsize=10,
        color="#7c2d12",
        ha="right",
    )

    add_kpi_cards(ax_kpi, metrics)

    add_month_highlights(ax_equity, list(monthly_report["month"]))
    style_axes(ax_equity, "Equity Curve En FTMO Limits")
    ax_equity.plot(months, monthly_report["start_balance"], marker="o", linewidth=1.8, color="#64748b", label="Start equity")
    ax_equity.plot(months, monthly_report["end_balance"], marker="o", linewidth=2.6, color="#0f766e", label="Eind equity")
    ax_equity.plot(
        months,
        monthly_report["estimated_min_equity"],
        marker="o",
        linewidth=2.0,
        linestyle="--",
        color="#b91c1c",
        label="Geschatte laagste equity",
    )
    ax_equity.axhline(config.ftmo_min_equity, color="#dc2626", linestyle="-", linewidth=1.8, label="FTMO minimum equity")
    ax_equity.fill_between(
        months,
        config.ftmo_min_equity,
        min(monthly_report["estimated_min_equity"].min(), config.ftmo_min_equity),
        color="#fee2e2",
        alpha=0.35,
    )
    ax_equity.set_ylabel("EUR")
    ax_equity.legend(loc="upper left", fontsize=9)

    add_month_highlights(ax_net, list(monthly_report["month"]))
    style_axes(ax_net, "Maandelijkse Netto PnL")
    net_colors = ["#15803d" if value >= 0 else "#dc2626" for value in monthly_report["net_result"]]
    ax_net.bar(months, monthly_report["net_result"], color=net_colors)
    ax_net.axhline(0, color="#1f2937", linewidth=1.0)
    ax_net.set_ylabel("EUR")

    add_month_highlights(ax_gross, list(monthly_report["month"]))
    style_axes(ax_gross, "Bruto Winst Vs Verlies")
    x_idx = range(len(months))
    ax_gross.bar([x - 0.18 for x in x_idx], monthly_report["gross_profit"], width=0.36, color="#16a34a", label="Bruto winst")
    ax_gross.bar([x + 0.18 for x in x_idx], monthly_report["gross_loss_abs"], width=0.36, color="#ef4444", label="Bruto verlies")
    ax_gross.set_xticks(list(x_idx))
    ax_gross.set_xticklabels(months)
    ax_gross.set_ylabel("EUR")
    ax_gross.legend(fontsize=9)

    add_month_highlights(ax_drawdown, list(monthly_report["month"]))
    style_axes(ax_drawdown, "Max Drawdown En Daily Warning")
    ax_drawdown.axhspan(0, config.ftmo_daily_loss_limit * 0.80, color="#dcfce7", alpha=0.35)
    ax_drawdown.axhspan(
        config.ftmo_daily_loss_limit * 0.80,
        config.ftmo_daily_loss_limit,
        color="#fef3c7",
        alpha=0.45,
    )
    ax_drawdown.axhspan(
        config.ftmo_daily_loss_limit,
        config.ftmo_max_loss_limit,
        color="#fee2e2",
        alpha=0.35,
    )
    dd_colors = ["#ef4444" if breach else "#f59e0b" if warn else "#2563eb" for breach, warn in zip(
        monthly_report["daily_limit_proxy_breach"], monthly_report["daily_limit_warning"]
    )]
    ax_drawdown.bar(months, monthly_report["drawdown_abs"], color=dd_colors)
    ax_drawdown.axhline(config.ftmo_daily_loss_limit, color="#b45309", linestyle="--", linewidth=1.5, label="Daily loss limit")
    ax_drawdown.axhline(config.ftmo_max_loss_limit, color="#991b1b", linestyle="-", linewidth=1.5, label="Max loss limit")
    ax_drawdown.set_ylabel("EUR")
    ax_drawdown.legend(fontsize=8, loc="upper left")

    add_month_highlights(ax_pf, list(monthly_report["month"]))
    style_axes(ax_pf, "Profit Factor Per Maand")
    pf_colors = ["#dc2626" if value < 1.0 else "#16a34a" if value >= 1.5 else "#2563eb" for value in monthly_report["profit_factor"]]
    ax_pf.bar(months, monthly_report["profit_factor"], color=pf_colors)
    ax_pf.axhline(1.0, color="#dc2626", linestyle="--", linewidth=1.3, label="Break-even")
    ax_pf.axhline(1.5, color="#15803d", linestyle=":", linewidth=1.3, label="Sterke kwaliteit")
    ax_pf.set_ylabel("PF")
    ax_pf.legend(fontsize=8, loc="upper left")

    add_month_highlights(ax_cum, list(monthly_report["month"]))
    style_axes(ax_cum, "Cumulative Profit Curve")
    cumulative = monthly_report["net_result"].cumsum()
    ax_cum.plot(months, cumulative, marker="o", linewidth=2.8, color="#1d4ed8", label="Cumulatieve netto winst")
    ax_cum.fill_between(months, cumulative, 0, alpha=0.18, color="#93c5fd")
    ax_cum.axhline(0, color="#1f2937", linewidth=1.0)
    ax_cum.set_ylabel("EUR")
    ax_cum.legend(fontsize=9, loc="upper left")

    ax_table.axis("off")
    ax_table.set_title("Maandelijkse Resultaten", fontsize=12, fontweight="bold", loc="left")
    display_cols = [
        "month",
        "trades",
        "start_balance",
        "end_balance",
        "monthly_return_pct",
        "gross_profit",
        "gross_loss",
        "net_result",
        "drawdown_abs",
        "profit_factor",
        "ftmo_status",
    ]
    table_df = monthly_report[display_cols].copy()
    table_df["start_balance"] = table_df["start_balance"].map(format_eur)
    table_df["end_balance"] = table_df["end_balance"].map(format_eur)
    table_df["monthly_return_pct"] = table_df["monthly_return_pct"].map(format_pct)
    table_df["gross_profit"] = table_df["gross_profit"].map(format_eur)
    table_df["gross_loss"] = table_df["gross_loss"].map(format_eur)
    table_df["net_result"] = table_df["net_result"].map(format_eur)
    table_df["drawdown_abs"] = table_df["drawdown_abs"].map(lambda x: format_eur(-x))
    table_df["profit_factor"] = table_df["profit_factor"].map(lambda x: f"{x:.2f}")
    table = ax_table.table(
        cellText=table_df.values,
        colLabels=[
            "Maand",
            "Trades",
            "Start",
            "Eind",
            "Return",
            "Bruto winst",
            "Bruto verlies",
            "Netto",
            "DD",
            "PF",
            "Status",
        ],
        loc="center",
        cellLoc="center",
        colLoc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8.5)
    table.scale(1.10, 1.45)
    for (row, col), cell in table.get_celld().items():
        cell.set_edgecolor("#d1d5db")
        if row == 0:
            cell.set_facecolor("#e5e7eb")
            cell.set_text_props(weight="bold")
        elif col == 10:
            cell.set_facecolor("#dcfce7")

    ax_risk.axis("off")
    ax_risk.set_title("Risk Dashboard", fontsize=12, fontweight="bold", loc="left")
    danger_text = ", ".join(metrics["danger_months"]) if metrics["danger_months"] else "Geen"
    daily_proxy_text = ", ".join(metrics["daily_proxy_breach_months"]) if metrics["daily_proxy_breach_months"] else "Geen"
    high_quality_text = ", ".join(metrics["high_quality_months"]) if metrics["high_quality_months"] else "Geen"
    risk_lines = [
        f"FTMO minimum equity: {format_eur(config.ftmo_min_equity)}",
        f"FTMO daily loss limit: {format_eur(config.ftmo_daily_loss_limit)}",
        f"FTMO max loss limit: {format_eur(config.ftmo_max_loss_limit)}",
        f"Overall status: {metrics['overall_ftmo_status']}",
        f"Gevaarlijke maanden: {danger_text}",
        f"Daily-loss proxy waarschuwing: {daily_proxy_text}",
        f"Risk month: 2026-02",
        f"High-quality month: {high_quality_text}",
        f"Overtrading signaal: {metrics['overtrading_signal']}",
        "April is kwalitatief sterk, maar de drawdown blijft te hoog voor FTMO-comfort.",
    ]
    y = 0.92
    for line in risk_lines:
        ax_risk.text(0.02, y, line, fontsize=10.5, color="#1f2937", transform=ax_risk.transAxes, va="top")
        y -= 0.09

    ax_payout.axis("off")
    ax_payout.set_title("Payout Simulation", fontsize=12, fontweight="bold", loc="left")
    payout_display = payout_report.copy()
    payout_display["gross_profit"] = payout_display["gross_profit"].map(format_eur)
    payout_display["net_result"] = payout_display["net_result"].map(format_eur)
    payout_display["trader_payout"] = payout_display["trader_payout"].map(format_eur)
    payout_display["firm_share"] = payout_display["firm_share"].map(format_eur)
    payout_display["balance_after_payout"] = payout_display["balance_after_payout"].map(format_eur)
    payout_table = ax_payout.table(
        cellText=payout_display[["month", "net_result", "trader_payout", "firm_share", "balance_after_payout"]].values,
        colLabels=["Maand", "Netto", "Trader payout", "Firm share", "Balance after payout"],
        loc="center",
        cellLoc="center",
        colLoc="center",
    )
    payout_table.auto_set_font_size(False)
    payout_table.set_fontsize(8.4)
    payout_table.scale(1.18, 1.55)
    for (row, col), cell in payout_table.get_celld().items():
        cell.set_edgecolor("#d1d5db")
        if row == 0:
            cell.set_facecolor("#e5e7eb")
            cell.set_text_props(weight="bold")

    plt.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def print_expert_summary(monthly_report: pd.DataFrame, metrics: Dict[str, object], config: AccountConfig) -> None:
    dangerous_months = ", ".join(metrics["danger_months"]) if metrics["danger_months"] else "geen"
    daily_proxy_breach_months = ", ".join(metrics["daily_proxy_breach_months"]) if metrics["daily_proxy_breach_months"] else "geen"

    print("=" * 96)
    print("PROFESSIONELE FTMO-ANALYSE | XAUUSD | EUR 160.000 ACCOUNT")
    print("=" * 96)
    print(f"Periode: {metrics['period']}")
    print(f"Startkapitaal: {format_eur(config.start_capital)}")
    print(f"Eindkapitaal: {format_eur(config.end_capital)}")
    print(f"Netto winst: {format_eur(config.net_profit_total)} | Return: {format_pct(config.total_return_pct)}")
    print(f"Profit factor totaal: {metrics['profit_factor_total']:.2f}")
    print(
        f"Bruto winst vs bruto verlies: {format_eur(config.gross_profit_total)} tegenover "
        f"{format_eur(config.gross_loss_total)}"
    )
    print(
        f"Hoogste drawdown: {format_eur(-metrics['highest_drawdown_eur'])} "
        f"in {metrics['highest_drawdown_month']} ({format_pct(metrics['highest_drawdown_pct'])})"
    )
    print()
    print("Analyse:")
    print(
        f"- Totale performance is sterk: {format_pct(config.total_return_pct)} netto in iets meer dan vier maanden "
        f"op een FTMO-account is commercieel aantrekkelijk."
    )
    print(
        f"- De maandelijkse consistentie is redelijk, maar niet stabiel: 4 van de 5 maanden zijn positief "
        f"({metrics['positive_month_ratio'] * 100:.0f}%)."
    )
    print(
        f"- De sterkste maand is {metrics['best_month']} met {format_eur(metrics['best_month_net'])}; "
        f"de zwakste maand is {metrics['worst_month']} met {format_eur(metrics['worst_month_net'])}."
    )
    print(
        f"- Profit factor van {metrics['profit_factor_total']:.2f} is winstgevend, maar voor FTMO-live nog niet ruim genoeg "
        f"om zware drawdown-maanden comfortabel op te vangen."
    )
    print(
        f"- Grootste risico zit in drawdown-clusters: proxy-waarschuwingen boven de daily limit liggen in {daily_proxy_breach_months}."
    )
    print(
        f"- Er is lichte overtradingdruk zichtbaar: januari en februari hebben duidelijk meer trades dan april en mei, "
        f"terwijl april juist de beste kwaliteit per trade laat zien."
    )
    print(f"- Gevaarlijke maanden volgens de risicoscore: {dangerous_months}.")
    print()
    print("Expert conclusie:")
    print(
        "- Live geschikt? Voor een kleine live pilot of demo-forward test: ja. Voor direct agressief FTMO-live capital: nog niet zonder extra risk filters."
    )
    print(
        "- Is de risk/reward gezond? Matig tot goed. De strategie verdient geld, maar laat te veel ruimte voor diepe terugvallen per maand."
    )
    print(
        "- Is februari een probleem? Ja. Februari is het duidelijkste signaal van fragiliteit: negatieve netto maand, PF rond 1.00 en de hoogste drawdown."
    )
    print(
        "- Is april het beste voorbeeld? Ja, kwalitatief wel: minder trades, hoge PF en sterke netto output. Nee, nog niet perfect: de proxy-drawdown blijft boven de daily comfortzone."
    )
    print(
        "- Moet de bot minder trades nemen? Ja. De data ondersteunt minder maar selectiever traden, vooral buiten high-conviction sessies."
    )
    print(
        "- Geschiktheid voor FTMO? De max-loss regel wordt gehaald, maar de daily-loss discipline is met deze maanddata niet hard bewezen en op proxy-basis te kwetsbaar."
    )
    print()
    print("Aanbevolen filters en verbeteringen:")
    print("- Volatility filter: alleen handelen boven een minimale gerealiseerde intraday volatiliteit.")
    print("- ADX filter: vermijd entries wanneer ADX onder trenddrempel blijft, zodat chop/range wordt onderdrukt.")
    print("- ATR minimum filter: geen trades wanneer ATR onder de historische drempel ligt.")
    print(f"- Max trades per dag: 2.")
    print(f"- Max trades per sessie: 1 tot 2, afhankelijk van London of New York.")
    print("- Pause na 2 verliezen: stop trading voor de rest van de sessie of dag.")
    print("- Daily profit lock: na een vooraf ingestelde dagwinst geen nieuwe entries meer.")
    print("- Weekly profit lock: bescherm sterke weken tegen late give-back trades.")
    print("- Monthly profit lock: verlaag size of stop na het halen van maanddoel.")
    print("- Minder traden in chop/range markets: combineer regime-filter met session filter.")
    print("- Betere trade suppression: blokkeer direct her-entry na stop-out zonder nieuw structuur- of momentum-signaal.")
    print("=" * 96)


def main() -> None:
    base_df, config = load_backtest_data()
    monthly_balances = calculate_monthly_balances(base_df, config.start_capital)
    monthly_report, metrics = calculate_metrics(monthly_balances, config)
    payout_report = calculate_payouts(monthly_report, config.payout_rate, config.start_capital)

    export_report = monthly_report[
        [
            "month",
            "trades",
            "start_balance",
            "end_balance",
            "monthly_return_pct",
            "gross_profit",
            "gross_loss",
            "net_result",
            "drawdown_abs",
            "drawdown_pct_abs",
            "profit_factor",
            "estimated_min_equity",
            "daily_limit_warning",
            "daily_limit_proxy_breach",
            "danger_month",
            "high_quality_month",
            "ftmo_status",
        ]
    ].copy()
    export_report = export_report.rename(
        columns={
            "month": "month",
            "trades": "trades",
            "start_balance": "start_capital_month",
            "end_balance": "end_capital_month",
            "monthly_return_pct": "monthly_return_pct",
            "gross_profit": "gross_profit",
            "gross_loss": "gross_loss",
            "net_result": "net_result",
            "drawdown_abs": "max_drawdown_eur_abs",
            "drawdown_pct_abs": "max_drawdown_pct_abs",
            "profit_factor": "profit_factor",
            "estimated_min_equity": "estimated_min_equity",
            "daily_limit_warning": "daily_loss_warning",
            "daily_limit_proxy_breach": "daily_loss_proxy_breach",
            "danger_month": "danger_month",
            "high_quality_month": "high_quality_month",
            "ftmo_status": "status",
        }
    )
    export_report = export_report.round(2)
    payout_export = payout_report.round(2)

    export_report.to_csv("ftmo_monthly_report.csv", index=False)
    payout_export.to_csv("ftmo_payout_simulation.csv", index=False)
    create_dashboard(monthly_report, payout_report, metrics, config, output_path="ftmo_dashboard.png")
    print_expert_summary(monthly_report, metrics, config)


if __name__ == "__main__":
    main()
