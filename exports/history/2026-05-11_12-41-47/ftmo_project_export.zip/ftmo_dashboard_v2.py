from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd

try:
    import seaborn as sns
except ImportError:  # pragma: no cover
    sns = None


@dataclass(frozen=True)
class FTMOConfig:
    start_capital: float = 160000.0
    end_capital: float = 205068.76
    net_profit: float = 45068.76
    gross_profit: float = 171660.74
    gross_loss: float = -126591.98
    total_return_pct: float = 28.17
    ftmo_daily_loss_limit: float = 8000.0
    ftmo_max_loss_limit: float = 16000.0
    ftmo_min_equity: float = 144000.0
    payout_rate: float = 0.80
    analysis_start: str = "2026-01-01"
    analysis_end: str = "2026-05-11"
    dashboard_file: str = "ftmo_dashboard_v2.png"
    trade_file: str = "ftmo_trade_analytics.csv"
    risk_file: str = "ftmo_risk_analysis.csv"
    drawdown_file: str = "ftmo_drawdown_analysis.csv"
    efficiency_file: str = "ftmo_efficiency_report.csv"
    payout_file: str = "ftmo_payout_simulation.csv"


PALETTE = {
    "bg": "#071018",
    "panel": "#0d1823",
    "card": "#101d2a",
    "grid": "#243647",
    "text": "#e7edf4",
    "muted": "#94a8bc",
    "green": "#2dd4bf",
    "green_soft": "#12352d",
    "amber": "#fbbf24",
    "amber_soft": "#3a2b0b",
    "red": "#fb7185",
    "red_soft": "#3d1520",
    "blue": "#60a5fa",
    "blue_soft": "#13263b",
    "cyan": "#22d3ee",
    "magenta": "#c084fc",
    "white": "#f8fafc",
}


def format_eur(value: float) -> str:
    sign = "-" if value < 0 else ""
    return f"{sign}EUR {abs(value):,.2f}"


def format_pct(value: float) -> str:
    return f"{value:.2f}%"


def format_plain(value: float) -> str:
    return f"{value:,.2f}"


def month_tag(value: pd.Timestamp | str) -> str:
    ts = pd.Timestamp(value)
    return ts.strftime("%Y-%m")


def month_label(value: str) -> str:
    return pd.Timestamp(value).strftime("%b %y").upper()


def style_axes(ax: plt.Axes, title: str, subtitle: str | None = None) -> None:
    ax.set_facecolor(PALETTE["panel"])
    for spine in ax.spines.values():
        spine.set_color(PALETTE["grid"])
        spine.set_linewidth(1.0)
    ax.tick_params(colors=PALETTE["muted"], labelsize=9)
    ax.grid(True, color=PALETTE["grid"], alpha=0.35, linewidth=0.8)
    ax.set_title(title, color=PALETTE["white"], fontsize=12, fontweight="bold", loc="left", pad=10)
    if subtitle:
        ax.text(
            0.0,
            1.02,
            subtitle,
            transform=ax.transAxes,
            color=PALETTE["muted"],
            fontsize=8.5,
            va="bottom",
        )


def euro_formatter() -> FuncFormatter:
    return FuncFormatter(lambda x, pos: f"EUR {x:,.0f}")


def load_monthly_core_data() -> pd.DataFrame:
    data = [
        ["2026-01", 36, 49328.08, -32749.11, 16578.97, -7116.04, -4.14],
        ["2026-02", 31, 34803.20, -34862.30, -59.09, -12012.68, -6.49],
        ["2026-03", 28, 38735.05, -30368.55, 8366.50, -7976.22, -4.41],
        ["2026-04", 18, 32133.65, -16606.98, 15526.68, -10784.65, -5.79],
        ["2026-05", 11, 16660.76, -12005.05, 4655.70, -10113.95, -4.95],
    ]
    columns = [
        "month",
        "trades",
        "gross_profit",
        "gross_loss",
        "net_result",
        "max_drawdown_eur",
        "max_drawdown_pct",
    ]
    return pd.DataFrame(data, columns=columns)


def load_reference_monthly_metrics(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()

    ref = pd.read_csv(path)
    keep = [
        "month",
        "win_rate",
        "profit_factor",
        "avg_trade",
        "best_trade",
        "worst_trade",
        "tp_hits",
        "sl_hits",
        "timeout_hits",
    ]
    missing = [col for col in keep if col not in ref.columns]
    if missing:
        return pd.DataFrame()
    ref = ref[keep].copy()
    rename_map = {col: f"{col}_ref" for col in keep if col != "month"}
    return ref.rename(columns=rename_map)


def load_daily_risk_report(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Missing daily risk report: {path}")

    daily = pd.read_csv(path)
    daily["date"] = pd.to_datetime(daily["date"])
    daily["month"] = daily["date"].dt.strftime("%Y-%m")
    return daily.sort_values("date").reset_index(drop=True)


def prepare_monthly_dataset(config: FTMOConfig, reference_path: Path) -> pd.DataFrame:
    monthly = load_monthly_core_data()
    monthly["gross_loss_abs"] = monthly["gross_loss"].abs()
    monthly["drawdown_abs"] = monthly["max_drawdown_eur"].abs()
    monthly["drawdown_pct_abs"] = monthly["max_drawdown_pct"].abs()
    monthly["profit_factor"] = monthly["gross_profit"] / monthly["gross_loss_abs"]
    monthly["net_profit_margin"] = (monthly["net_result"] / monthly["gross_profit"]) * 100.0

    start_balances: List[float] = []
    end_balances: List[float] = []
    estimated_min_equity: List[float] = []
    running_balance = config.start_capital
    for row in monthly.itertuples(index=False):
        start_balances.append(running_balance)
        running_balance += row.net_result
        end_balances.append(running_balance)
        estimated_min_equity.append(start_balances[-1] - row.drawdown_abs)

    monthly["start_balance"] = start_balances
    monthly["end_balance"] = end_balances
    monthly["estimated_min_equity"] = estimated_min_equity
    monthly["monthly_return_pct"] = monthly["net_result"] / monthly["start_balance"] * 100.0
    monthly["recovery_factor_month"] = monthly["net_result"] / monthly["drawdown_abs"]
    monthly["trade_efficiency_eur"] = monthly["net_result"] / monthly["trades"]
    monthly["return_per_drawdown"] = monthly["monthly_return_pct"] / monthly["drawdown_pct_abs"]

    ref = load_reference_monthly_metrics(reference_path)
    monthly = monthly.merge(ref, on="month", how="left")
    for col in ["win_rate_ref", "best_trade_ref", "worst_trade_ref"]:
        if col not in monthly.columns:
            monthly[col] = np.nan

    fallback_wins = np.round(monthly["trades"] * 0.42).astype(int).clip(lower=1)
    monthly["wins"] = np.where(
        monthly["win_rate_ref"].notna(),
        np.round(monthly["trades"] * monthly["win_rate_ref"] / 100.0),
        fallback_wins,
    )
    monthly["wins"] = monthly["wins"].astype(int).clip(lower=1)
    monthly["losses"] = (monthly["trades"] - monthly["wins"]).clip(lower=1)
    monthly["win_rate"] = monthly["wins"] / monthly["trades"] * 100.0
    monthly["loss_rate"] = 100.0 - monthly["win_rate"]
    monthly["average_winner"] = monthly["gross_profit"] / monthly["wins"]
    monthly["average_loser"] = monthly["gross_loss_abs"] / monthly["losses"]
    monthly["risk_reward_ratio"] = monthly["average_winner"] / monthly["average_loser"]
    monthly["largest_winner"] = monthly["best_trade_ref"].fillna(monthly["average_winner"] * 1.85)
    monthly["largest_loser"] = monthly["worst_trade_ref"].fillna(-monthly["average_loser"] * 1.40)
    monthly["business_days"] = monthly["month"].map(count_business_days_in_month)
    monthly["trades_per_day"] = monthly["trades"] / monthly["business_days"]

    avg_trades = monthly["trades"].mean()
    monthly["overtrading_flag"] = (
        (monthly["trades"] > avg_trades * 1.12)
        & ((monthly["profit_factor"] < 1.10) | (monthly["trade_efficiency_eur"] < monthly["trade_efficiency_eur"].median()))
    )
    monthly["quality_month_flag"] = (
        (monthly["profit_factor"] >= 1.50)
        & (monthly["trade_efficiency_eur"] >= monthly["trade_efficiency_eur"].quantile(0.70))
        & (monthly["trades"] <= monthly["trades"].median())
    )
    monthly["stress_month_flag"] = (
        (monthly["profit_factor"] <= 1.05)
        | (monthly["drawdown_abs"] >= monthly["drawdown_abs"].quantile(0.80))
        | (monthly["net_result"] <= 0)
    )
    return monthly


def count_business_days_in_month(month: str) -> int:
    start = pd.Timestamp(f"{month}-01")
    end = min(start + pd.offsets.MonthEnd(0), pd.Timestamp("2026-05-11"))
    return max(len(pd.bdate_range(start, end)), 1)


def generate_scaled_values(
    total: float,
    count: int,
    anchor: float,
    rng: np.random.Generator,
    sigma: float,
) -> np.ndarray:
    if count <= 0:
        return np.array([], dtype=float)
    if count == 1:
        return np.array([float(total)], dtype=float)

    anchor = float(min(max(anchor, total * 0.12 / count), total * 0.70))
    raw = rng.lognormal(mean=0.0, sigma=sigma, size=count - 1)
    remaining = max(total - anchor, total * 0.25)
    scaled = raw / raw.sum() * remaining
    values = np.append(scaled, anchor)
    values *= total / values.sum()
    return values


def build_trade_pattern(wins: int, losses: int, month: str, rng: np.random.Generator) -> List[str]:
    base = ["W"] * wins + ["L"] * losses
    if month == "2026-02":
        losses_first = ["L"] * min(losses, int(np.ceil(losses * 0.65)))
        residual = ["W"] * wins + ["L"] * (losses - len(losses_first))
        rng.shuffle(residual)
        return losses_first + residual
    if month == "2026-04":
        wins_first = ["W"] * min(wins, int(np.ceil(wins * 0.60)))
        residual = ["W"] * (wins - len(wins_first)) + ["L"] * losses
        rng.shuffle(residual)
        return wins_first + residual
    if month == "2026-01":
        early_chop = ["L", "W", "L", "L", "W", "L"]
        residual = base.copy()
        for marker in early_chop:
            if marker in residual:
                residual.remove(marker)
        rng.shuffle(residual)
        return early_chop + residual
    rng.shuffle(base)
    return base


def create_synthetic_trade_book(monthly: pd.DataFrame, config: FTMOConfig) -> pd.DataFrame:
    rng = np.random.default_rng(42)
    trades: List[Dict[str, float | str | int | pd.Timestamp]] = []
    running_equity = config.start_capital
    trade_id = 1

    for row in monthly.itertuples(index=False):
        start = pd.Timestamp(f"{row.month}-01")
        end = min(start + pd.offsets.MonthEnd(0), pd.Timestamp(config.analysis_end))
        trade_days = pd.bdate_range(start, end)
        if len(trade_days) == 0:
            trade_days = pd.DatetimeIndex([start])

        win_values = generate_scaled_values(
            total=row.gross_profit,
            count=int(row.wins),
            anchor=float(row.largest_winner),
            rng=rng,
            sigma=0.38,
        )
        loss_values = -generate_scaled_values(
            total=row.gross_loss_abs,
            count=int(row.losses),
            anchor=abs(float(row.largest_loser)),
            rng=rng,
            sigma=0.30,
        )

        win_values = np.sort(win_values)[::-1]
        loss_values = np.sort(loss_values)
        pattern = build_trade_pattern(int(row.wins), int(row.losses), row.month, rng)
        chosen_days = np.linspace(0, len(trade_days) - 1, num=int(row.trades), dtype=int)

        win_idx = 0
        loss_idx = 0
        month_pnls: List[float] = []
        for idx, outcome in enumerate(pattern):
            if outcome == "W":
                pnl = float(win_values[win_idx])
                win_idx += 1
            else:
                pnl = float(loss_values[loss_idx])
                loss_idx += 1
            month_pnls.append(pnl)

        adjustment = row.net_result - sum(month_pnls)
        if month_pnls:
            month_pnls[-1] += adjustment

        for idx, pnl in enumerate(month_pnls):
            trade_date = trade_days[chosen_days[idx]]
            running_equity += pnl
            trades.append(
                {
                    "trade_id": trade_id,
                    "month": row.month,
                    "trade_date": trade_date,
                    "pnl": pnl,
                    "result_type": "WIN" if pnl > 0 else "LOSS",
                    "cumulative_profit": running_equity - config.start_capital,
                    "equity": running_equity,
                    "rolling_month_profit_factor": row.profit_factor,
                    "session_placeholder": ["London", "New York", "Asia"][trade_id % 3],
                    "regime_placeholder": infer_regime_label(row.month),
                }
            )
            trade_id += 1

    trades_df = pd.DataFrame(trades)
    trades_df["trade_date"] = pd.to_datetime(trades_df["trade_date"])
    trades_df["trade_return_pct"] = trades_df["pnl"] / trades_df["equity"].shift(fill_value=config.start_capital) * 100.0
    trades_df["expectancy_curve"] = trades_df["pnl"].expanding().mean()
    trades_df["rolling_profit_factor"] = calculate_rolling_profit_factor(trades_df["pnl"], window=10)
    trades_df["streak"] = calculate_streaks(trades_df["pnl"])
    return trades_df


def infer_regime_label(month: str) -> str:
    mapping = {
        "2026-01": "Trend continuation with volatility spikes",
        "2026-02": "Range/chop with false expansion",
        "2026-03": "Mixed trend and retracement",
        "2026-04": "Clean trend expansion",
        "2026-05": "Moderate expansion with lower activity",
    }
    return mapping.get(month, "Unclassified regime")


def calculate_rolling_profit_factor(pnl: pd.Series, window: int = 10) -> pd.Series:
    pf_values = []
    for idx in range(len(pnl)):
        sample = pnl.iloc[max(0, idx - window + 1) : idx + 1]
        gross_profit = sample[sample > 0].sum()
        gross_loss = abs(sample[sample < 0].sum())
        if gross_loss == 0:
            pf_values.append(np.nan)
        else:
            pf_values.append(gross_profit / gross_loss)
    return pd.Series(pf_values, index=pnl.index)


def calculate_streaks(pnl: pd.Series) -> pd.Series:
    streaks = []
    current = 0
    previous_sign = 0
    for value in pnl:
        sign = 1 if value > 0 else -1
        if sign == previous_sign:
            current += sign
        else:
            current = sign
        previous_sign = sign
        streaks.append(current)
    return pd.Series(streaks, index=pnl.index)


def max_consecutive(trades: pd.Series, positive: bool) -> int:
    best = 0
    current = 0
    for value in trades:
        condition = value > 0 if positive else value < 0
        if condition:
            current += 1
            best = max(best, current)
        else:
            current = 0
    return best


def compute_drawdown_analysis(daily: pd.DataFrame, config: FTMOConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
    report = daily.copy()
    report["end_balance"] = report["start_balance"] + report["daily_pnl"]
    report["peak_balance"] = report["end_balance"].cummax()
    report["equity_mark"] = np.minimum(report["lowest_equity"], report["end_balance"])
    report["underwater_eur"] = np.minimum(report["equity_mark"] - report["peak_balance"], 0.0)
    report["underwater_pct"] = report["underwater_eur"] / report["peak_balance"] * 100.0
    report["drawdown_duration_days"] = compute_underwater_duration(report["underwater_eur"])
    report["rolling_drawdown_pct_5d"] = report["underwater_pct"].rolling(5, min_periods=1).min()
    report["buffer_to_min_equity"] = report["lowest_equity"] - config.ftmo_min_equity
    report["daily_limit_utilization"] = report["daily_drawdown"] / config.ftmo_daily_loss_limit
    report["max_loss_utilization"] = abs(report["underwater_eur"]) / config.ftmo_max_loss_limit
    report["ftmo_zone"] = pd.cut(
        report["daily_limit_utilization"],
        bins=[-np.inf, 0.50, 0.80, np.inf],
        labels=["SAFE", "WARNING", "DANGER"],
    ).astype(str)
    report["weekday"] = report["date"].dt.day_name().str[:3]
    report["day"] = report["date"].dt.day

    episodes = build_drawdown_episodes(report)
    report["episode_id"] = episodes["episode_id"]
    summary = summarize_drawdown_monthly(report)
    return report, summary


def compute_underwater_duration(underwater: pd.Series) -> List[int]:
    durations: List[int] = []
    current = 0
    for value in underwater:
        if value < 0:
            current += 1
        else:
            current = 0
        durations.append(current)
    return durations


def build_drawdown_episodes(report: pd.DataFrame) -> pd.DataFrame:
    episode_ids: List[int] = []
    current_episode = 0
    active = False
    for value in report["underwater_eur"]:
        if value < 0 and not active:
            current_episode += 1
            active = True
        elif value >= 0:
            active = False
        episode_ids.append(current_episode if value < 0 else 0)

    episode_df = pd.DataFrame({"episode_id": episode_ids})
    return episode_df


def summarize_drawdown_monthly(report: pd.DataFrame) -> pd.DataFrame:
    monthly = (
        report.groupby("month")
        .agg(
            max_daily_drawdown=("daily_drawdown", "max"),
            avg_daily_drawdown=("daily_drawdown", "mean"),
            max_underwater_eur=("underwater_eur", "min"),
            max_underwater_pct=("underwater_pct", "min"),
            longest_duration=("drawdown_duration_days", "max"),
            min_daily_buffer=("remaining_daily_buffer", "min"),
            warning_days=("ftmo_zone", lambda s: int((s == "WARNING").sum())),
            danger_days=("ftmo_zone", lambda s: int((s == "DANGER").sum())),
        )
        .reset_index()
    )
    monthly["recovery_factor_proxy"] = np.where(
        monthly["max_underwater_eur"] < 0,
        load_monthly_core_data()["net_result"].values / abs(monthly["max_underwater_eur"].values),
        np.nan,
    )
    return monthly


def compute_trade_analytics(trades: pd.DataFrame, monthly: pd.DataFrame, config: FTMOConfig) -> Dict[str, float | str]:
    total_trades = int(len(trades))
    winners = trades.loc[trades["pnl"] > 0, "pnl"]
    losers = trades.loc[trades["pnl"] < 0, "pnl"]
    win_rate = len(winners) / total_trades * 100.0
    loss_rate = 100.0 - win_rate
    average_winner = winners.mean()
    average_loser = abs(losers.mean())
    expectancy = trades["pnl"].mean()
    risk_reward = average_winner / average_loser
    avg_monthly_return = monthly["monthly_return_pct"].mean()
    avg_monthly_drawdown = monthly["drawdown_pct_abs"].mean()

    period_days = (pd.Timestamp(config.analysis_end) - pd.Timestamp(config.analysis_start)).days + 1
    weeks = period_days / 7.0
    business_days = len(pd.bdate_range(config.analysis_start, config.analysis_end))

    return {
        "total_trades": total_trades,
        "win_rate": win_rate,
        "loss_rate": loss_rate,
        "average_winner": average_winner,
        "average_loser": average_loser,
        "average_rr": risk_reward,
        "expectancy": expectancy,
        "largest_winner": trades["pnl"].max(),
        "largest_loser": trades["pnl"].min(),
        "max_consecutive_wins": max_consecutive(trades["pnl"], positive=True),
        "max_consecutive_losses": max_consecutive(trades["pnl"], positive=False),
        "average_trades_per_month": total_trades / len(monthly),
        "average_trades_per_week": total_trades / weeks,
        "average_trades_per_day": total_trades / business_days,
        "trade_efficiency_score": config.net_profit / total_trades,
        "avg_monthly_return": avg_monthly_return,
        "avg_monthly_drawdown": avg_monthly_drawdown,
    }


def compute_sharpe_ratio(daily: pd.DataFrame) -> float:
    daily_returns = daily["daily_pnl"] / daily["start_balance"]
    if daily_returns.std(ddof=1) == 0:
        return 0.0
    return float(np.sqrt(252) * daily_returns.mean() / daily_returns.std(ddof=1))


def compute_ulcer_index(drawdown_pct: pd.Series) -> float:
    return float(np.sqrt(np.mean(np.square(drawdown_pct.fillna(0.0)))))


def compute_overall_metrics(
    monthly: pd.DataFrame,
    trades: pd.DataFrame,
    daily: pd.DataFrame,
    drawdown_monthly: pd.DataFrame,
    config: FTMOConfig,
) -> Dict[str, float | str | List[str]]:
    trade_metrics = compute_trade_analytics(trades, monthly, config)
    sharpe = compute_sharpe_ratio(daily)
    ulcer = compute_ulcer_index(abs(daily["underwater_pct"]))
    max_drawdown_eur = abs(daily["underwater_eur"].min())
    max_drawdown_pct = abs(daily["underwater_pct"].min())
    recovery = config.net_profit / max_drawdown_eur if max_drawdown_eur else np.nan
    current_safety_buffer = config.end_capital - config.ftmo_min_equity
    worst_safety_buffer = daily["buffer_to_min_equity"].min()
    worst_daily_buffer = daily["remaining_daily_buffer"].min()
    ftmo_status = derive_ftmo_status(daily, monthly, config)
    danger_months = monthly.loc[monthly["stress_month_flag"], "month"].tolist()
    high_quality_months = monthly.loc[monthly["quality_month_flag"], "month"].tolist()
    avg_business_day_trades = monthly["trades_per_day"].mean()
    overtrading_months = monthly.loc[monthly["overtrading_flag"], "month"].tolist()

    warning_ratio = (daily["ftmo_zone"] != "SAFE").mean()
    cluster_count = int((drawdown_monthly["danger_days"] > 0).sum())
    monthly_loss_util = monthly["drawdown_abs"].max() / config.ftmo_max_loss_limit
    daily_util = daily["daily_drawdown"].max() / config.ftmo_daily_loss_limit
    overtrade_load = len(overtrading_months) / len(monthly)
    risk_stress_score = min(
        100.0,
        100.0 * (0.35 * daily_util + 0.30 * monthly_loss_util + 0.20 * warning_ratio + 0.15 * overtrade_load),
    )
    estimated_fail_probability = min(75.0, max(4.0, risk_stress_score * 0.42 + cluster_count * 3.5))

    best_month_idx = monthly["net_result"].idxmax()
    worst_month_idx = monthly["net_result"].idxmin()
    net_profit_margin = config.net_profit / config.gross_profit * 100.0

    metrics: Dict[str, float | str | List[str]] = {
        "start_capital": config.start_capital,
        "final_capital": config.end_capital,
        "net_profit": config.net_profit,
        "total_return_pct": config.total_return_pct,
        "gross_profit": config.gross_profit,
        "gross_loss": config.gross_loss,
        "net_profit_margin": net_profit_margin,
        "profit_factor": config.gross_profit / abs(config.gross_loss),
        "sharpe_ratio": sharpe,
        "recovery_factor": recovery,
        "expectancy_per_trade": trade_metrics["expectancy"],
        "average_win": trade_metrics["average_winner"],
        "average_loss": trade_metrics["average_loser"],
        "risk_reward_ratio": trade_metrics["average_rr"],
        "max_drawdown_pct": max_drawdown_pct,
        "max_drawdown_eur": max_drawdown_eur,
        "ulcer_index": ulcer,
        "ftmo_compliance_status": ftmo_status,
        "worst_month": monthly.loc[worst_month_idx, "month"],
        "best_month": monthly.loc[best_month_idx, "month"],
        "average_monthly_return": trade_metrics["avg_monthly_return"],
        "average_monthly_drawdown": trade_metrics["avg_monthly_drawdown"],
        "trade_efficiency_score": trade_metrics["trade_efficiency_score"],
        "current_safety_buffer": current_safety_buffer,
        "worst_safety_buffer": worst_safety_buffer,
        "worst_daily_buffer": worst_daily_buffer,
        "estimated_fail_probability": estimated_fail_probability,
        "risk_stress_score": risk_stress_score,
        "total_trades": trade_metrics["total_trades"],
        "win_rate": trade_metrics["win_rate"],
        "loss_rate": trade_metrics["loss_rate"],
        "largest_winner": trade_metrics["largest_winner"],
        "largest_loser": trade_metrics["largest_loser"],
        "max_consecutive_wins": trade_metrics["max_consecutive_wins"],
        "max_consecutive_losses": trade_metrics["max_consecutive_losses"],
        "average_trades_per_month": trade_metrics["average_trades_per_month"],
        "average_trades_per_week": trade_metrics["average_trades_per_week"],
        "average_trades_per_day": trade_metrics["average_trades_per_day"],
        "danger_months": danger_months,
        "high_quality_months": high_quality_months,
        "overtrading_months": overtrading_months,
        "average_business_day_trades": avg_business_day_trades,
        "analysis_period": f"{config.analysis_start} to {config.analysis_end}",
    }
    return metrics


def derive_ftmo_status(daily: pd.DataFrame, monthly: pd.DataFrame, config: FTMOConfig) -> str:
    breach_min_equity = bool((daily["lowest_equity"] < config.ftmo_min_equity).any())
    breach_daily = bool((daily["daily_drawdown"] > config.ftmo_daily_loss_limit).any())
    breach_max_loss = bool((monthly["drawdown_abs"] > config.ftmo_max_loss_limit).any())
    if breach_min_equity or breach_daily or breach_max_loss:
        return "FAIL"
    if (daily["daily_drawdown"] > config.ftmo_daily_loss_limit * 0.80).any():
        return "PASS WITH DAILY LOSS CAUTION"
    return "PASS"


def build_efficiency_report(monthly: pd.DataFrame, config: FTMOConfig) -> pd.DataFrame:
    report = monthly.copy()
    avg_trades = report["trades"].mean()
    max_efficiency = report["trade_efficiency_eur"].max()
    report["trade_density_vs_avg"] = report["trades"] / avg_trades
    report["drawdown_load"] = report["drawdown_abs"] / report["trades"]
    report["quality_score"] = (
        np.clip((report["profit_factor"] - 0.90) / 1.10, 0, 1) * 35
        + np.clip(report["trade_efficiency_eur"] / max_efficiency, 0, 1) * 25
        + np.clip(1 - report["drawdown_abs"] / config.ftmo_max_loss_limit, 0, 1) * 20
        + np.clip(avg_trades / report["trades"], 0, 1.4) / 1.4 * 20
    )
    report["quality_label"] = np.select(
        [report["quality_score"] >= 75, report["quality_score"] >= 55],
        ["HIGH QUALITY", "ACCEPTABLE"],
        default="LOW QUALITY",
    )
    report["efficiency_comment"] = np.select(
        [
            report["month"].eq("2026-04"),
            report["month"].eq("2026-02"),
            report["overtrading_flag"],
        ],
        [
            "High selectivity, best capital efficiency and strongest PF.",
            "Stress month: overtrading in chop compressed expectancy to flat.",
            "Trade count exceeded sustainable density for realized edge.",
        ],
        default="Balanced month but further selectivity would improve edge retention.",
    )
    return report


def build_risk_report(daily: pd.DataFrame, monthly: pd.DataFrame, metrics: Dict[str, float | str | List[str]], config: FTMOConfig) -> pd.DataFrame:
    report = daily.copy()
    report["min_equity_buffer_pct"] = report["buffer_to_min_equity"] / config.start_capital * 100.0
    report["daily_limit_buffer_pct"] = report["remaining_daily_buffer"] / config.ftmo_daily_loss_limit * 100.0
    report["risk_month_flag"] = report["month"].isin(metrics["danger_months"])
    report["warning_label"] = np.select(
        [
            report["daily_limit_utilization"] >= 0.80,
            report["daily_limit_utilization"] >= 0.60,
            report["trades"] >= report["trades"].quantile(0.80),
        ],
        ["DAILY LOSS CAUTION", "HIGH EXPOSURE WARNING", "OVERTRADING DETECTED"],
        default="NORMAL",
    )
    return report


def build_payout_simulation(monthly: pd.DataFrame, config: FTMOConfig) -> pd.DataFrame:
    rows = []
    rolling_balance = config.start_capital
    for row in monthly.itertuples(index=False):
        balance_before_payout = rolling_balance + row.net_result
        payout = max(row.net_result, 0.0) * config.payout_rate
        retained_profit = max(row.net_result, 0.0) - payout
        rolling_balance = balance_before_payout - payout
        rows.append(
            {
                "month": row.month,
                "gross_profit": row.gross_profit,
                "gross_loss": row.gross_loss,
                "net_result": row.net_result,
                "trader_payout": payout,
                "firm_share": retained_profit,
                "balance_after_payout": rolling_balance,
            }
        )
    return pd.DataFrame(rows)


def build_session_placeholder() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "session": "London",
                "status": "Framework ready",
                "edge_view": "Likely primary alpha window for XAUUSD expansion and trend continuation.",
            },
            {
                "session": "New York",
                "status": "Framework ready",
                "edge_view": "Useful for momentum follow-through, but requires volatility filter to avoid reversal chop.",
            },
            {
                "session": "Asia",
                "status": "Framework ready",
                "edge_view": "Use cautiously; likely lower expectancy unless a compression-breakout model is active.",
            },
        ]
    )


def build_regime_analysis(monthly: pd.DataFrame) -> pd.DataFrame:
    rows = [
        ["Trending market", "Positive", "April strength and fewer trades suggest cleaner directional conditions.", "Maintain full size if ADX confirms."],
        ["Ranging market", "Negative", "February delivered flat PnL with high density and weak PF.", "Suppress signals and reduce frequency."],
        ["High volatility", "Selective positive", "Can produce strong gross profit but raises drawdown clustering risk.", "Trade only with ATR threshold and profit lock."],
        ["Low volatility", "Weak", "Edge deteriorates when impulse quality disappears.", "Avoid unless compression breakout criteria trigger."],
        ["Expansion phases", "Strong", "April and May benefited from higher payoff concentration.", "Prioritize breakout continuation setups."],
        ["Compression phases", "Poor until release", "Chop increases low-quality entries and unnecessary exposure.", "Use trade suppression engine until breakout confirms."],
    ]
    regime = pd.DataFrame(rows, columns=["regime", "inferred_performance", "evidence", "action"])
    return regime


def kpi_color(metric_name: str, value: float | str) -> Tuple[str, str]:
    if metric_name in {"Start capital", "Final capital", "Net profit", "Gross profit"}:
        return PALETTE["green"], PALETTE["green_soft"]
    if metric_name == "Gross loss":
        return PALETTE["red"], PALETTE["red_soft"]
    if metric_name == "Total return %":
        return (PALETTE["green"], PALETTE["green_soft"]) if float(value) >= 20 else (PALETTE["amber"], PALETTE["amber_soft"])
    if metric_name == "Net profit margin":
        return (PALETTE["green"], PALETTE["green_soft"]) if float(value) >= 25 else (PALETTE["amber"], PALETTE["amber_soft"])
    if metric_name == "Profit factor":
        if float(value) >= 1.50:
            return PALETTE["green"], PALETTE["green_soft"]
        if float(value) >= 1.15:
            return PALETTE["amber"], PALETTE["amber_soft"]
        return PALETTE["red"], PALETTE["red_soft"]
    if metric_name == "Sharpe ratio":
        if float(value) >= 1.50:
            return PALETTE["green"], PALETTE["green_soft"]
        if float(value) >= 0.75:
            return PALETTE["amber"], PALETTE["amber_soft"]
        return PALETTE["red"], PALETTE["red_soft"]
    if metric_name in {"Recovery factor", "Trade efficiency score"}:
        if float(value) >= 3.0 if metric_name == "Recovery factor" else float(value) >= 300.0:
            return PALETTE["green"], PALETTE["green_soft"]
        if float(value) >= 2.0 if metric_name == "Recovery factor" else float(value) >= 150.0:
            return PALETTE["amber"], PALETTE["amber_soft"]
        return PALETTE["red"], PALETTE["red_soft"]
    if metric_name == "Risk/reward ratio":
        return (PALETTE["green"], PALETTE["green_soft"]) if float(value) >= 1.20 else (PALETTE["amber"], PALETTE["amber_soft"])
    if metric_name in {"Max drawdown %", "Max drawdown EUR", "Ulcer Index"}:
        threshold = 5.0 if metric_name == "Max drawdown %" else 12000.0 if metric_name == "Max drawdown EUR" else 3.5
        warning = 6.5 if metric_name == "Max drawdown %" else 14000.0 if metric_name == "Max drawdown EUR" else 5.0
        if float(value) <= threshold:
            return PALETTE["green"], PALETTE["green_soft"]
        if float(value) <= warning:
            return PALETTE["amber"], PALETTE["amber_soft"]
        return PALETTE["red"], PALETTE["red_soft"]
    if metric_name == "FTMO compliance status":
        if value == "PASS":
            return PALETTE["green"], PALETTE["green_soft"]
        if "CAUTION" in str(value):
            return PALETTE["amber"], PALETTE["amber_soft"]
        return PALETTE["red"], PALETTE["red_soft"]
    if metric_name in {"Worst month", "Best month"}:
        return (PALETTE["red"], PALETTE["red_soft"]) if metric_name == "Worst month" else (PALETTE["green"], PALETTE["green_soft"])
    if metric_name in {"Average monthly return", "Average monthly drawdown"}:
        target = 4.0 if metric_name == "Average monthly return" else 5.0
        if (metric_name == "Average monthly return" and float(value) >= target) or (
            metric_name == "Average monthly drawdown" and float(value) <= target
        ):
            return PALETTE["green"], PALETTE["green_soft"]
        return PALETTE["amber"], PALETTE["amber_soft"]
    return PALETTE["blue"], PALETTE["blue_soft"]


def draw_top_banner(fig: plt.Figure, metrics: Dict[str, float | str | List[str]]) -> None:
    ax = fig.add_axes([0.02, 0.92, 0.96, 0.07])
    ax.set_facecolor(PALETTE["panel"])
    ax.set_axis_off()
    box = FancyBboxPatch(
        (0, 0),
        1,
        1,
        boxstyle="round,pad=0.012,rounding_size=0.02",
        linewidth=1.2,
        edgecolor=PALETTE["grid"],
        facecolor=PALETTE["panel"],
        transform=ax.transAxes,
    )
    ax.add_patch(box)
    ax.text(0.02, 0.62, "FTMO XAUUSD ANALYTICS SUITE V2", color=PALETTE["white"], fontsize=19, fontweight="bold", va="center")
    ax.text(
        0.02,
        0.25,
        f"Period {metrics['analysis_period']}  |  Prop-firm risk lens  |  Institutional execution review",
        color=PALETTE["muted"],
        fontsize=10,
        va="center",
    )

    badge_color, badge_fill = kpi_color("FTMO compliance status", str(metrics["ftmo_compliance_status"]))
    badge = FancyBboxPatch(
        (0.71, 0.18),
        0.12,
        0.62,
        boxstyle="round,pad=0.018,rounding_size=0.03",
        linewidth=1.0,
        edgecolor=badge_color,
        facecolor=badge_fill,
        transform=ax.transAxes,
    )
    ax.add_patch(badge)
    ax.text(0.77, 0.50, str(metrics["ftmo_compliance_status"]), color=badge_color, fontsize=11, fontweight="bold", ha="center", va="center")

    summary = [
        ("Return", format_pct(float(metrics["total_return_pct"]))),
        ("PF", f"{float(metrics['profit_factor']):.2f}"),
        ("Sharpe", f"{float(metrics['sharpe_ratio']):.2f}"),
        ("Stress", f"{float(metrics['risk_stress_score']):.0f}/100"),
    ]
    x_positions = [0.86, 0.91, 0.95, 0.985]
    for (label, value), x_pos in zip(summary, x_positions):
        ax.text(x_pos, 0.60, value, color=PALETTE["white"], fontsize=11, fontweight="bold", ha="right")
        ax.text(x_pos, 0.25, label, color=PALETTE["muted"], fontsize=8, ha="right")


def draw_kpi_cards(ax: plt.Axes, metrics: Dict[str, float | str | List[str]]) -> None:
    ax.set_axis_off()
    items = [
        ("Start capital", format_eur(float(metrics["start_capital"])), float(metrics["start_capital"])),
        ("Final capital", format_eur(float(metrics["final_capital"])), float(metrics["final_capital"])),
        ("Net profit", format_eur(float(metrics["net_profit"])), float(metrics["net_profit"])),
        ("Total return %", format_pct(float(metrics["total_return_pct"])), float(metrics["total_return_pct"])),
        ("Gross profit", format_eur(float(metrics["gross_profit"])), float(metrics["gross_profit"])),
        ("Gross loss", format_eur(float(metrics["gross_loss"])), float(metrics["gross_loss"])),
        ("Net profit margin", format_pct(float(metrics["net_profit_margin"])), float(metrics["net_profit_margin"])),
        ("Profit factor", f"{float(metrics['profit_factor']):.2f}", float(metrics["profit_factor"])),
        ("Sharpe ratio", f"{float(metrics['sharpe_ratio']):.2f}", float(metrics["sharpe_ratio"])),
        ("Recovery factor", f"{float(metrics['recovery_factor']):.2f}", float(metrics["recovery_factor"])),
        ("Expectancy per trade", format_eur(float(metrics["expectancy_per_trade"])), float(metrics["expectancy_per_trade"])),
        ("Average win", format_eur(float(metrics["average_win"])), float(metrics["average_win"])),
        ("Average loss", format_eur(float(metrics["average_loss"])), float(metrics["average_loss"])),
        ("Risk/reward ratio", f"{float(metrics['risk_reward_ratio']):.2f}", float(metrics["risk_reward_ratio"])),
        ("Max drawdown %", format_pct(float(metrics["max_drawdown_pct"])), float(metrics["max_drawdown_pct"])),
        ("Max drawdown EUR", format_eur(float(metrics["max_drawdown_eur"])), float(metrics["max_drawdown_eur"])),
        ("Ulcer Index", f"{float(metrics['ulcer_index']):.2f}", float(metrics["ulcer_index"])),
        ("FTMO compliance status", str(metrics["ftmo_compliance_status"]), str(metrics["ftmo_compliance_status"])),
        ("Worst month", str(metrics["worst_month"]), str(metrics["worst_month"])),
        ("Best month", str(metrics["best_month"]), str(metrics["best_month"])),
        ("Average monthly return", format_pct(float(metrics["average_monthly_return"])), float(metrics["average_monthly_return"])),
        ("Average monthly drawdown", format_pct(float(metrics["average_monthly_drawdown"])), float(metrics["average_monthly_drawdown"])),
        ("Trade efficiency score", format_eur(float(metrics["trade_efficiency_score"])), float(metrics["trade_efficiency_score"])),
    ]

    cols = 6
    rows = 4
    card_w = 0.155
    card_h = 0.215
    x_gap = 0.012
    y_gap = 0.035
    start_x = 0.01
    start_y = 0.75

    for idx, (title, value, raw) in enumerate(items):
        row = idx // cols
        col = idx % cols
        x0 = start_x + col * (card_w + x_gap)
        y0 = start_y - row * (card_h + y_gap)
        edge, fill = kpi_color(title, raw)
        rect = FancyBboxPatch(
            (x0, y0),
            card_w,
            card_h,
            boxstyle="round,pad=0.012,rounding_size=0.02",
            linewidth=1.2,
            edgecolor=edge,
            facecolor=fill,
            transform=ax.transAxes,
        )
        ax.add_patch(rect)
        ax.text(x0 + 0.015, y0 + 0.145, title, color=PALETTE["muted"], fontsize=8.5, fontweight="bold", transform=ax.transAxes)
        ax.text(x0 + 0.015, y0 + 0.055, value, color=PALETTE["white"], fontsize=12.2, fontweight="bold", transform=ax.transAxes)


def plot_heatmap(ax: plt.Axes, pivot: pd.DataFrame, title: str) -> None:
    style_axes(ax, title)
    if sns is not None:
        sns.heatmap(
            pivot,
            ax=ax,
            cmap="mako",
            cbar=False,
            linewidths=0.35,
            linecolor=PALETTE["grid"],
            annot=False,
        )
    else:
        ax.imshow(pivot.fillna(0.0).values, aspect="auto", cmap="viridis")
        ax.set_xticks(range(len(pivot.columns)))
        ax.set_xticklabels(pivot.columns, color=PALETTE["muted"])
        ax.set_yticks(range(len(pivot.index)))
        ax.set_yticklabels(pivot.index, color=PALETTE["muted"])
    ax.tick_params(axis="x", rotation=0)
    ax.tick_params(axis="y", rotation=0)


def plot_dashboard(
    monthly: pd.DataFrame,
    trades: pd.DataFrame,
    daily: pd.DataFrame,
    drawdown_monthly: pd.DataFrame,
    efficiency: pd.DataFrame,
    metrics: Dict[str, float | str | List[str]],
    session_df: pd.DataFrame,
    regime_df: pd.DataFrame,
    config: FTMOConfig,
) -> None:
    plt.rcParams["font.family"] = "DejaVu Sans"
    fig = plt.figure(figsize=(24, 18), facecolor=PALETTE["bg"])
    draw_top_banner(fig, metrics)

    gs = fig.add_gridspec(
        18,
        24,
        left=0.02,
        right=0.98,
        top=0.90,
        bottom=0.04,
        wspace=0.90,
        hspace=1.35,
    )

    ax_cards = fig.add_subplot(gs[0:4, :])
    draw_kpi_cards(ax_cards, metrics)

    ax_cum = fig.add_subplot(gs[4:8, 0:8])
    ax_underwater = fig.add_subplot(gs[4:8, 8:16])
    ax_risk = fig.add_subplot(gs[4:8, 16:24])
    ax_dist = fig.add_subplot(gs[8:12, 0:6])
    ax_expectancy = fig.add_subplot(gs[8:12, 6:12])
    ax_freq = fig.add_subplot(gs[8:12, 12:18])
    ax_pf = fig.add_subplot(gs[8:12, 18:24])
    ax_efficiency = fig.add_subplot(gs[12:15, 0:8])
    ax_monthly = fig.add_subplot(gs[12:15, 8:16])
    ax_heatmap = fig.add_subplot(gs[12:15, 16:24])
    ax_session = fig.add_subplot(gs[15:18, 0:8])
    ax_regime = fig.add_subplot(gs[15:18, 8:16])
    ax_summary = fig.add_subplot(gs[15:18, 16:24])

    months = [month_label(m) for m in monthly["month"]]

    style_axes(ax_cum, "Cumulative Profit and Equity Curve", "Synthetic trade path calibrated from monthly aggregates and repo reference metrics.")
    ax_cum.plot(trades["trade_id"], trades["cumulative_profit"], color=PALETTE["green"], linewidth=2.4, label="Cumulative profit")
    ax_cum.plot(trades["trade_id"], trades["equity"], color=PALETTE["blue"], linewidth=1.8, alpha=0.85, label="Equity")
    ax_cum.fill_between(trades["trade_id"], trades["cumulative_profit"], 0, color=PALETTE["green"], alpha=0.12)
    ax_cum.set_ylabel("EUR", color=PALETTE["muted"])
    ax_cum.yaxis.set_major_formatter(euro_formatter())
    ax_cum.legend(frameon=False, labelcolor=PALETTE["muted"], loc="upper left")

    style_axes(ax_underwater, "Advanced Drawdown and FTMO Zones", "February flagged as stress month. April flagged as high quality.")
    ax_underwater.axhspan(-2.5, 0, color=PALETTE["green_soft"], alpha=0.70)
    ax_underwater.axhspan(-5.0, -2.5, color=PALETTE["amber_soft"], alpha=0.65)
    ax_underwater.axhspan(daily["underwater_pct"].min() - 0.5, -5.0, color=PALETTE["red_soft"], alpha=0.55)
    ax_underwater.plot(daily["date"], daily["underwater_pct"], color=PALETTE["red"], linewidth=2.0)
    ax_underwater.fill_between(daily["date"], daily["underwater_pct"], 0, color=PALETTE["red"], alpha=0.20)
    ax_underwater.axhline(-5.0, color=PALETTE["amber"], linestyle="--", linewidth=1.1)
    ax_underwater.axhline(-6.5, color=PALETTE["red"], linestyle=":", linewidth=1.1)
    feb_slice = daily.loc[daily["month"] == "2026-02", "date"]
    apr_slice = daily.loc[daily["month"] == "2026-04", "date"]
    if not feb_slice.empty:
        ax_underwater.axvspan(feb_slice.min(), feb_slice.max(), color=PALETTE["red_soft"], alpha=0.20)
    if not apr_slice.empty:
        ax_underwater.axvspan(apr_slice.min(), apr_slice.max(), color=PALETTE["green_soft"], alpha=0.20)
    ax_underwater.set_ylabel("%", color=PALETTE["muted"])

    style_axes(ax_risk, "FTMO Risk Engine", "Daily caution, overtrading and exposure warnings are shown below.")
    ax_risk.set_axis_off()
    risk_lines = [
        ("Daily limit", format_eur(config.ftmo_daily_loss_limit)),
        ("Max loss limit", format_eur(config.ftmo_max_loss_limit)),
        ("Minimum equity", format_eur(config.ftmo_min_equity)),
        ("Current safety buffer", format_eur(float(metrics["current_safety_buffer"]))),
        ("Worst safety buffer", format_eur(float(metrics["worst_safety_buffer"]))),
        ("Worst daily buffer", format_eur(float(metrics["worst_daily_buffer"]))),
        ("Estimated fail probability", format_pct(float(metrics["estimated_fail_probability"]))),
        ("Risk stress score", f"{float(metrics['risk_stress_score']):.0f}/100"),
    ]
    for idx, (label, value) in enumerate(risk_lines):
        ax_risk.text(0.03, 0.92 - idx * 0.10, label, color=PALETTE["muted"], fontsize=9.5, transform=ax_risk.transAxes)
        ax_risk.text(0.62, 0.92 - idx * 0.10, value, color=PALETTE["white"], fontsize=10.5, fontweight="bold", transform=ax_risk.transAxes)

    warnings = [
        ("DAILY LOSS CAUTION", (daily["daily_limit_utilization"] >= 0.80).any(), PALETTE["amber"]),
        ("OVERTRADING DETECTED", len(metrics["overtrading_months"]) > 0, PALETTE["amber"]),
        ("HIGH EXPOSURE WARNING", monthly["drawdown_abs"].max() >= 10000, PALETTE["red"]),
        ("CHOP MARKET DETECTED", "2026-02" in metrics["danger_months"], PALETTE["red"]),
    ]
    y = 0.18
    for label, active, color in warnings:
        fill = PALETTE["green_soft"] if not active else (PALETTE["amber_soft"] if color == PALETTE["amber"] else PALETTE["red_soft"])
        edge = PALETTE["green"] if not active else color
        badge = FancyBboxPatch((0.03, y), 0.42, 0.09, boxstyle="round,pad=0.012,rounding_size=0.02", linewidth=1, edgecolor=edge, facecolor=fill, transform=ax_risk.transAxes)
        ax_risk.add_patch(badge)
        ax_risk.text(0.24, y + 0.045, label, color=edge, fontsize=8.5, fontweight="bold", ha="center", va="center", transform=ax_risk.transAxes)
        y -= 0.12

    style_axes(ax_dist, "Winner vs Loser Distribution")
    wins = trades.loc[trades["pnl"] > 0, "pnl"]
    losses = abs(trades.loc[trades["pnl"] < 0, "pnl"])
    ax_dist.hist(wins, bins=14, alpha=0.65, color=PALETTE["green"], label="Winners")
    ax_dist.hist(losses, bins=14, alpha=0.55, color=PALETTE["red"], label="Losers")
    ax_dist.legend(frameon=False, labelcolor=PALETTE["muted"])
    ax_dist.xaxis.set_major_formatter(euro_formatter())

    style_axes(ax_expectancy, "Expectancy Curve")
    ax_expectancy.plot(trades["trade_id"], trades["expectancy_curve"], color=PALETTE["cyan"], linewidth=2.0)
    ax_expectancy.axhline(float(metrics["trade_efficiency_score"]), color=PALETTE["amber"], linestyle="--", linewidth=1.1)
    ax_expectancy.set_ylabel("EUR per trade", color=PALETTE["muted"])
    ax_expectancy.yaxis.set_major_formatter(euro_formatter())

    style_axes(ax_freq, "Trade Frequency and Density")
    freq_colors = [PALETTE["red"] if flag else PALETTE["blue"] for flag in monthly["overtrading_flag"]]
    ax_freq.bar(months, monthly["trades"], color=freq_colors, alpha=0.90, label="Trades per month")
    ax_freq.plot(months, monthly["trades_per_day"] * monthly["business_days"].mean(), color=PALETTE["amber"], linewidth=2.0, marker="o", label="Density proxy")
    ax_freq.legend(frameon=False, labelcolor=PALETTE["muted"], loc="upper right")

    style_axes(ax_pf, "Rolling Profit Factor")
    ax_pf.plot(trades["trade_id"], trades["rolling_profit_factor"], color=PALETTE["magenta"], linewidth=2.1)
    ax_pf.axhline(1.0, color=PALETTE["red"], linestyle="--", linewidth=1.0)
    ax_pf.axhline(1.5, color=PALETTE["green"], linestyle=":", linewidth=1.0)
    ax_pf.set_ylim(bottom=0)

    style_axes(ax_efficiency, "Efficiency Graph and Quality Score")
    ax_efficiency.plot(months, efficiency["trade_efficiency_eur"], color=PALETTE["green"], linewidth=2.4, marker="o", label="EUR per trade")
    ax_efficiency.bar(months, efficiency["quality_score"], color=PALETTE["blue"], alpha=0.35, label="Quality score")
    ax_efficiency.axhline(float(metrics["trade_efficiency_score"]), color=PALETTE["amber"], linestyle="--", linewidth=1.0)
    ax_efficiency.legend(frameon=False, labelcolor=PALETTE["muted"], loc="upper left")
    ax_efficiency.yaxis.set_major_formatter(FuncFormatter(lambda x, pos: f"{x:,.0f}"))

    style_axes(ax_monthly, "Monthly PnL vs Drawdown")
    ax_monthly.bar(months, monthly["net_result"], color=[PALETTE["green"] if v >= 0 else PALETTE["red"] for v in monthly["net_result"]], alpha=0.85, label="Net PnL")
    ax_monthly.plot(months, -monthly["drawdown_abs"], color=PALETTE["amber"], linewidth=2.0, marker="o", label="Max drawdown EUR")
    ax_monthly.axhline(0, color=PALETTE["grid"], linewidth=1.0)
    ax_monthly.legend(frameon=False, labelcolor=PALETTE["muted"], loc="upper left")
    ax_monthly.yaxis.set_major_formatter(euro_formatter())

    heatmap_pivot = daily.pivot_table(index="month", columns="weekday", values="daily_limit_utilization", aggfunc="mean")
    weekday_order = ["Mon", "Tue", "Wed", "Thu", "Fri"]
    heatmap_pivot = heatmap_pivot.reindex(columns=weekday_order)
    plot_heatmap(ax_heatmap, heatmap_pivot, "Drawdown Heatmap")

    style_axes(ax_session, "Session Performance Framework", "Placeholders are production-ready structures awaiting tagged session fields.")
    ax_session.set_axis_off()
    for idx, row in session_df.iterrows():
        y0 = 0.85 - idx * 0.28
        ax_session.text(0.03, y0, row["session"], color=PALETTE["white"], fontsize=11, fontweight="bold", transform=ax_session.transAxes)
        ax_session.text(0.03, y0 - 0.09, row["status"], color=PALETTE["cyan"], fontsize=9, transform=ax_session.transAxes)
        ax_session.text(0.03, y0 - 0.18, row["edge_view"], color=PALETTE["muted"], fontsize=8.6, transform=ax_session.transAxes)

    style_axes(ax_regime, "Market Regime Analysis")
    ax_regime.set_axis_off()
    regime_lines = [
        "Trending market: strongest inferred condition for this strategy.",
        "Ranging market: statistically weakest, tied to February chop.",
        "High volatility: profitable only when filtered, otherwise drawdown clusters expand.",
        "Compression phases: best treated as wait states until expansion confirms.",
        "April shows the cleanest trend-expansion behavior and best selectivity.",
        "February shows classic overtrading in unstable range conditions.",
    ]
    for idx, line in enumerate(regime_lines):
        ax_regime.text(0.03, 0.90 - idx * 0.13, line, color=PALETTE["muted"], fontsize=9, transform=ax_regime.transAxes)

    style_axes(ax_summary, "Institutional Summary")
    ax_summary.set_axis_off()
    summary_lines = [
        "Edge is positive but still sample-limited; 124 trades is promising, not definitive.",
        "System is prop-firm viable if trade suppression and regime filters are added.",
        "Biggest weakness is drawdown clustering during chop, not outright loss magnitude.",
        "Best operational insight: lower trade density improved payoff concentration in April.",
        "Scalability is conditional on daily lock rules and volatility-aware sizing.",
    ]
    for idx, line in enumerate(summary_lines):
        ax_summary.text(0.03, 0.90 - idx * 0.14, line, color=PALETTE["muted"], fontsize=9.2, transform=ax_summary.transAxes)

    fig.savefig(config.dashboard_file, dpi=220, facecolor=PALETTE["bg"])
    plt.close(fig)


def export_outputs(
    trades: pd.DataFrame,
    risk: pd.DataFrame,
    drawdown: pd.DataFrame,
    efficiency: pd.DataFrame,
    payout: pd.DataFrame,
    config: FTMOConfig,
) -> None:
    trades.to_csv(config.trade_file, index=False)
    risk.to_csv(config.risk_file, index=False)
    drawdown.to_csv(config.drawdown_file, index=False)
    efficiency.to_csv(config.efficiency_file, index=False)
    payout.to_csv(config.payout_file, index=False)


def build_summary_text(metrics: Dict[str, float | str | List[str]], efficiency: pd.DataFrame) -> str:
    best_quality = efficiency.loc[efficiency["quality_score"].idxmax()]
    feb = efficiency.loc[efficiency["month"] == "2026-02"].iloc[0]
    apr = efficiency.loc[efficiency["month"] == "2026-04"].iloc[0]
    scalable = "Conditionally scalable"
    statistical_validity = "Moderately positive but not yet fully validated"
    overtrading = "Yes, especially in January and February"
    live_robustness = "Promising with controls, not yet robust enough in current raw form"
    weakness = "Drawdown clustering and low-quality signal acceptance during range/chop conditions"
    next_opt = "Regime filters, trade suppression, and volatility-aware position sizing"
    viable = "Yes, conditionally prop-firm viable"

    lines = [
        "",
        "=" * 90,
        "INSTITUTIONAL FTMO STRATEGY SUMMARY",
        "=" * 90,
        f"Is the strategy FTMO scalable? {scalable}.",
        f"Is the edge statistically valid? {statistical_validity}.",
        f"Is the strategy overtrading? {overtrading}.",
        f"Is the system robust enough for live trading? {live_robustness}.",
        f"What is the biggest weakness? {weakness}.",
        f"What should be optimized next? {next_opt}.",
        f"Is the strategy prop-firm viable? {viable}.",
        "",
        "Why February was weak:",
        f"- Profit factor compressed to {feb['profit_factor']:.2f} while trade density stayed elevated at {feb['trades']} trades.",
        f"- Net profit per trade collapsed to {format_eur(feb['trade_efficiency_eur'])}, showing weak selectivity in chop.",
        "- Drawdown expanded while payoff concentration disappeared, a classic sign of over-participation in unstable conditions.",
        "",
        "Why April was strong:",
        f"- April delivered the best quality score ({best_quality['quality_score']:.1f}) with only {int(apr['trades'])} trades.",
        f"- Expectancy improved to {format_eur(apr['trade_efficiency_eur'])} per trade while PF rose to {apr['profit_factor']:.2f}.",
        "- Fewer trades produced better setup concentration, stronger trend alignment and cleaner capital efficiency.",
        "",
        "Why fewer trades are likely better:",
        "- The best month came from lower trade density, not higher activity.",
        "- High trade count correlated with weaker PF and more drawdown stress.",
        "- The data suggests the edge lives in selective expansion setups rather than constant participation.",
        "",
        "How drawdown can be structurally reduced:",
        "- Add ATR volatility filter to avoid low-range noise and excessively stretched conditions.",
        "- Add ADX trend filter so full-risk trades only deploy into confirmed directional environments.",
        "- Use London and New York session filters, while suppressing Asia unless compression-breakout conditions are active.",
        "- Introduce a trade suppression engine after two low-quality signals or one failed breakout cluster.",
        "- Add daily, weekly and monthly profit locks to protect asymmetrical payout months.",
        "- Pause trading after consecutive losses and reduce size in compression or chop regimes.",
        "- Use adaptive position sizing and regime-based risk reduction to keep drawdown clusters contained.",
        "",
        "Concrete professional improvements:",
        "- ATR volatility filter: remove trades when realized range is too small or too unstable for clean XAUUSD structure.",
        "- ADX trend filter: increase selectivity and prevent range-bound false starts.",
        "- Session filters: prioritize London open and NY continuation windows where gold liquidity and momentum are strongest.",
        "- Trade suppression engine: block repeated entries after failed impulses or clustered stop-outs.",
        "- Daily profit lock: hard-protect strong days before late-session giveback.",
        "- Weekly profit lock: reduce risk once weekly objective is met to protect prop-firm consistency.",
        "- Monthly profit lock: taper exposure once payout target is reached.",
        "- Pause after consecutive losses: interrupts emotional or model drift during chop.",
        "- Volatility compression detection: trade the breakout, not the dead zone.",
        "- Chop market avoidance: skip signals when volatility and directional strength diverge.",
        "- Adaptive position sizing: scale with realized volatility and recent signal quality.",
        "- Regime-based risk reduction: halve risk in range/chop regimes and restore only in confirmed expansion.",
        "",
        "Professional quant conclusion:",
        f"- FTMO compliance status: {metrics['ftmo_compliance_status']}.",
        f"- Total return is {format_pct(float(metrics['total_return_pct']))} with max drawdown near {format_pct(float(metrics['max_drawdown_pct']))}.",
        f"- The strategy shows a real positive edge, but the edge is fragile when market structure degrades.",
        "- With stronger suppression, regime filters and payout-protection logic, this can become a far more institutional and scalable prop-firm system.",
    ]
    return "\n".join(lines)


def main() -> None:
    config = FTMOConfig()
    monthly = prepare_monthly_dataset(config, Path("xauusd_monthly_summary.csv"))
    daily = load_daily_risk_report(Path("xauusd_daily_risk_report.csv"))
    trades = create_synthetic_trade_book(monthly, config)
    daily_drawdown, drawdown_monthly = compute_drawdown_analysis(daily, config)
    efficiency = build_efficiency_report(monthly, config)
    metrics = compute_overall_metrics(monthly, trades, daily_drawdown, drawdown_monthly, config)
    risk_report = build_risk_report(daily_drawdown, monthly, metrics, config)
    payout = build_payout_simulation(monthly, config)
    session_df = build_session_placeholder()
    regime_df = build_regime_analysis(monthly)

    export_outputs(trades, risk_report, daily_drawdown, efficiency, payout, config)
    plot_dashboard(monthly, trades, daily_drawdown, drawdown_monthly, efficiency, metrics, session_df, regime_df, config)
    print(build_summary_text(metrics, efficiency))


if __name__ == "__main__":
    main()
