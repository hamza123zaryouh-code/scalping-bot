from __future__ import annotations

import logging
import math
import os
import shutil
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
from dotenv import load_dotenv
from matplotlib.ticker import FuncFormatter
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


LOGGER = logging.getLogger("ftmo_report_pipeline")

PDF_THEME = {
    "navy": colors.HexColor("#07121d"),
    "slate": colors.HexColor("#0f1c2a"),
    "steel": colors.HexColor("#1a2b3d"),
    "grid": colors.HexColor("#d6dce5"),
    "text": colors.HexColor("#17212b"),
    "muted": colors.HexColor("#5b6b7b"),
    "green": colors.HexColor("#0f9d73"),
    "amber": colors.HexColor("#c28812"),
    "red": colors.HexColor("#c94f5d"),
    "blue": colors.HexColor("#2f74c0"),
    "cyan": colors.HexColor("#169bb7"),
    "paper": colors.HexColor("#f4f7fb"),
    "white": colors.white,
}

CHART_THEME = {
    "bg": "#061018",
    "panel": "#0d1824",
    "grid": "#284057",
    "text": "#edf2f8",
    "muted": "#90a4b9",
    "green": "#18c28e",
    "amber": "#f3b74b",
    "red": "#ff6678",
    "blue": "#54a0ff",
    "cyan": "#35d0ff",
    "violet": "#9a7cf3",
    "white": "#fbfdff",
}


@dataclass
class ExportPaths:
    base_dir: Path
    exports_dir: Path
    latest_dir: Path
    reports_dir: Path
    images_dir: Path
    data_dir: Path
    logs_dir: Path
    history_dir: Path
    summary_file: Path
    zip_file: Path
    error_log_file: Path
    report_log_file: Path


@dataclass
class TelegramSettings:
    token: str = ""
    chat_id: str = ""

    @property
    def configured(self) -> bool:
        return bool(self.token and self.chat_id)


@dataclass
class ReportContext:
    base_dir: Path
    generated_at: datetime
    paths: ExportPaths
    datasets: Dict[str, pd.DataFrame]
    metrics: Dict[str, Any]
    summary_text: str
    summary_metrics: Dict[str, Any] = field(default_factory=dict)
    report_paths: Dict[str, Path] = field(default_factory=dict)
    image_paths: Dict[str, Path] = field(default_factory=dict)
    archive_path: Path | None = None
    telegram_success: bool = False


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(number):
        return default
    return number


def safe_ratio(numerator: Any, denominator: Any, default: float = 0.0) -> float:
    denominator_value = safe_float(denominator)
    if abs(denominator_value) < 1e-12:
        return default
    return safe_float(numerator) / denominator_value


def format_currency(value: Any) -> str:
    amount = safe_float(value)
    sign = "-" if amount < 0 else ""
    return f"{sign}EUR {abs(amount):,.2f}"


def format_percent(value: Any, scale: float = 1.0) -> str:
    return f"{safe_float(value) * scale:.2f}%"


def format_number(value: Any, decimals: int = 2) -> str:
    return f"{safe_float(value):,.{decimals}f}"


def euro_formatter() -> FuncFormatter:
    return FuncFormatter(lambda value, pos: f"EUR {value:,.0f}")


def create_export_paths(base_dir: Path) -> ExportPaths:
    exports_dir = base_dir / "exports"
    latest_dir = exports_dir / "latest"
    reports_dir = latest_dir / "reports"
    images_dir = latest_dir / "images"
    data_dir = latest_dir / "data"
    logs_dir = latest_dir / "logs"
    history_dir = exports_dir / "history"

    return ExportPaths(
        base_dir=base_dir,
        exports_dir=exports_dir,
        latest_dir=latest_dir,
        reports_dir=reports_dir,
        images_dir=images_dir,
        data_dir=data_dir,
        logs_dir=logs_dir,
        history_dir=history_dir,
        summary_file=latest_dir / "summary.txt",
        zip_file=latest_dir / "ftmo_project_export.zip",
        error_log_file=exports_dir / "error_log.txt",
        report_log_file=logs_dir / "reporting.log",
    )


def prepare_latest_workspace(paths: ExportPaths) -> None:
    paths.exports_dir.mkdir(parents=True, exist_ok=True)
    paths.history_dir.mkdir(parents=True, exist_ok=True)
    paths.latest_dir.mkdir(parents=True, exist_ok=True)

    for directory in [paths.reports_dir, paths.images_dir, paths.data_dir, paths.logs_dir]:
        if directory.exists():
            shutil.rmtree(directory)
        directory.mkdir(parents=True, exist_ok=True)


def configure_file_logging(paths: ExportPaths) -> None:
    paths.logs_dir.mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(paths.report_log_file, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
    file_handler.setLevel(logging.INFO)

    if not any(isinstance(handler, logging.FileHandler) and getattr(handler, "baseFilename", "") == str(paths.report_log_file) for handler in LOGGER.handlers):
        LOGGER.addHandler(file_handler)
    LOGGER.setLevel(logging.INFO)


def compute_drawdown(equity: pd.Series) -> pd.DataFrame:
    equity = pd.Series(equity).astype(float)
    peaks = equity.cummax()
    drawdown = equity - peaks
    drawdown_pct = np.where(peaks != 0, drawdown / peaks * 100.0, 0.0)
    return pd.DataFrame(
        {
            "equity": equity,
            "peak": peaks,
            "drawdown_eur": drawdown,
            "drawdown_pct": drawdown_pct,
        }
    )


def extract_summary_metrics(context: ReportContext) -> Dict[str, Any]:
    trade_quality = context.datasets.get("trade_quality", pd.DataFrame())
    monthly = context.datasets.get("monthly", pd.DataFrame())
    stats = context.metrics.get("stats", {})
    robustness = context.metrics.get("robustness", {})
    config = context.metrics.get("config")

    start_capital = safe_float(getattr(config, "start_capital", 160000.0), 160000.0)
    baseline_final_capital = safe_float(stats.get("final_capital"), start_capital)
    controlled_final_capital = baseline_final_capital
    if not trade_quality.empty and "v3_pnl" in trade_quality.columns:
        controlled_final_capital = start_capital + safe_float(trade_quality["v3_pnl"].sum())

    controlled_return_pct = safe_ratio(controlled_final_capital - start_capital, start_capital) * 100.0
    baseline_return_pct = safe_ratio(baseline_final_capital - start_capital, start_capital) * 100.0

    if not trade_quality.empty:
        baseline_wins = trade_quality.loc[trade_quality["pnl"] > 0, "pnl"]
        baseline_losses = trade_quality.loc[trade_quality["pnl"] < 0, "pnl"]
        v3_wins = trade_quality.loc[trade_quality["v3_pnl"] > 0, "v3_pnl"] if "v3_pnl" in trade_quality.columns else pd.Series(dtype=float)
        v3_losses = trade_quality.loc[trade_quality["v3_pnl"] < 0, "v3_pnl"] if "v3_pnl" in trade_quality.columns else pd.Series(dtype=float)
        avg_win = safe_float(v3_wins.mean() if not v3_wins.empty else baseline_wins.mean())
        avg_loss = abs(safe_float(v3_losses.mean() if not v3_losses.empty else baseline_losses.mean()))
    else:
        avg_win = 0.0
        avg_loss = 0.0

    overtrading_detected = bool(
        safe_float(robustness.get("suppression_rate")) >= 25.0
        or safe_float(stats.get("trades_per_day")) >= 3.5
    )

    if not monthly.empty and "pnl" in monthly.columns:
        best_row = monthly.sort_values("pnl", ascending=False).iloc[0]
        worst_row = monthly.sort_values("pnl", ascending=True).iloc[0]
        best_month = str(best_row["month"])
        worst_month = str(worst_row["month"])
    else:
        best_month = "N/A"
        worst_month = "N/A"

    robustness_score = safe_float(robustness.get("robustness_score"))
    fail_probability = safe_float(robustness.get("final_fail_probability")) * 100.0

    if robustness_score >= 75 and fail_probability <= 25:
        conclusion = "Institutional-grade structure with strong FTMO survivability under controlled execution."
    elif robustness_score >= 60:
        conclusion = "Operationally viable with controls, but selective execution discipline remains essential."
    else:
        conclusion = "Profitable characteristics exist, but robustness is still below institutional deployment comfort."

    return {
        "ftmo_status": str(stats.get("ftmo_status", "UNKNOWN")),
        "challenge_status": str(stats.get("challenge_status", "UNKNOWN")),
        "start_capital": start_capital,
        "baseline_final_capital": baseline_final_capital,
        "final_capital": controlled_final_capital,
        "baseline_return_pct": baseline_return_pct,
        "total_return_pct": controlled_return_pct,
        "profit_factor": safe_float(robustness.get("v3_profit_factor"), safe_float(stats.get("profit_factor"))),
        "baseline_profit_factor": safe_float(robustness.get("baseline_profit_factor"), safe_float(stats.get("profit_factor"))),
        "sharpe_ratio": safe_float(robustness.get("rolling_sharpe_final"), safe_float(stats.get("sharpe"))),
        "max_drawdown_eur": safe_float(robustness.get("v3_max_drawdown_eur"), safe_float(stats.get("max_drawdown"))),
        "max_drawdown_pct": safe_float(stats.get("max_drawdown")),
        "best_month": best_month,
        "worst_month": worst_month,
        "overtrading_detected": overtrading_detected,
        "robustness_score": robustness_score,
        "fail_probability_pct": fail_probability,
        "survival_probability_pct": safe_float(robustness.get("monte_carlo_survival_probability")) * 100.0,
        "suppression_rate": safe_float(robustness.get("suppression_rate")),
        "recovery_factor": safe_float(robustness.get("recovery_factor")),
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "rr_ratio": safe_ratio(avg_win, avg_loss),
        "stress_score": safe_float(robustness.get("average_stress_score")),
        "institutional_conclusion": conclusion,
    }


def write_dataset_exports(context: ReportContext) -> None:
    for name, dataset in context.datasets.items():
        if isinstance(dataset, pd.DataFrame) and not dataset.empty:
            dataset.to_csv(context.paths.data_dir / f"{name}.csv", index=False)


def write_summary_file(context: ReportContext) -> Path:
    metrics = context.summary_metrics
    lines = [
        "FTMO XAUUSD EXECUTIVE SUMMARY",
        f"Generated: {context.generated_at.strftime('%Y-%m-%d %H:%M:%S')}",
        f"FTMO status: {metrics['ftmo_status']}",
        f"Challenge status: {metrics['challenge_status']}",
        f"Final capital: {format_currency(metrics['final_capital'])}",
        f"Total return: {format_percent(metrics['total_return_pct'])}",
        f"Profit factor: {format_number(metrics['profit_factor'])}",
        f"Sharpe ratio: {format_number(metrics['sharpe_ratio'])}",
        f"Max drawdown: {format_currency(metrics['max_drawdown_eur'])} | {format_percent(metrics['max_drawdown_pct'])}",
        f"Best month: {metrics['best_month']}",
        f"Worst month: {metrics['worst_month']}",
        f"Overtrading detected: {'YES' if metrics['overtrading_detected'] else 'NO'}",
        f"Robustness score: {format_number(metrics['robustness_score'])}/100",
        f"Fail probability: {format_percent(metrics['fail_probability_pct'])}",
        f"Institutional conclusion: {metrics['institutional_conclusion']}",
        "",
        context.summary_text.strip(),
    ]
    context.paths.summary_file.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")
    return context.paths.summary_file


def _setup_chart(title: str, subtitle: str | None = None) -> tuple[plt.Figure, plt.Axes]:
    fig, ax = plt.subplots(figsize=(12, 6), facecolor=CHART_THEME["bg"])
    ax.set_facecolor(CHART_THEME["panel"])
    for spine in ax.spines.values():
        spine.set_color(CHART_THEME["grid"])
    ax.tick_params(colors=CHART_THEME["muted"])
    ax.grid(True, color=CHART_THEME["grid"], alpha=0.28, linewidth=0.8)
    ax.set_title(title, color=CHART_THEME["white"], fontsize=15, fontweight="bold", loc="left", pad=12)
    if subtitle:
        ax.text(0.0, 1.02, subtitle, transform=ax.transAxes, color=CHART_THEME["muted"], fontsize=9, va="bottom")
    return fig, ax


def _save_chart(fig: plt.Figure, output_path: Path) -> Path:
    fig.savefig(output_path, dpi=200, facecolor=CHART_THEME["bg"], bbox_inches="tight")
    plt.close(fig)
    return output_path


def copy_existing_dashboard(image_paths: Dict[str, Path], source_path: Path, destination_dir: Path) -> None:
    if source_path.exists():
        copied = destination_dir / source_path.name
        shutil.copy2(source_path, copied)
        image_paths[source_path.stem] = copied


def build_supporting_images(context: ReportContext) -> Dict[str, Path]:
    LOGGER.info("Generating supporting dashboard images for PDF reports")
    image_paths: Dict[str, Path] = {}

    dashboard_candidates = context.metrics.get("dashboard_paths", [])
    for candidate in dashboard_candidates:
        candidate_path = Path(candidate)
        copy_existing_dashboard(image_paths, candidate_path, context.paths.images_dir)

    trade_quality = context.datasets.get("trade_quality", pd.DataFrame())
    risk = context.datasets.get("risk", pd.DataFrame())
    monthly = context.datasets.get("monthly", pd.DataFrame())
    monte_carlo = context.datasets.get("monte_carlo", pd.DataFrame())
    payout = context.datasets.get("payout", pd.DataFrame())
    robustness = context.metrics.get("robustness", {})
    start_capital = safe_float(context.summary_metrics.get("start_capital"), 160000.0)

    if not trade_quality.empty:
        baseline_equity = start_capital + trade_quality["pnl"].fillna(0.0).cumsum()
        v3_equity = start_capital + trade_quality["v3_pnl"].fillna(0.0).cumsum()
        drawdown = compute_drawdown(v3_equity)

        fig, ax = _setup_chart("Controlled Equity Curve", "Baseline versus V3-controlled path")
        x = np.arange(1, len(trade_quality) + 1)
        ax.plot(x, baseline_equity, color=CHART_THEME["muted"], linewidth=1.4, label="Baseline")
        ax.plot(x, v3_equity, color=CHART_THEME["green"], linewidth=2.0, label="V3 controlled")
        ax.yaxis.set_major_formatter(euro_formatter())
        ax.legend(facecolor=CHART_THEME["panel"], edgecolor=CHART_THEME["grid"], labelcolor=CHART_THEME["text"])
        image_paths["equity_curve"] = _save_chart(fig, context.paths.images_dir / "equity_curve.png")

        fig, ax = _setup_chart("Drawdown Analysis", "Controlled drawdown depth over trade sequence")
        ax.fill_between(x, drawdown["drawdown_eur"], 0, color=CHART_THEME["red"], alpha=0.28)
        ax.plot(x, drawdown["drawdown_eur"], color=CHART_THEME["red"], linewidth=1.7)
        ax.axhline(0, color=CHART_THEME["grid"], linewidth=1.0)
        ax.yaxis.set_major_formatter(euro_formatter())
        image_paths["drawdown_curve"] = _save_chart(fig, context.paths.images_dir / "drawdown_curve.png")

        fig, ax = _setup_chart("Rolling Performance Quality", "Expectancy, rolling PF and rolling Sharpe")
        ax.plot(trade_quality.index + 1, trade_quality["v3_expectancy_curve"], color=CHART_THEME["amber"], linewidth=1.5, label="Expectancy")
        ax.plot(trade_quality.index + 1, trade_quality["rolling_pf_v3"], color=CHART_THEME["cyan"], linewidth=1.5, label="Rolling PF")
        ax.plot(trade_quality.index + 1, trade_quality["rolling_sharpe_v3"], color=CHART_THEME["violet"], linewidth=1.5, label="Rolling Sharpe")
        ax.axhline(0, color=CHART_THEME["grid"], linewidth=1.0)
        ax.legend(facecolor=CHART_THEME["panel"], edgecolor=CHART_THEME["grid"], labelcolor=CHART_THEME["text"])
        image_paths["rolling_quality"] = _save_chart(fig, context.paths.images_dir / "rolling_quality.png")

        winners_vs_losers = pd.DataFrame(
            {
                "Baseline": [(trade_quality["pnl"] > 0).sum(), (trade_quality["pnl"] <= 0).sum()],
                "V3": [(trade_quality["v3_pnl"] > 0).sum(), (trade_quality["v3_pnl"] <= 0).sum()],
            },
            index=["Winners", "Losers"],
        )
        fig, ax = _setup_chart("Winners Vs Losers", "Raw counts before and after suppression")
        winners_vs_losers.plot(kind="bar", ax=ax, color=[CHART_THEME["blue"], CHART_THEME["green"]], alpha=0.92)
        ax.tick_params(axis="x", rotation=0)
        image_paths["winners_vs_losers"] = _save_chart(fig, context.paths.images_dir / "winners_vs_losers.png")

    if not monthly.empty:
        fig, ax = _setup_chart("Monthly Performance", "Net PnL by month")
        colors_row = np.where(monthly["pnl"] >= 0, CHART_THEME["green"], CHART_THEME["red"])
        ax.bar(monthly["month"].astype(str), monthly["pnl"], color=colors_row, alpha=0.95)
        ax.axhline(0, color=CHART_THEME["grid"], linewidth=1.0)
        ax.yaxis.set_major_formatter(euro_formatter())
        ax.tick_params(axis="x", rotation=20)
        image_paths["monthly_performance"] = _save_chart(fig, context.paths.images_dir / "monthly_performance.png")

    if not risk.empty:
        risk = risk.copy()
        if "date" in risk.columns:
            risk["date"] = pd.to_datetime(risk["date"])
        fig, ax = _setup_chart("Risk Zones", "Daily FTMO buffer versus minimum equity threshold")
        x_axis = risk["date"] if "date" in risk.columns else np.arange(len(risk))
        buffer_series = risk["buffer_to_min_equity_v3"] if "buffer_to_min_equity_v3" in risk.columns else risk.get("buffer_to_min_equity", pd.Series(dtype=float))
        ax.plot(x_axis, buffer_series, color=CHART_THEME["green"], linewidth=1.8, label="Buffer to min equity")
        ax.axhline(8000, color=CHART_THEME["amber"], linestyle="--", linewidth=1.1, label="Warning buffer")
        ax.axhline(4000, color=CHART_THEME["red"], linestyle="--", linewidth=1.1, label="Danger buffer")
        ax.legend(facecolor=CHART_THEME["panel"], edgecolor=CHART_THEME["grid"], labelcolor=CHART_THEME["text"])
        ax.yaxis.set_major_formatter(euro_formatter())
        image_paths["risk_zones"] = _save_chart(fig, context.paths.images_dir / "risk_zones.png")

        fig, ax = _setup_chart("Stress And Fail Probability", "Modelled fragility through time")
        fail_probability = risk["fail_probability_v3"] if "fail_probability_v3" in risk.columns else risk.get("fail_probability", pd.Series(dtype=float))
        ax.plot(x_axis, risk["stress_score"], color=CHART_THEME["amber"], linewidth=1.8, label="Stress score")
        ax.plot(x_axis, fail_probability * 100.0, color=CHART_THEME["red"], linewidth=1.6, label="Fail probability %")
        ax.legend(facecolor=CHART_THEME["panel"], edgecolor=CHART_THEME["grid"], labelcolor=CHART_THEME["text"])
        image_paths["stress_fail"] = _save_chart(fig, context.paths.images_dir / "stress_fail.png")

    if not trade_quality.empty:
        session_matrix = (
            trade_quality.pivot_table(index="weekday", columns="session_label", values="v3_pnl", aggfunc="mean")
            .reindex(["Mon", "Tue", "Wed", "Thu", "Fri"])
            .fillna(0.0)
        )
        fig, ax = _setup_chart("Session Heatmap", "Average V3 PnL by weekday and session")
        heatmap = ax.imshow(session_matrix.to_numpy(), cmap="viridis", aspect="auto")
        ax.set_xticks(np.arange(session_matrix.shape[1]))
        ax.set_xticklabels([str(col) for col in session_matrix.columns], rotation=15)
        ax.set_yticks(np.arange(session_matrix.shape[0]))
        ax.set_yticklabels([str(idx) for idx in session_matrix.index])
        for row_idx in range(session_matrix.shape[0]):
            for col_idx in range(session_matrix.shape[1]):
                ax.text(col_idx, row_idx, f"{session_matrix.iloc[row_idx, col_idx]:.0f}", ha="center", va="center", color=CHART_THEME["white"], fontsize=8)
        fig.colorbar(heatmap, ax=ax, fraction=0.046, pad=0.04)
        image_paths["session_heatmap"] = _save_chart(fig, context.paths.images_dir / "session_heatmap.png")

        hourly_matrix = (
            trade_quality.pivot_table(index="weekday", columns="entry_hour", values="v3_pnl", aggfunc="mean")
            .reindex(["Mon", "Tue", "Wed", "Thu", "Fri"])
            .fillna(0.0)
        )
        fig, ax = _setup_chart("Hourly Heatmap", "Average V3 PnL by weekday and entry hour")
        heatmap = ax.imshow(hourly_matrix.to_numpy(), cmap="magma", aspect="auto")
        ticks = list(range(0, hourly_matrix.shape[1], max(1, hourly_matrix.shape[1] // 8)))
        ax.set_xticks(ticks)
        ax.set_xticklabels([str(hourly_matrix.columns[idx]) for idx in ticks])
        ax.set_yticks(np.arange(hourly_matrix.shape[0]))
        ax.set_yticklabels([str(idx) for idx in hourly_matrix.index])
        fig.colorbar(heatmap, ax=ax, fraction=0.046, pad=0.04)
        image_paths["hourly_heatmap"] = _save_chart(fig, context.paths.images_dir / "hourly_heatmap.png")

    if not monte_carlo.empty:
        fig, ax = _setup_chart("Monte Carlo Confidence Cone", "Median, interquartile range and tail bands")
        steps = monte_carlo["step"]
        ax.plot(steps, monte_carlo["median_equity"], color=CHART_THEME["white"], linewidth=1.7, label="Median")
        ax.fill_between(steps, monte_carlo["q25_equity"], monte_carlo["q75_equity"], color=CHART_THEME["blue"], alpha=0.20, label="25-75%")
        ax.fill_between(steps, monte_carlo["q05_equity"], monte_carlo["q95_equity"], color=CHART_THEME["cyan"], alpha=0.12, label="5-95%")
        ax.axhline(context.summary_metrics["start_capital"] * 0.90, color=CHART_THEME["red"], linestyle="--", linewidth=1.1, label="FTMO min equity")
        ax.yaxis.set_major_formatter(euro_formatter())
        ax.legend(facecolor=CHART_THEME["panel"], edgecolor=CHART_THEME["grid"], labelcolor=CHART_THEME["text"])
        image_paths["monte_carlo"] = _save_chart(fig, context.paths.images_dir / "monte_carlo_cone.png")

    if robustness:
        labels = ["Robustness", "Survival", "Walk-Forward", "Scalability"]
        values = [
            safe_float(robustness.get("robustness_score")),
            safe_float(robustness.get("monte_carlo_survival_probability")) * 100.0,
            safe_float(robustness.get("walkforward_score")),
            safe_float(robustness.get("scalability_score")),
        ]
        fig, ax = _setup_chart("Robustness Scorecard", "Composite institutional readiness overview")
        ax.bar(labels, values, color=[CHART_THEME["blue"], CHART_THEME["green"], CHART_THEME["amber"], CHART_THEME["cyan"]], alpha=0.94)
        ax.set_ylim(0, 100)
        for idx, value in enumerate(values):
            ax.text(idx, value + 2, f"{value:.1f}", ha="center", color=CHART_THEME["white"], fontsize=9)
        image_paths["robustness"] = _save_chart(fig, context.paths.images_dir / "robustness_scorecard.png")

    if not payout.empty:
        balance_col = "ending_balance_after_payout" if "ending_balance_after_payout" in payout.columns else "balance_after_payout"
        fig, ax = _setup_chart("Payout Simulation", "Balance path after monthly payouts")
        ax.plot(payout["month"].astype(str), payout[balance_col], color=CHART_THEME["gold"] if "gold" in CHART_THEME else CHART_THEME["amber"], linewidth=1.9, marker="o")
        ax.yaxis.set_major_formatter(euro_formatter())
        ax.tick_params(axis="x", rotation=20)
        image_paths["payout"] = _save_chart(fig, context.paths.images_dir / "payout_simulation.png")

    return image_paths


def build_report_context(
    base_dir: Path,
    datasets: Mapping[str, pd.DataFrame],
    metrics: Mapping[str, Any],
    summary_text: str,
) -> ReportContext:
    generated_at = datetime.now()
    paths = create_export_paths(base_dir)
    prepare_latest_workspace(paths)
    configure_file_logging(paths)

    context = ReportContext(
        base_dir=base_dir,
        generated_at=generated_at,
        paths=paths,
        datasets={key: value.copy() if isinstance(value, pd.DataFrame) else value for key, value in datasets.items()},
        metrics=dict(metrics),
        summary_text=summary_text,
    )
    context.summary_metrics = extract_summary_metrics(context)
    write_dataset_exports(context)
    write_summary_file(context)
    context.image_paths = build_supporting_images(context)
    return context


def build_styles() -> Dict[str, ParagraphStyle]:
    sheet = getSampleStyleSheet()
    styles = {
        "title": ParagraphStyle(
            "ReportTitle",
            parent=sheet["Title"],
            fontName="Helvetica-Bold",
            fontSize=22,
            leading=26,
            textColor=PDF_THEME["navy"],
            alignment=TA_LEFT,
            spaceAfter=12,
        ),
        "hero": ParagraphStyle(
            "Hero",
            parent=sheet["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=18,
            leading=22,
            textColor=PDF_THEME["white"],
            alignment=TA_LEFT,
        ),
        "section": ParagraphStyle(
            "Section",
            parent=sheet["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=14,
            leading=17,
            textColor=PDF_THEME["navy"],
            spaceBefore=8,
            spaceAfter=8,
        ),
        "body": ParagraphStyle(
            "Body",
            parent=sheet["BodyText"],
            fontName="Helvetica",
            fontSize=9.6,
            leading=13,
            textColor=PDF_THEME["text"],
            spaceAfter=5,
        ),
        "muted": ParagraphStyle(
            "Muted",
            parent=sheet["BodyText"],
            fontName="Helvetica",
            fontSize=8.5,
            leading=11,
            textColor=PDF_THEME["muted"],
            spaceAfter=4,
        ),
        "small": ParagraphStyle(
            "Small",
            parent=sheet["BodyText"],
            fontName="Helvetica",
            fontSize=8.0,
            leading=10,
            textColor=PDF_THEME["text"],
        ),
    }
    return styles


def make_paragraph(text: str, style: ParagraphStyle) -> Paragraph:
    safe_text = text.replace("\n", "<br/>")
    return Paragraph(safe_text, style)


def add_page_chrome(canvas, doc) -> None:
    canvas.saveState()
    page_width, page_height = A4
    canvas.setFillColor(PDF_THEME["navy"])
    canvas.rect(0, page_height - 1.7 * cm, page_width, 1.7 * cm, fill=1, stroke=0)
    canvas.rect(0, 0, page_width, 1.1 * cm, fill=1, stroke=0)
    canvas.setFillColor(PDF_THEME["white"])
    canvas.setFont("Helvetica-Bold", 11)
    canvas.drawString(1.5 * cm, page_height - 1.05 * cm, "FTMO XAUUSD Institutional Analytics")
    canvas.setFont("Helvetica", 8)
    canvas.drawRightString(page_width - 1.5 * cm, page_height - 1.05 * cm, datetime.now().strftime("%Y-%m-%d %H:%M"))
    canvas.drawString(1.5 * cm, 0.45 * cm, "Generated automatically after backtest run")
    canvas.drawRightString(page_width - 1.5 * cm, 0.45 * cm, f"Page {canvas.getPageNumber()}")
    canvas.restoreState()


def build_table(rows: Sequence[Sequence[Any]], column_widths: Sequence[float] | None = None, header_fill: colors.Color | None = None) -> Table:
    table = Table(rows, colWidths=column_widths, repeatRows=1)
    header_fill = header_fill or PDF_THEME["navy"]
    style = TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), header_fill),
            ("TEXTCOLOR", (0, 0), (-1, 0), PDF_THEME["white"]),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8.2),
            ("LEADING", (0, 0), (-1, -1), 10),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PDF_THEME["paper"]]),
            ("GRID", (0, 0), (-1, -1), 0.35, PDF_THEME["grid"]),
            ("BOX", (0, 0), (-1, -1), 0.5, PDF_THEME["grid"]),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]
    )
    table.setStyle(style)
    return table


def df_head_table(df: pd.DataFrame, columns: Sequence[str], rename: Mapping[str, str] | None = None, max_rows: int = 12) -> Table:
    rename = rename or {}
    working = df.loc[:, [col for col in columns if col in df.columns]].head(max_rows).copy()
    for column in working.columns:
        if pd.api.types.is_numeric_dtype(working[column]):
            if "pct" in column.lower() or "rate" in column.lower() or "prob" in column.lower():
                working[column] = working[column].map(lambda value: format_percent(value))
            elif any(token in column.lower() for token in ["pnl", "drawdown", "equity", "profit", "loss", "buffer", "balance", "capital", "expectancy", "cost", "payout"]):
                working[column] = working[column].map(format_currency)
            else:
                working[column] = working[column].map(lambda value: format_number(value))
        else:
            working[column] = working[column].astype(str)
    headers = [rename.get(col, col.replace("_", " ").title()) for col in working.columns]
    rows = [headers] + working.values.tolist()
    return build_table(rows)


def metric_card_table(pairs: Sequence[tuple[str, str]]) -> Table:
    rows = []
    row: List[Any] = []
    for idx, (label, value) in enumerate(pairs, start=1):
        cell = f"<b>{label}</b><br/>{value}"
        row.append(Paragraph(cell, ParagraphStyle("Card", fontName="Helvetica", fontSize=9, leading=11, textColor=PDF_THEME["text"])))
        if idx % 3 == 0:
            rows.append(row)
            row = []
    if row:
        while len(row) < 3:
            row.append("")
        rows.append(row)
    table = Table(rows, colWidths=[6.0 * cm, 6.0 * cm, 6.0 * cm])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), PDF_THEME["paper"]),
                ("BOX", (0, 0), (-1, -1), 0.8, PDF_THEME["grid"]),
                ("GRID", (0, 0), (-1, -1), 0.45, PDF_THEME["grid"]),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
            ]
        )
    )
    return table


def scaled_image(path: Path, width_cm: float = 17.5, height_cm: float = 9.5) -> Image | Spacer:
    if not path.exists():
        return Spacer(1, 0.2 * cm)
    return Image(str(path), width=width_cm * cm, height=height_cm * cm)


def build_pdf(output_path: Path, story: List[Any]) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=1.4 * cm,
        rightMargin=1.4 * cm,
        topMargin=2.2 * cm,
        bottomMargin=1.7 * cm,
    )
    doc.build(story, onFirstPage=add_page_chrome, onLaterPages=add_page_chrome)
    return output_path


def build_executive_summary_story(context: ReportContext, styles: Dict[str, ParagraphStyle]) -> List[Any]:
    metrics = context.summary_metrics
    cards = [
        ("FTMO Status", metrics["ftmo_status"]),
        ("Final Capital", format_currency(metrics["final_capital"])),
        ("Total Return", format_percent(metrics["total_return_pct"])),
        ("Profit Factor", format_number(metrics["profit_factor"])),
        ("Sharpe Ratio", format_number(metrics["sharpe_ratio"])),
        ("Max Drawdown", format_currency(metrics["max_drawdown_eur"])),
        ("Best Month", metrics["best_month"]),
        ("Worst Month", metrics["worst_month"]),
        ("Overtrading", "Detected" if metrics["overtrading_detected"] else "Controlled"),
        ("Robustness Score", f"{format_number(metrics['robustness_score'])}/100"),
        ("Fail Probability", format_percent(metrics["fail_probability_pct"])),
        ("Survival Probability", format_percent(metrics["survival_probability_pct"])),
    ]
    return [
        make_paragraph("Executive Summary", styles["section"]),
        metric_card_table(cards),
        Spacer(1, 0.35 * cm),
        make_paragraph(metrics["institutional_conclusion"], styles["body"]),
    ]


def build_ftmo_full_report(context: ReportContext) -> Path:
    styles = build_styles()
    metrics = context.summary_metrics
    story: List[Any] = []

    story.append(make_paragraph("FTMO XAUUSD Full Institutional Report", styles["title"]))
    story.append(make_paragraph("Automated post-backtest dossier with dashboard visuals, risk intelligence and robustness validation.", styles["muted"]))
    story.append(Spacer(1, 0.3 * cm))
    story.extend(build_executive_summary_story(context, styles))
    story.append(Spacer(1, 0.4 * cm))
    if "ftmo_dashboard_v3" in context.image_paths:
        story.append(scaled_image(context.image_paths["ftmo_dashboard_v3"], 17.8, 10.5))
    elif "ftmo_dashboard" in context.image_paths:
        story.append(scaled_image(context.image_paths["ftmo_dashboard"], 17.8, 10.5))

    story.append(PageBreak())
    story.append(make_paragraph("FTMO Status And KPI Overview", styles["section"]))
    story.append(
        metric_card_table(
            [
                ("Challenge Status", metrics["challenge_status"]),
                ("Baseline Capital", format_currency(metrics["baseline_final_capital"])),
                ("Controlled Capital", format_currency(metrics["final_capital"])),
                ("Baseline PF", format_number(metrics["baseline_profit_factor"])),
                ("Controlled PF", format_number(metrics["profit_factor"])),
                ("Recovery Factor", format_number(metrics["recovery_factor"])),
            ]
        )
    )
    story.append(Spacer(1, 0.3 * cm))
    story.append(make_paragraph("Equity Curve", styles["section"]))
    story.append(scaled_image(context.image_paths.get("equity_curve", Path()), 17.8, 9.5))
    story.append(Spacer(1, 0.2 * cm))
    story.append(make_paragraph("Drawdown Analysis", styles["section"]))
    story.append(scaled_image(context.image_paths.get("drawdown_curve", Path()), 17.8, 8.8))

    monthly = context.datasets.get("monthly", pd.DataFrame())
    story.append(PageBreak())
    story.append(make_paragraph("Monthly Performance", styles["section"]))
    if not monthly.empty:
        story.append(
            df_head_table(
                monthly,
                ["month", "trades", "pnl", "return_pct", "win_rate", "profit_factor", "max_drawdown_pct", "ftmo_status"],
                rename={"pnl": "Net PnL", "return_pct": "Return %", "win_rate": "Win %", "profit_factor": "PF", "max_drawdown_pct": "Max DD %"},
                max_rows=12,
            )
        )
        story.append(Spacer(1, 0.25 * cm))
        story.append(scaled_image(context.image_paths.get("monthly_performance", Path()), 17.8, 8.8))
    else:
        story.append(make_paragraph("Monthly dataset unavailable.", styles["body"]))

    risk = context.datasets.get("risk", pd.DataFrame())
    story.append(PageBreak())
    story.append(make_paragraph("Risk Analysis", styles["section"]))
    if not risk.empty:
        story.append(
            df_head_table(
                risk.sort_values("date", ascending=False),
                ["date", "daily_pnl_v3", "daily_drawdown_v3", "buffer_to_min_equity_v3", "stress_score", "fail_probability_v3", "risk_mode", "ftmo_buffer_zone"],
                rename={"daily_pnl_v3": "Daily PnL", "daily_drawdown_v3": "Daily DD", "buffer_to_min_equity_v3": "Equity Buffer", "fail_probability_v3": "Fail Prob"},
                max_rows=10,
            )
        )
        story.append(Spacer(1, 0.25 * cm))
        story.append(scaled_image(context.image_paths.get("risk_zones", Path()), 17.8, 8.6))
        story.append(Spacer(1, 0.15 * cm))
        story.append(scaled_image(context.image_paths.get("stress_fail", Path()), 17.8, 8.6))
    else:
        story.append(make_paragraph("Risk dataset unavailable.", styles["body"]))

    regime = context.datasets.get("regime", pd.DataFrame())
    session = context.datasets.get("session", pd.DataFrame())
    story.append(PageBreak())
    story.append(make_paragraph("Regime Analysis", styles["section"]))
    if not regime.empty:
        story.append(
            df_head_table(
                regime.sort_values("actual_pnl", ascending=False),
                ["regime_label", "trade_count", "suppression_rate", "actual_pnl", "v3_pnl", "avg_quality_score", "avg_risk_multiplier"],
                rename={"actual_pnl": "Baseline PnL", "v3_pnl": "V3 PnL", "avg_quality_score": "Avg Quality", "avg_risk_multiplier": "Risk Mult"},
                max_rows=10,
            )
        )
    else:
        story.append(make_paragraph("Regime analysis unavailable.", styles["body"]))

    story.append(Spacer(1, 0.25 * cm))
    story.append(make_paragraph("Session Analysis", styles["section"]))
    if not session.empty:
        story.append(
            df_head_table(
                session[session["analysis_type"] == "session"].sort_values("v3_pnl", ascending=False),
                ["bucket", "trades", "executed_trades", "blocked_trades", "baseline_pnl", "v3_pnl", "profit_factor_v3", "expectancy_v3"],
                rename={"bucket": "Session", "baseline_pnl": "Baseline PnL", "v3_pnl": "V3 PnL", "profit_factor_v3": "PF V3", "expectancy_v3": "Exp V3"},
                max_rows=8,
            )
        )
        story.append(Spacer(1, 0.2 * cm))
        story.append(scaled_image(context.image_paths.get("session_heatmap", Path()), 17.8, 7.8))
        story.append(Spacer(1, 0.15 * cm))
        story.append(scaled_image(context.image_paths.get("hourly_heatmap", Path()), 17.8, 7.8))
    else:
        story.append(make_paragraph("Session analysis unavailable.", styles["body"]))

    monte_carlo = context.datasets.get("monte_carlo", pd.DataFrame())
    walkforward = context.datasets.get("walkforward", pd.DataFrame())
    robustness_report = context.datasets.get("robustness_report", pd.DataFrame())
    story.append(PageBreak())
    story.append(make_paragraph("Monte Carlo And Robustness", styles["section"]))
    story.append(scaled_image(context.image_paths.get("monte_carlo", Path()), 17.8, 8.8))
    story.append(Spacer(1, 0.2 * cm))
    story.append(scaled_image(context.image_paths.get("robustness", Path()), 17.8, 7.5))
    if not walkforward.empty:
        story.append(Spacer(1, 0.2 * cm))
        story.append(df_head_table(walkforward, ["test_month", "allowed_regimes", "test_profit_factor", "test_expectancy", "walkforward_score", "overfit_probability"], max_rows=8))
    if not robustness_report.empty:
        story.append(Spacer(1, 0.2 * cm))
        story.append(df_head_table(robustness_report, ["metric", "value"], max_rows=15))
    if monte_carlo.empty and walkforward.empty:
        story.append(make_paragraph("Monte Carlo and walk-forward datasets unavailable.", styles["body"]))

    payout = context.datasets.get("payout", pd.DataFrame())
    story.append(PageBreak())
    story.append(make_paragraph("Payout Simulation", styles["section"]))
    if not payout.empty:
        story.append(
            df_head_table(
                payout,
                ["month", "gross_profit", "trader_payout", "firm_share", "ending_balance_after_payout"],
                rename={"ending_balance_after_payout": "Balance After Payout"},
                max_rows=12,
            )
        )
        story.append(Spacer(1, 0.2 * cm))
        story.append(scaled_image(context.image_paths.get("payout", Path()), 17.8, 7.8))
    else:
        story.append(make_paragraph("Payout simulation unavailable.", styles["body"]))

    story.append(PageBreak())
    story.append(make_paragraph("Institutional Summary", styles["section"]))
    for line in [line.strip() for line in context.summary_text.splitlines() if line.strip()]:
        story.append(make_paragraph(line, styles["body"]))

    output_path = context.paths.reports_dir / "ftmo_full_report.pdf"
    return build_pdf(output_path, story)


def build_trade_report(context: ReportContext) -> Path:
    styles = build_styles()
    trade_quality = context.datasets.get("trade_quality", pd.DataFrame())
    story: List[Any] = [make_paragraph("FTMO Trade Analytics Report", styles["title"])]

    if trade_quality.empty:
        story.append(make_paragraph("Trade analytics dataset unavailable.", styles["body"]))
        return build_pdf(context.paths.reports_dir / "ftmo_trade_analytics.pdf", story)

    executed = int(trade_quality["v3_executed"].sum())
    blocked = int(trade_quality["suppressed"].sum())
    expectancy_v3 = safe_float(trade_quality["v3_pnl"].mean())
    expectancy_base = safe_float(trade_quality["pnl"].mean())
    longest_win_streak = int((trade_quality["v3_pnl"] > 0).astype(int).groupby((trade_quality["v3_pnl"] <= 0).cumsum()).cumsum().max())
    longest_loss_streak = int((trade_quality["v3_pnl"] < 0).astype(int).groupby((trade_quality["v3_pnl"] >= 0).cumsum()).cumsum().max())

    story.append(
        metric_card_table(
            [
                ("Trades", str(len(trade_quality))),
                ("Executed", str(executed)),
                ("Blocked", str(blocked)),
                ("Baseline Expectancy", format_currency(expectancy_base)),
                ("V3 Expectancy", format_currency(expectancy_v3)),
                ("RR Ratio", format_number(context.summary_metrics["rr_ratio"])),
                ("Longest Win Streak", str(longest_win_streak)),
                ("Longest Loss Streak", str(longest_loss_streak)),
                ("Suppression Rate", format_percent(context.summary_metrics["suppression_rate"])),
            ]
        )
    )
    story.append(Spacer(1, 0.25 * cm))
    story.append(make_paragraph("Trade Statistics", styles["section"]))
    story.append(df_head_table(trade_quality, ["entry_time", "session_label", "regime_label", "pnl", "v3_pnl", "dynamic_risk_pct", "trade_quality_score", "suppression_reasons"], max_rows=14))
    story.append(Spacer(1, 0.2 * cm))
    story.append(make_paragraph("Rolling Profit Factor And Expectancy", styles["section"]))
    story.append(scaled_image(context.image_paths.get("rolling_quality", Path()), 17.8, 8.6))
    story.append(Spacer(1, 0.2 * cm))
    story.append(make_paragraph("Winners Vs Losers", styles["section"]))
    story.append(scaled_image(context.image_paths.get("winners_vs_losers", Path()), 17.8, 7.5))

    return build_pdf(context.paths.reports_dir / "ftmo_trade_analytics.pdf", story)


def build_risk_report(context: ReportContext) -> Path:
    styles = build_styles()
    risk = context.datasets.get("risk", pd.DataFrame())
    story: List[Any] = [make_paragraph("FTMO Risk Report", styles["title"])]

    story.append(
        metric_card_table(
            [
                ("FTMO Status", context.summary_metrics["ftmo_status"]),
                ("Max Drawdown", format_currency(context.summary_metrics["max_drawdown_eur"])),
                ("Stress Score", format_number(context.summary_metrics["stress_score"])),
                ("Fail Probability", format_percent(context.summary_metrics["fail_probability_pct"])),
                ("Survival Probability", format_percent(context.summary_metrics["survival_probability_pct"])),
                ("Robustness Score", f"{format_number(context.summary_metrics['robustness_score'])}/100"),
            ]
        )
    )
    story.append(Spacer(1, 0.25 * cm))

    if not risk.empty:
        story.append(make_paragraph("FTMO Limits And Daily Risk State", styles["section"]))
        story.append(df_head_table(risk.sort_values("date", ascending=False), ["date", "daily_limit", "daily_drawdown_v3", "remaining_daily_buffer_v3", "buffer_to_min_equity_v3", "risk_mode", "ftmo_buffer_zone"], max_rows=12))
        story.append(Spacer(1, 0.2 * cm))
        story.append(scaled_image(context.image_paths.get("risk_zones", Path()), 17.8, 8.6))
        story.append(Spacer(1, 0.2 * cm))
        story.append(scaled_image(context.image_paths.get("stress_fail", Path()), 17.8, 8.6))
    else:
        story.append(make_paragraph("Risk dataset unavailable.", styles["body"]))

    return build_pdf(context.paths.reports_dir / "ftmo_risk_report.pdf", story)


def build_session_report(context: ReportContext) -> Path:
    styles = build_styles()
    session = context.datasets.get("session", pd.DataFrame())
    story: List[Any] = [make_paragraph("FTMO Session Report", styles["title"])]

    if not session.empty:
        session_only = session[session["analysis_type"] == "session"].copy()
        story.append(make_paragraph("Session Performance", styles["section"]))
        story.append(df_head_table(session_only.sort_values("v3_pnl", ascending=False), ["bucket", "trades", "executed_trades", "blocked_trades", "baseline_pnl", "v3_pnl", "profit_factor_v3", "expectancy_v3"], max_rows=10))
    else:
        story.append(make_paragraph("Session dataset unavailable.", styles["body"]))

    story.append(Spacer(1, 0.25 * cm))
    story.append(make_paragraph("Weekday / Session Heatmap", styles["section"]))
    story.append(scaled_image(context.image_paths.get("session_heatmap", Path()), 17.8, 7.8))
    story.append(Spacer(1, 0.2 * cm))
    story.append(make_paragraph("Hourly Heatmap", styles["section"]))
    story.append(scaled_image(context.image_paths.get("hourly_heatmap", Path()), 17.8, 7.8))

    return build_pdf(context.paths.reports_dir / "ftmo_session_report.pdf", story)


def build_montecarlo_report(context: ReportContext) -> Path:
    styles = build_styles()
    monte_carlo = context.datasets.get("monte_carlo", pd.DataFrame())
    walkforward = context.datasets.get("walkforward", pd.DataFrame())
    robustness_report = context.datasets.get("robustness_report", pd.DataFrame())
    story: List[Any] = [make_paragraph("FTMO Monte Carlo Report", styles["title"])]

    story.append(
        metric_card_table(
            [
                ("Survival Probability", format_percent(context.summary_metrics["survival_probability_pct"])),
                ("Fail Probability", format_percent(context.summary_metrics["fail_probability_pct"])),
                ("Robustness Score", f"{format_number(context.summary_metrics['robustness_score'])}/100"),
                ("Recovery Factor", format_number(context.summary_metrics["recovery_factor"])),
                ("Suppression Rate", format_percent(context.summary_metrics["suppression_rate"])),
                ("Institutional Verdict", context.summary_metrics["institutional_conclusion"]),
            ]
        )
    )
    story.append(Spacer(1, 0.25 * cm))
    story.append(scaled_image(context.image_paths.get("monte_carlo", Path()), 17.8, 8.7))

    if not monte_carlo.empty:
        story.append(Spacer(1, 0.2 * cm))
        story.append(df_head_table(monte_carlo, ["step", "q05_equity", "q25_equity", "median_equity", "q75_equity", "q95_equity"], max_rows=14))
    if not walkforward.empty:
        story.append(Spacer(1, 0.2 * cm))
        story.append(make_paragraph("Walk-Forward Robustness", styles["section"]))
        story.append(df_head_table(walkforward, ["test_month", "allowed_regimes", "test_profit_factor", "test_expectancy", "walkforward_score", "overfit_probability"], max_rows=10))
    if not robustness_report.empty:
        story.append(Spacer(1, 0.2 * cm))
        story.append(make_paragraph("Robustness Metrics", styles["section"]))
        story.append(df_head_table(robustness_report, ["metric", "value"], max_rows=20))

    return build_pdf(context.paths.reports_dir / "ftmo_montecarlo_report.pdf", story)


def generate_pdf_reports(context: ReportContext) -> Dict[str, Path]:
    LOGGER.info("Generating institutional PDF report package")
    report_paths = {
        "full": build_ftmo_full_report(context),
        "trade": build_trade_report(context),
        "risk": build_risk_report(context),
        "session": build_session_report(context),
        "montecarlo": build_montecarlo_report(context),
    }
    context.report_paths = report_paths
    return report_paths


def export_project_zip(context: ReportContext) -> Path:
    LOGGER.info("Creating project export zip")
    exclude_dir_names = {"__pycache__", ".git", "node_modules", ".mypy_cache", ".pytest_cache"}
    exclude_exact = {context.paths.zip_file.resolve()}
    include_latest = context.paths.latest_dir.resolve()

    with zipfile.ZipFile(context.paths.zip_file, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in context.base_dir.rglob("*"):
            if path.is_dir():
                continue
            resolved = path.resolve()
            relative = path.relative_to(context.base_dir)
            parts = set(relative.parts)
            if parts & exclude_dir_names:
                continue
            if resolved in exclude_exact:
                continue
            if relative.parts[:2] == ("exports", "history"):
                continue
            if relative.parts[:2] == ("exports", "latest") and not str(resolved).startswith(str(include_latest)):
                continue
            archive.write(path, arcname=str(relative))
    return context.paths.zip_file


def load_telegram_settings(base_dir: Path) -> TelegramSettings:
    load_dotenv(base_dir / ".env")
    return TelegramSettings(
        token=os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
        chat_id=os.getenv("TELEGRAM_CHAT_ID", "").strip(),
    )


def send_telegram_message(settings: TelegramSettings, text: str) -> None:
    response = requests.post(
        f"https://api.telegram.org/bot{settings.token}/sendMessage",
        data={"chat_id": settings.chat_id, "text": text, "parse_mode": "Markdown"},
        timeout=30,
    )
    response.raise_for_status()


def send_telegram_pdf(settings: TelegramSettings, pdf_path: Path, caption: str | None = None) -> None:
    if not pdf_path.exists():
        LOGGER.warning("Skipping missing PDF for Telegram: %s", pdf_path)
        return
    with pdf_path.open("rb") as handle:
        response = requests.post(
            f"https://api.telegram.org/bot{settings.token}/sendDocument",
            data={"chat_id": settings.chat_id, "caption": caption or pdf_path.name},
            files={"document": (pdf_path.name, handle, "application/pdf")},
            timeout=60,
        )
    response.raise_for_status()


def send_telegram_image(settings: TelegramSettings, image_path: Path, caption: str | None = None) -> None:
    if not image_path.exists():
        LOGGER.warning("Skipping missing image for Telegram: %s", image_path)
        return
    with image_path.open("rb") as handle:
        response = requests.post(
            f"https://api.telegram.org/bot{settings.token}/sendPhoto",
            data={"chat_id": settings.chat_id, "caption": caption or image_path.name},
            files={"photo": (image_path.name, handle, "image/png")},
            timeout=60,
        )
    response.raise_for_status()


def send_telegram_files(settings: TelegramSettings, files: Iterable[Path]) -> None:
    for file_path in files:
        suffix = file_path.suffix.lower()
        if suffix == ".pdf":
            send_telegram_pdf(settings, file_path)
        elif suffix in {".png", ".jpg", ".jpeg"}:
            send_telegram_image(settings, file_path)
        else:
            if not file_path.exists():
                LOGGER.warning("Skipping missing file for Telegram: %s", file_path)
                continue
            with file_path.open("rb") as handle:
                response = requests.post(
                    f"https://api.telegram.org/bot{settings.token}/sendDocument",
                    data={"chat_id": settings.chat_id, "caption": file_path.name},
                    files={"document": (file_path.name, handle, "application/octet-stream")},
                    timeout=60,
                )
            response.raise_for_status()


def build_telegram_summary(context: ReportContext) -> str:
    metrics = context.summary_metrics
    lines = [
        "*FTMO XAUUSD Performance Update*",
        f"FTMO status: `{metrics['ftmo_status']}`",
        f"Final capital: `{format_currency(metrics['final_capital'])}`",
        f"Total return: `{format_percent(metrics['total_return_pct'])}`",
        f"Profit factor: `{format_number(metrics['profit_factor'])}`",
        f"Sharpe ratio: `{format_number(metrics['sharpe_ratio'])}`",
        f"Max drawdown: `{format_currency(metrics['max_drawdown_eur'])}`",
        f"Best month: `{metrics['best_month']}`",
        f"Robustness score: `{format_number(metrics['robustness_score'])}/100`",
        f"Fail probability: `{format_percent(metrics['fail_probability_pct'])}`",
        context.summary_metrics["institutional_conclusion"],
    ]
    return "\n".join(lines)


def log_export_error(error_log_file: Path, message: str) -> None:
    error_log_file.parent.mkdir(parents=True, exist_ok=True)
    with error_log_file.open("a", encoding="utf-8") as handle:
        handle.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} | {message}\n")


def send_telegram_reports(context: ReportContext) -> bool:
    LOGGER.info("Sending reports through Telegram")
    settings = load_telegram_settings(context.base_dir)
    if not settings.configured:
        message = "Telegram settings incomplete: TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID missing in .env"
        log_export_error(context.paths.error_log_file, message)
        LOGGER.error(message)
        print(message)
        return False

    try:
        send_telegram_message(settings, build_telegram_summary(context))
        if "ftmo_dashboard_v3" in context.image_paths:
            send_telegram_image(settings, context.image_paths["ftmo_dashboard_v3"], "Primary FTMO dashboard")
        elif "ftmo_dashboard" in context.image_paths:
            send_telegram_image(settings, context.image_paths["ftmo_dashboard"], "Primary FTMO dashboard")

        send_telegram_files(settings, context.report_paths.values())
        send_telegram_files(settings, [context.paths.zip_file])
        context.telegram_success = True
        return True
    except Exception as exc:  # pragma: no cover - network dependent
        error_message = f"Telegram verzending mislukt: {exc}"
        log_export_error(context.paths.error_log_file, error_message)
        LOGGER.exception("Telegram delivery failed")
        print(error_message)
        context.telegram_success = False
        return False


def archive_export_history(context: ReportContext) -> Path:
    timestamp = context.generated_at.strftime("%Y-%m-%d_%H-%M-%S")
    archive_path = context.paths.history_dir / timestamp
    LOGGER.info("Archiving latest export bundle to %s", archive_path)

    if archive_path.exists():
        shutil.rmtree(archive_path)
    shutil.copytree(context.paths.latest_dir, archive_path)
    context.archive_path = archive_path
    return archive_path


def cleanup_latest_exports(context: ReportContext) -> None:
    LOGGER.info("Cleaning up temporary latest exports")
    for item in context.paths.latest_dir.iterdir():
        if item.is_dir():
            shutil.rmtree(item)
        else:
            item.unlink()


def run_post_backtest_exports(
    base_dir: Path,
    datasets: Mapping[str, pd.DataFrame],
    metrics: Mapping[str, Any],
    summary_text: str,
) -> ReportContext:
    context = build_report_context(base_dir, datasets, metrics, summary_text)
    generate_pdf_reports(context)
    export_project_zip(context)
    telegram_success = send_telegram_reports(context)
    archive_export_history(context)
    if telegram_success:
        cleanup_latest_exports(context)
    return context
