@echo off
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py ftmo_dashboard_v2.py
) else (
    python ftmo_dashboard_v2.py
)

echo.
echo Dashboard run completed.
pause
