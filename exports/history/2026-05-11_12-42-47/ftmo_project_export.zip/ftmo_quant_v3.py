from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd

import xauusd_backtest as baseline
from ftmo_report_pipeline import (
    archive_export_history,
    build_report_context,
    cleanup_latest_exports,
    export_project_zip,
    generate_pdf_reports,
    send_telegram_reports,
)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
LOGGER = logging.getLogger("ftmo_quant_v3")
logging.getLogger("matplotlib").setLevel(logging.WARNING)


@dataclass(frozen=True)
class FTMOQuantV3Config:
    start_capital: float = 160_000.0
    daily_loss_limit: float = 8_000.0
    max_loss_limit: float = 16_000.0
    min_equity: float = 144_000.0
    daily_profit_lock: float = 1_200.0
    weekly_profit_lock: float = 4_200.0
    monthly_profit_lock: float = 16_000.0
    base_risk_per_trade: float = 0.01
    loss_pause_hours: int = 3
    locked_seed: int = 20260515
    drift_scale: float = 0.92
    vol_scale: float = 1.00
    cycle_scale: float = 0.90
    monte_carlo_iterations: int = 750
    bootstrap_iterations: int = 2_000
    dashboard_file: str = "ftmo_dashboard_v3.png"
    regime_file: str = "ftmo_regime_analysis.csv"
    risk_file: str = "ftmo_risk_engine.csv"
    trade_quality_file: str = "ftmo_trade_quality.csv"
    session_file: str = "ftmo_session_analysis.csv"
    monte_carlo_file: str = "ftmo_monte_carlo.csv"
    walkforward_file: str = "ftmo_walkforward.csv"
    robustness_file: str = "ftmo_robustness_report.csv"
    monthly_reference_file: str = "xauusd_monthly_summary.csv"


PALETTE = {
    "bg": "#03070d",
    "panel": "#0b1320",
    "card": "#0f1a29",
    "grid": "#1f3348",
    "text": "#e6edf3",
    "muted": "#8ba3b8",
    "green": "#19d18c",
    "red": "#ff5f6d",
    "amber": "#f5b94c",
    "blue": "#4da3ff",
    "cyan": "#2ed8ff",
    "violet": "#9f7aea",
    "gold": "#ffd166",
    "soft_green": "#12392d",
    "soft_red": "#34141a",
    "soft_amber": "#3b2a10",
    "white": "#f8fbff",
}

REGIME_RISK_MULTIPLIERS = {
    "STRONG_TREND": 1.00,
    "TREND": 0.75,
    "RANGE": 0.40,
    "CHOP": 0.20,
    "EXPANSION": 0.85,
    "COMPRESSION": 0.25,
    "HIGH_RISK": 0.10,
    "NO_TRADE": 0.00,
}

REGIME_COLORS = {
    "STRONG_TREND": "#19d18c",
    "TREND": "#2bb4ff",
    "RANGE": "#f5b94c",
    "CHOP": "#ff7a45",
    "EXPANSION": "#8b5cf6",
    "COMPRESSION": "#6c7a89",
    "HIGH_RISK": "#ff5f6d",
    "NO_TRADE": "#8b949e",
}


def safe_float(value: object, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if not np.isfinite(number):
        return default
    return number


def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    denominator = safe_float(denominator)
    if abs(denominator) < 1e-12:
        return default
    return safe_float(numerator) / denominator


def calculate_profit_factor(pnl: pd.Series) -> float:
    gross_profit = safe_float(pnl[pnl > 0].sum())
    gross_loss = abs(safe_float(pnl[pnl < 0].sum()))
    if gross_loss == 0:
        return float("inf") if gross_profit > 0 else 0.0
    return gross_profit / gross_loss


def calculate_sharpe(returns: pd.Series, annualisation: float = 252.0) -> float:
    clean = pd.Series(returns).replace([np.inf, -np.inf], np.nan).dropna()
    if len(clean) < 2 or float(clean.std(ddof=0)) == 0.0:
        return 0.0
    return float((clean.mean() / clean.std(ddof=0)) * math.sqrt(annualisation))


def calculate_ulcer_index(drawdown_pct: pd.Series) -> float:
    clean = drawdown_pct.fillna(0.0).astype(float)
    if clean.empty:
        return 0.0
    return float(np.sqrt(np.mean(np.square(clean))))


def rolling_profit_factor(pnl: pd.Series, window: int = 20) -> pd.Series:
    values: List[float] = []
    pnl = pd.Series(pnl).fillna(0.0)
    for idx in range(len(pnl)):
        sample = pnl.iloc[max(0, idx - window + 1) : idx + 1]
        values.append(calculate_profit_factor(sample))
    return pd.Series(values, index=pnl.index)


def rolling_sharpe(pnl: pd.Series, window: int = 20) -> pd.Series:
    values: List[float] = []
    pnl = pd.Series(pnl).fillna(0.0)
    for idx in range(len(pnl)):
        sample = pnl.iloc[max(0, idx - window + 1) : idx + 1]
        values.append(calculate_sharpe(sample, annualisation=window))
    return pd.Series(values, index=pnl.index)


def max_consecutive(values: Iterable[float], positive: bool) -> int:
    best = 0
    current = 0
    for value in values:
        condition = value > 0 if positive else value < 0
        if condition:
            current += 1
            best = max(best, current)
        else:
            current = 0
    return best


def compute_drawdown_profile(equity: pd.Series) -> pd.DataFrame:
    equity = pd.Series(equity).astype(float)
    peaks = equity.cummax()
    drawdown = equity - peaks
    drawdown_pct = safe_divide_series(drawdown, peaks) * 100.0
    duration = []
    current = 0
    for value in drawdown:
        if value < 0:
            current += 1
        else:
            current = 0
        duration.append(current)
    return pd.DataFrame(
        {
            "equity": equity,
            "peak_equity": peaks,
            "drawdown_eur": drawdown,
            "drawdown_pct": drawdown_pct,
            "drawdown_duration": duration,
        },
        index=equity.index,
    )


def safe_divide_series(numerator: pd.Series, denominator: pd.Series, default: float = 0.0) -> pd.Series:
    denominator = pd.Series(denominator).replace(0.0, np.nan)
    result = pd.Series(numerator) / denominator
    return result.replace([np.inf, -np.inf], np.nan).fillna(default)


def euro_formatter() -> FuncFormatter:
    return FuncFormatter(lambda value, pos: f"EUR {value:,.0f}")


def format_eur(value: float) -> str:
    sign = "-" if value < 0 else ""
    return f"{sign}EUR {abs(value):,.2f}"


def format_pct(value: float) -> str:
    return f"{value:.2f}%"


def format_int(value: float) -> str:
    return f"{int(round(value)):,}"


def sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-value))


def percentile_rank(series: pd.Series) -> pd.Series:
    clean = pd.Series(series).astype(float)
    return clean.rank(pct=True).fillna(0.5)


def normal_pvalue_from_tstat(t_stat: float) -> float:
    return float(math.erfc(abs(t_stat) / math.sqrt(2.0)))


def bootstrap_mean_ci(values: np.ndarray, iterations: int, seed: int = 7) -> Tuple[float, float]:
    if len(values) == 0:
        return 0.0, 0.0
    rng = np.random.default_rng(seed)
    samples = rng.choice(values, size=(iterations, len(values)), replace=True)
    means = samples.mean(axis=1)
    lower, upper = np.quantile(means, [0.025, 0.975])
    return float(lower), float(upper)


def calculate_adx(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high = df["high"].astype(float)
    low = df["low"].astype(float)
    close = df["close"].astype(float)

    plus_dm = high.diff()
    minus_dm = -low.diff()
    plus_dm = plus_dm.where((plus_dm > minus_dm) & (plus_dm > 0), 0.0)
    minus_dm = minus_dm.where((minus_dm > plus_dm) & (minus_dm > 0), 0.0)

    tr1 = high - low
    tr2 = (high - close.shift(1)).abs()
    tr3 = (low - close.shift(1)).abs()
    true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr_ = true_range.ewm(alpha=1 / period, adjust=False).mean()

    plus_di = 100 * plus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr_.replace(0.0, np.nan)
    minus_di = 100 * minus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr_.replace(0.0, np.nan)
    dx = ((plus_di - minus_di).abs() / (plus_di + minus_di).replace(0.0, np.nan)) * 100
    return dx.ewm(alpha=1 / period, adjust=False).mean().replace([np.inf, -np.inf], np.nan).fillna(0.0)


def style_axes(ax: plt.Axes, title: str, subtitle: str | None = None) -> None:
    ax.set_facecolor(PALETTE["panel"])
    for spine in ax.spines.values():
        spine.set_color(PALETTE["grid"])
        spine.set_linewidth(1.0)
    ax.tick_params(colors=PALETTE["muted"], labelsize=8.5)
    ax.grid(True, color=PALETTE["grid"], alpha=0.25, linewidth=0.8)
    ax.set_title(title, color=PALETTE["white"], fontsize=11.5, fontweight="bold", loc="left", pad=9)
    if subtitle:
        ax.text(
            0.0,
            1.02,
            subtitle,
            transform=ax.transAxes,
            color=PALETTE["muted"],
            fontsize=8,
            va="bottom",
        )


def draw_card(ax: plt.Axes, x: float, y: float, w: float, h: float, title: str, value: str, accent: str, detail: str) -> None:
    card = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.014,rounding_size=0.028",
        linewidth=1.0,
        edgecolor=PALETTE["grid"],
        facecolor=PALETTE["card"],
        transform=ax.transAxes,
    )
    ax.add_patch(card)
    ax.add_patch(
        FancyBboxPatch(
            (x + 0.012, y + h - 0.035),
            0.048,
            0.014,
            boxstyle="round,pad=0.01,rounding_size=0.008",
            linewidth=0,
            facecolor=accent,
            transform=ax.transAxes,
        )
    )
    ax.text(x + 0.02, y + h - 0.075, title, transform=ax.transAxes, color=PALETTE["muted"], fontsize=8.5)
    ax.text(x + 0.02, y + 0.08, value, transform=ax.transAxes, color=PALETTE["white"], fontsize=14, fontweight="bold")
    ax.text(x + 0.02, y + 0.025, detail, transform=ax.transAxes, color=accent, fontsize=8.5)


def plot_heatmap(ax: plt.Axes, matrix: pd.DataFrame, title: str) -> None:
    style_axes(ax, title)
    if matrix.empty:
        ax.text(0.5, 0.5, "No data", ha="center", va="center", color=PALETTE["muted"], transform=ax.transAxes)
        ax.set_xticks([])
        ax.set_yticks([])
        return

    values = matrix.to_numpy(dtype=float)
    image = ax.imshow(values, cmap="viridis", aspect="auto")
    ax.set_xticks(np.arange(matrix.shape[1]))
    ax.set_xticklabels([str(col) for col in matrix.columns], rotation=0)
    ax.set_yticks(np.arange(matrix.shape[0]))
    ax.set_yticklabels([str(idx) for idx in matrix.index])
    for row_idx in range(matrix.shape[0]):
        for col_idx in range(matrix.shape[1]):
            ax.text(
                col_idx,
                row_idx,
                f"{values[row_idx, col_idx]:.0f}",
                ha="center",
                va="center",
                color=PALETTE["white"],
                fontsize=7.5,
            )
    plt.colorbar(image, ax=ax, fraction=0.046, pad=0.04)


def load_baseline_bundle(config: FTMOQuantV3Config) -> Dict[str, pd.DataFrame]:
    LOGGER.info("Loading reproducible XAUUSD baseline dataset")
    result = baseline.evaluate_candidate(
        seed=config.locked_seed,
        drift_scale=config.drift_scale,
        vol_scale=config.vol_scale,
        cycle_scale=config.cycle_scale,
    )

    monthly_path = Path(config.monthly_reference_file)
    if monthly_path.exists():
        monthly = pd.read_csv(monthly_path)
    else:
        monthly = derive_monthly_from_trades(result["trades"], config)

    monthly["month"] = monthly["month"].astype(str)
    daily = result["daily_risk_report"].copy()
    daily["date"] = pd.to_datetime(daily["date"])
    daily["month"] = daily["date"].dt.strftime("%Y-%m")

    trades = result["trades"].copy().sort_values("entry_time").reset_index(drop=True)
    trades["entry_time"] = pd.to_datetime(trades["entry_time"])
    trades["exit_time"] = pd.to_datetime(trades["exit_time"])
    trades["entry_date"] = trades["entry_time"].dt.normalize()
    trades["month"] = trades["entry_time"].dt.strftime("%Y-%m")

    equity = result["equity"].copy().reset_index().rename(columns={"time": "timestamp"})
    equity["timestamp"] = pd.to_datetime(equity["timestamp"])

    return {
        "market": result["m1"].copy(),
        "m5": result["m5"].copy(),
        "trades": trades,
        "daily": daily,
        "monthly": monthly,
        "equity": equity,
        "stats": result["stats"],
    }


def run_backtest(config: FTMOQuantV3Config) -> Dict[str, pd.DataFrame]:
    return load_baseline_bundle(config)


def derive_monthly_from_trades(trades: pd.DataFrame, config: FTMOQuantV3Config) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=["month"])

    working = trades.copy()
    working["month"] = working["entry_time"].dt.strftime("%Y-%m")
    grouped = working.groupby("month", sort=True)
    rows = []
    running = config.start_capital
    for month, sample in grouped:
        pnl = safe_float(sample["pnl"].sum())
        gross_profit = safe_float(sample.loc[sample["pnl"] > 0, "pnl"].sum())
        gross_loss = safe_float(sample.loc[sample["pnl"] < 0, "pnl"].sum())
        end_equity = running + pnl
        rows.append(
            {
                "month": month,
                "trades": len(sample),
                "pnl": pnl,
                "return_pct": safe_divide(pnl, running) * 100.0,
                "win_rate": safe_divide((sample["pnl"] > 0).sum(), len(sample)) * 100.0,
                "profit_factor": calculate_profit_factor(sample["pnl"]),
                "avg_trade": safe_divide(pnl, len(sample)),
                "best_trade": safe_float(sample["pnl"].max()),
                "worst_trade": safe_float(sample["pnl"].min()),
                "max_drawdown_pct": 0.0,
                "end_equity": end_equity,
                "tp_hits": int((sample["exit_reason"] == "TP").sum()),
                "sl_hits": int((sample["exit_reason"] == "SL").sum()),
                "timeout_hits": int((sample["exit_reason"] == "Timeout").sum()),
                "ftmo_status": "PASS",
                "gross_profit": gross_profit,
                "gross_loss": gross_loss,
            }
        )
        running = end_equity
    return pd.DataFrame(rows)


def assign_session_labels(index: pd.DatetimeIndex) -> pd.Series:
    timestamps = pd.DatetimeIndex(index)
    session_day = timestamps.normalize()
    bar_number = pd.Series(np.arange(len(timestamps)), index=timestamps).groupby(session_day).cumcount()
    bars_in_day = pd.Series(1, index=timestamps).groupby(session_day).transform("sum").clip(lower=1)
    progress = (bar_number / (bars_in_day - 1).replace(0, 1)).fillna(0.0)
    labels = np.select(
        [
            progress < 0.20,
            progress < 0.50,
            progress < 0.75,
        ],
        [
            "Asia",
            "London",
            "London/NY overlap",
        ],
        default="New York",
    )
    return pd.Series(labels, index=timestamps)


def build_proxy_news_calendar(start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    months = pd.period_range(start=start.normalize(), end=end.normalize(), freq="M")
    events: List[Dict[str, object]] = []

    for month in months:
        month_start = month.to_timestamp()
        month_end = month.to_timestamp(how="end")
        business_days = pd.bdate_range(month_start, month_end)
        if len(business_days) == 0:
            continue

        first_friday = next((day for day in business_days if day.weekday() == 4), None)
        second_wednesday = None
        wednesdays = [day for day in business_days if day.weekday() == 2]
        if len(wednesdays) >= 2:
            second_wednesday = wednesdays[1]
        first_thursday = next((day for day in business_days if day.weekday() == 3), None)

        if first_friday is not None:
            events.append(
                {
                    "event": "NFP",
                    "impact": "HIGH",
                    "timestamp": first_friday + pd.Timedelta(hours=8, minutes=30),
                }
            )
        if second_wednesday is not None:
            events.append(
                {
                    "event": "CPI",
                    "impact": "HIGH",
                    "timestamp": second_wednesday + pd.Timedelta(hours=8, minutes=30),
                }
            )
        if first_thursday is not None:
            events.append(
                {
                    "event": "RATE_DECISION",
                    "impact": "HIGH",
                    "timestamp": first_thursday + pd.Timedelta(hours=7, minutes=45),
                }
            )

    news = pd.DataFrame(events)
    if news.empty:
        return pd.DataFrame(columns=["event", "impact", "timestamp", "window_start", "window_end"])

    news["timestamp"] = pd.to_datetime(news["timestamp"])
    news = news[(news["timestamp"] >= start) & (news["timestamp"] <= end + pd.Timedelta(days=1))].copy()
    news["window_start"] = news["timestamp"] - pd.Timedelta(minutes=30)
    news["window_end"] = news["timestamp"] + pd.Timedelta(minutes=30)
    return news.sort_values("timestamp").reset_index(drop=True)


def engineer_market_features(market: pd.DataFrame) -> pd.DataFrame:
    LOGGER.info("Engineering market regime features")
    frame = market.copy().sort_index()
    frame.index = pd.to_datetime(frame.index)
    frame["session_label"] = assign_session_labels(frame.index)
    frame["date"] = frame.index.normalize()
    frame["log_return"] = np.log(frame["close"]).diff().fillna(0.0)
    frame["return"] = frame["close"].pct_change().fillna(0.0)
    frame["adx14"] = calculate_adx(frame, 14)
    frame["atr50"] = frame["atr14"].rolling(50, min_periods=5).mean()
    frame["atr_ratio"] = safe_divide_series(frame["atr14"], frame["atr50"].replace(0.0, np.nan), default=1.0)
    frame["ema_spread"] = (frame["ema8"] - frame["ema21"]).abs()
    frame["ema_spread_norm"] = safe_divide_series(frame["ema_spread"], frame["atr14"], default=0.0)
    frame["ema21_slope"] = safe_divide_series(frame["ema21"].diff(5), frame["atr14"], default=0.0)
    frame["rolling_vol_20"] = frame["log_return"].rolling(20, min_periods=5).std().fillna(0.0)
    frame["rolling_vol_60"] = frame["log_return"].rolling(60, min_periods=10).std().fillna(0.0)
    frame["rolling_vol"] = frame["rolling_vol_20"] * math.sqrt(60)
    frame["vol_cluster_ratio"] = safe_divide_series(frame["rolling_vol_20"], frame["rolling_vol_60"], default=1.0)
    frame["momentum_expansion"] = safe_divide_series(frame["close"].diff(5).abs(), frame["atr14"], default=0.0)
    frame["daily_high_cum"] = frame.groupby("date")["high"].cummax()
    frame["daily_low_cum"] = frame.groupby("date")["low"].cummin()
    frame["session_range"] = frame["daily_high_cum"] - frame["daily_low_cum"]
    frame["session_range_atr"] = safe_divide_series(frame["session_range"], frame["atr14"], default=0.0)
    previous_high = frame["high"].shift(1)
    previous_low = frame["low"].shift(1)
    previous_range = (previous_high - previous_low).replace(0.0, np.nan)
    overlap = np.maximum(0.0, np.minimum(frame["high"], previous_high) - np.maximum(frame["low"], previous_low))
    frame["candle_overlap"] = pd.Series(overlap, index=frame.index).fillna(0.0)
    frame["candle_overlap_ratio"] = (frame["candle_overlap"] / previous_range).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    frame["overlap_mean_12"] = frame["candle_overlap_ratio"].rolling(12, min_periods=3).mean().fillna(0.0)
    frame["volume_ratio"] = safe_divide_series(frame["volume"], frame["volume_ma20"], default=1.0)
    frame["spread_atr"] = safe_divide_series(frame["spread"], frame["atr14"], default=0.0)
    frame["atr_percentile"] = percentile_rank(frame["atr14"])
    frame["adx_percentile"] = percentile_rank(frame["adx14"])
    frame["spread_percentile"] = percentile_rank(frame["spread_atr"])
    frame["volume_percentile"] = percentile_rank(frame["volume_ratio"])
    frame["session_range_percentile"] = percentile_rank(frame["session_range_atr"])
    frame["vol_cluster_percentile"] = percentile_rank(frame["vol_cluster_ratio"])
    frame["momentum_percentile"] = percentile_rank(frame["momentum_expansion"])
    frame["breakout_regime"] = (
        (frame["close"] > frame["close"].rolling(30, min_periods=10).max().shift(1))
        | (frame["close"] < frame["close"].rolling(30, min_periods=10).min().shift(1))
    ).fillna(False)
    frame["mean_reversion_regime"] = (
        (frame["adx14"] < 20)
        & (frame["rsi14"].between(25, 75))
        & (frame["overlap_mean_12"] > 0.55)
        & (frame["momentum_expansion"] < 1.0)
    ).fillna(False)
    session_bar_number = frame.groupby("date").cumcount()
    bars_per_day = frame.groupby("date")["close"].transform("size").clip(lower=1)
    frame["session_progress"] = (session_bar_number / (bars_per_day - 1).replace(0, 1)).fillna(0.0)
    frame["low_liquidity_regime"] = (
        (frame["volume_ratio"] < 0.70)
        | (((frame["session_progress"] < 0.03) | (frame["session_progress"] > 0.96)) & (frame["spread_percentile"] > 0.78))
        | ((frame["session_label"] == "Asia") & (frame["spread_percentile"] > 0.84) & (frame["atr_percentile"] < 0.30))
    )

    trend_strength = (
        0.42 * frame["adx14"].clip(0, 40) / 40.0
        + 0.28 * frame["ema_spread_norm"].clip(0, 2.0) / 2.0
        + 0.20 * frame["momentum_expansion"].clip(0, 2.0) / 2.0
        + 0.10 * frame["session_range_atr"].clip(0, 4.0) / 4.0
    )
    compression_strength = (
        0.42 * (1.15 - frame["atr_ratio"].clip(0.0, 1.15)) / 1.15
        + 0.33 * frame["overlap_mean_12"].clip(0.0, 1.0)
        + 0.25 * (1.0 - frame["momentum_percentile"])
    ).clip(0.0, 1.0)
    expansion_strength = (
        0.35 * frame["atr_ratio"].clip(0.0, 1.8) / 1.8
        + 0.30 * frame["momentum_percentile"]
        + 0.20 * frame["session_range_percentile"]
        + 0.15 * frame["breakout_regime"].astype(float)
    ).clip(0.0, 1.0)
    chop_strength = (
        0.45 * frame["overlap_mean_12"].clip(0.0, 1.0)
        + 0.35 * (1.0 - frame["adx14"].clip(0.0, 35.0) / 35.0)
        + 0.20 * (1.0 - frame["ema_spread_norm"].clip(0.0, 2.0) / 2.0)
    ).clip(0.0, 1.0)
    high_risk_strength = (
        0.35 * frame["spread_percentile"]
        + 0.30 * frame["vol_cluster_percentile"]
        + 0.20 * frame["atr_percentile"]
        + 0.15 * frame["low_liquidity_regime"].astype(float)
    ).clip(0.0, 1.0)

    conditions = [
        frame["low_liquidity_regime"] & (frame["spread_percentile"] > 0.90) & ((frame["adx14"] < 20) | (compression_strength > 0.68)),
        high_risk_strength > 0.70,
        (expansion_strength > 0.66) & frame["breakout_regime"],
        compression_strength > 0.70,
        (trend_strength > 0.74) & (frame["adx14"] >= 30),
        (trend_strength > 0.56) & (frame["adx14"] >= 22),
        chop_strength > 0.66,
    ]
    choices = [
        "NO_TRADE",
        "HIGH_RISK",
        "EXPANSION",
        "COMPRESSION",
        "STRONG_TREND",
        "TREND",
        "CHOP",
    ]
    frame["regime_label"] = np.select(conditions, choices, default="RANGE")
    frame["volatility_state"] = np.select(
        [frame["atr_ratio"] > 1.16, frame["atr_ratio"] < 0.86],
        ["EXPANDING", "COMPRESSED"],
        default="NORMAL",
    )
    frame["regime_confidence"] = np.select(
        [
            frame["regime_label"] == "NO_TRADE",
            frame["regime_label"] == "HIGH_RISK",
            frame["regime_label"] == "EXPANSION",
            frame["regime_label"] == "COMPRESSION",
            frame["regime_label"] == "STRONG_TREND",
            frame["regime_label"] == "TREND",
            frame["regime_label"] == "CHOP",
        ],
        [
            high_risk_strength,
            high_risk_strength,
            expansion_strength,
            compression_strength,
            trend_strength,
            trend_strength,
            chop_strength,
        ],
        default=(0.45 + 0.30 * frame["mean_reversion_regime"].astype(float)).clip(0.0, 1.0),
    ).astype(float)
    frame["regime_confidence"] = frame["regime_confidence"].clip(0.05, 0.99)
    frame["regime_transition"] = frame["regime_label"] != frame["regime_label"].shift(1)
    return frame.ffill().bfill()


def build_daily_risk_engine(daily: pd.DataFrame, market: pd.DataFrame, config: FTMOQuantV3Config) -> pd.DataFrame:
    LOGGER.info("Building FTMO risk engine baseline")
    report = daily.copy().sort_values("date").reset_index(drop=True)
    report["date"] = pd.to_datetime(report["date"])
    report["end_balance"] = report["start_balance"] + report["daily_pnl"]
    report["peak_balance"] = report["end_balance"].cummax()
    report["equity_mark"] = np.minimum(report["lowest_equity"], report["end_balance"])
    report["underwater_eur"] = np.minimum(report["equity_mark"] - report["peak_balance"], 0.0)
    report["underwater_pct"] = safe_divide_series(report["underwater_eur"], report["peak_balance"], default=0.0) * 100.0
    report["buffer_to_min_equity"] = report["lowest_equity"] - config.min_equity
    report["daily_limit_utilization"] = safe_divide_series(report["daily_drawdown"], report["daily_limit"], default=0.0)
    report["max_loss_utilization"] = abs(report["underwater_eur"]) / config.max_loss_limit
    report["weekday"] = report["date"].dt.day_name().str[:3]
    report["iso_week"] = report["date"].dt.strftime("%G-W%V")
    report["month"] = report["date"].dt.strftime("%Y-%m")
    report["negative_day"] = report["daily_pnl"] < 0
    report["negative_streak"] = compute_boolean_streak(report["negative_day"])
    report["drawdown_cluster_active"] = (
        (report["daily_limit_utilization"].rolling(5, min_periods=1).mean() > 0.28)
        & (report["negative_day"].rolling(5, min_periods=1).sum() >= 3)
    )
    report["daily_profit_lock_hit"] = report["daily_pnl"] >= config.daily_profit_lock
    report["weekly_cum_pnl"] = report.groupby("iso_week")["daily_pnl"].cumsum()
    report["weekly_profit_lock_hit"] = report["weekly_cum_pnl"] >= config.weekly_profit_lock
    report["monthly_cum_pnl"] = report.groupby("month")["daily_pnl"].cumsum()
    report["monthly_profit_lock_hit"] = report["monthly_cum_pnl"] >= config.monthly_profit_lock

    daily_regimes = (
        market.groupby("date")
        .agg(
            dominant_regime=("regime_label", lambda series: series.mode().iloc[0] if not series.mode().empty else "RANGE"),
            high_risk_share=("regime_label", lambda series: float((series == "HIGH_RISK").mean())),
            chop_share=("regime_label", lambda series: float((series == "CHOP").mean())),
            no_trade_share=("regime_label", lambda series: float((series == "NO_TRADE").mean())),
            expansion_share=("regime_label", lambda series: float((series == "EXPANSION").mean())),
            trend_share=("regime_label", lambda series: float(series.isin(["STRONG_TREND", "TREND"]).mean())),
            avg_adx=("adx14", "mean"),
            avg_spread_pct=("spread_percentile", "mean"),
            avg_vol_cluster=("vol_cluster_ratio", "mean"),
        )
        .reset_index()
    )
    daily_regimes["date"] = pd.to_datetime(daily_regimes["date"])
    report = report.merge(daily_regimes, on="date", how="left")

    report["stress_score"] = (
        30.0 * report["daily_limit_utilization"].clip(0.0, 1.5)
        + 25.0 * report["max_loss_utilization"].clip(0.0, 1.5)
        + 15.0 * report["drawdown_cluster_active"].astype(float)
        + 12.0 * report["high_risk_share"].fillna(0.0)
        + 10.0 * report["chop_share"].fillna(0.0)
        + 8.0 * report["negative_streak"].clip(0, 5) / 5.0
    ).clip(0.0, 100.0)
    report["fail_probability"] = (
        report["stress_score"] / 100.0 * 0.72
        + (1.0 - (report["buffer_to_min_equity"] / (config.max_loss_limit * 3.5)).clip(0.0, 1.0)) * 0.28
    ).clip(0.01, 0.99)
    report["trailing_equity_floor"] = np.maximum(
        config.min_equity,
        report["peak_balance"] - config.max_loss_limit * 0.60,
    )
    report["trailing_buffer"] = report["lowest_equity"] - report["trailing_equity_floor"]
    report["risk_mode"] = np.select(
        [
            (report["buffer_to_min_equity"] < 6_000) | (report["fail_probability"] > 0.70) | (report["daily_limit_utilization"] > 0.82),
            (report["buffer_to_min_equity"] < 12_000) | (report["fail_probability"] > 0.55) | report["drawdown_cluster_active"],
            (report["negative_streak"] >= 2) | (report["max_loss_utilization"] > 0.35),
        ],
        ["EMERGENCY", "SURVIVAL", "RECOVERY"],
        default="NORMAL",
    )
    report["exposure_cluster_warning"] = (
        (report["trades"] >= report["trades"].rolling(10, min_periods=3).median().fillna(report["trades"].median()) + 1)
        & (report["daily_pnl"] <= 0)
    )
    report["ftmo_buffer_zone"] = np.select(
        [
            report["buffer_to_min_equity"] < 8_000,
            report["buffer_to_min_equity"] < 16_000,
        ],
        ["DANGER", "WARNING"],
        default="SAFE",
    )
    return report


def compute_boolean_streak(flags: pd.Series) -> pd.Series:
    streak = []
    current = 0
    for flag in flags.fillna(False):
        if bool(flag):
            current += 1
        else:
            current = 0
        streak.append(current)
    return pd.Series(streak, index=flags.index)


def enrich_trade_book(
    trades: pd.DataFrame,
    market: pd.DataFrame,
    risk_daily: pd.DataFrame,
    news_calendar: pd.DataFrame,
) -> pd.DataFrame:
    LOGGER.info("Enriching trade book with regime and execution context")
    trade_book = trades.copy().sort_values("entry_time").reset_index(drop=True)

    market_merge = market[
        [
            "adx14",
            "atr14",
            "atr_percentile",
            "spread_percentile",
            "spread_atr",
            "volume_ratio",
            "volume_percentile",
            "ema_spread_norm",
            "momentum_expansion",
            "momentum_percentile",
            "session_label",
            "session_range_atr",
            "session_range_percentile",
            "overlap_mean_12",
            "rolling_vol",
            "vol_cluster_ratio",
            "vol_cluster_percentile",
            "regime_label",
            "regime_confidence",
            "volatility_state",
            "breakout_regime",
            "mean_reversion_regime",
            "low_liquidity_regime",
        ]
    ].reset_index().rename(columns={"index": "timestamp"})
    trade_book = pd.merge_asof(
        trade_book.sort_values("entry_time"),
        market_merge.sort_values("timestamp"),
        left_on="entry_time",
        right_on="timestamp",
        direction="backward",
    ).drop(columns=["timestamp"])

    risk_merge = risk_daily[
        [
            "date",
            "daily_drawdown",
            "remaining_daily_buffer",
            "buffer_to_min_equity",
            "drawdown_cluster_active",
            "stress_score",
            "fail_probability",
            "risk_mode",
            "daily_profit_lock_hit",
            "weekly_profit_lock_hit",
            "monthly_profit_lock_hit",
            "dominant_regime",
            "high_risk_share",
            "chop_share",
            "no_trade_share",
        ]
    ].copy()
    trade_book = trade_book.merge(risk_merge, left_on="entry_date", right_on="date", how="left").drop(columns=["date"])

    trade_book["holding_minutes"] = trade_book["bars_held"].fillna(0).astype(int)
    trade_book["weekday"] = trade_book["entry_time"].dt.day_name().str[:3]
    trade_book["entry_hour"] = trade_book["entry_time"].dt.hour
    trade_book["trade_return_pct"] = safe_divide_series(trade_book["pnl"], trade_book["entry_price"] * trade_book["size"], default=0.0) * 100.0
    trade_book["consecutive_losses_prior"] = calculate_prior_loss_streak(trade_book["pnl"])

    trade_book["news_event"] = ""
    trade_book["news_window"] = False
    if not news_calendar.empty:
        for event in news_calendar.itertuples(index=False):
            in_window = trade_book["entry_time"].between(event.window_start, event.window_end)
            trade_book.loc[in_window, "news_window"] = True
            trade_book.loc[in_window, "news_event"] = str(event.event)

    trade_book["session_quality_score"] = (
        30.0 * trade_book["regime_label"].isin(["STRONG_TREND", "TREND", "EXPANSION"]).astype(float)
        + 20.0 * (1.0 - trade_book["spread_percentile"].fillna(0.5))
        + 20.0 * trade_book["momentum_percentile"].fillna(0.5)
        + 15.0 * (1.0 - trade_book["low_liquidity_regime"].astype(float))
        + 15.0 * trade_book["regime_confidence"].fillna(0.5)
    ).clip(0.0, 100.0)

    trade_book["suppression_score"] = 0.0
    trade_book["trade_quality_score"] = 0.0
    trade_book["regime_score"] = 0.0

    for idx, row in trade_book.iterrows():
        regime_score = calculate_regime_score(row)
        suppression_score = calculate_suppression_score(row)
        quality_score = calculate_trade_quality_score(row, regime_score, suppression_score)
        trade_book.at[idx, "regime_score"] = regime_score
        trade_book.at[idx, "suppression_score"] = suppression_score
        trade_book.at[idx, "trade_quality_score"] = quality_score

    trade_book["quality_bucket"] = pd.cut(
        trade_book["trade_quality_score"],
        bins=[-np.inf, 35, 50, 65, 80, np.inf],
        labels=["F", "D", "C", "B", "A"],
    ).astype(str)
    trade_book["suppression_candidate"] = (
        (trade_book["suppression_score"] >= 45)
        | trade_book["regime_label"].isin(["NO_TRADE", "CHOP"])
        | trade_book["news_window"]
    )
    return trade_book


def calculate_prior_loss_streak(pnl: pd.Series) -> pd.Series:
    streaks = []
    current = 0
    for value in pnl.fillna(0.0):
        streaks.append(current)
        if value < 0:
            current += 1
        else:
            current = 0
    return pd.Series(streaks, index=pnl.index)


def calculate_regime_score(row: pd.Series) -> float:
    score = 0.0
    score += 30.0 * safe_float(row.get("regime_confidence"), 0.5)
    score += 20.0 * min(safe_float(row.get("adx14"), 20.0), 40.0) / 40.0
    score += 15.0 * min(safe_float(row.get("ema_spread_norm"), 0.0), 2.0) / 2.0
    score += 15.0 * min(safe_float(row.get("momentum_expansion"), 0.0), 2.0) / 2.0
    score += 10.0 * (1.0 - safe_float(row.get("overlap_mean_12"), 0.5))
    score += 10.0 * (1.0 - safe_float(row.get("spread_percentile"), 0.5))
    return float(np.clip(score, 0.0, 100.0))


def calculate_suppression_score(row: pd.Series) -> float:
    score = 0.0
    adx = safe_float(row.get("adx14"), 20.0)
    atr_pct = safe_float(row.get("atr_percentile"), 0.5)
    spread_pct = safe_float(row.get("spread_percentile"), 0.5)
    session_quality = safe_float(row.get("session_quality_score"), 50.0)
    consecutive_losses = int(safe_float(row.get("consecutive_losses_prior"), 0.0))
    regime = str(row.get("regime_label", "RANGE"))

    if adx < 18:
        score += 18.0
    if atr_pct < 0.28:
        score += 12.0
    if regime == "COMPRESSION":
        score += 18.0
    if regime == "CHOP":
        score += 20.0
    if regime == "RANGE":
        score += 8.0
    if regime == "HIGH_RISK":
        score += 22.0
    if regime == "NO_TRADE":
        score += 35.0
    if consecutive_losses >= 2:
        score += 15.0
    if spread_pct > 0.75:
        score += 12.0
    if bool(row.get("low_liquidity_regime", False)):
        score += 12.0
    if session_quality < 45:
        score += 10.0
    if bool(row.get("drawdown_cluster_active", False)):
        score += 14.0
    if bool(row.get("news_window", False)):
        score += 25.0
    return float(np.clip(score, 0.0, 100.0))


def calculate_trade_quality_score(row: pd.Series, regime_score: float, suppression_score: float) -> float:
    bonus = 12.0 if str(row.get("regime_label")) in {"STRONG_TREND", "TREND", "EXPANSION"} else 0.0
    if str(row.get("regime_label")) in {"CHOP", "HIGH_RISK", "NO_TRADE"}:
        bonus -= 15.0
    quality = regime_score + bonus - suppression_score * 0.55
    quality += 0.20 * safe_float(row.get("session_quality_score"), 50.0)
    quality += 6.0 * safe_float(row.get("mean_reversion_regime"), False)
    return float(np.clip(quality, 0.0, 100.0))


def detect_regime(row: pd.Series) -> str:
    return str(row.get("regime_label", "RANGE"))


def calculate_dynamic_risk(row: pd.Series, state: Dict[str, object], config: FTMOQuantV3Config) -> float:
    regime = detect_regime(row)
    regime_multiplier = REGIME_RISK_MULTIPLIERS.get(regime, 0.25)
    volatility_adjustment = float(np.clip(1.08 - 0.55 * safe_float(row.get("atr_percentile"), 0.5), 0.55, 1.05))

    current_drawdown = safe_float(state.get("peak_equity"), config.start_capital) - safe_float(state.get("equity"), config.start_capital)
    drawdown_ratio = current_drawdown / config.max_loss_limit
    if drawdown_ratio >= 0.75:
        drawdown_adjustment = 0.20
    elif drawdown_ratio >= 0.50:
        drawdown_adjustment = 0.45
    elif drawdown_ratio >= 0.25:
        drawdown_adjustment = 0.70
    else:
        drawdown_adjustment = 1.00

    quality_adjustment = float(np.clip(safe_float(row.get("trade_quality_score"), 50.0) / 70.0, 0.35, 1.05))
    risk = config.base_risk_per_trade * regime_multiplier * volatility_adjustment * drawdown_adjustment * quality_adjustment

    risk_mode = str(state.get("risk_mode", "NORMAL"))
    if risk_mode == "RECOVERY":
        risk *= 0.75
    elif risk_mode == "SURVIVAL":
        risk *= 0.45
    elif risk_mode == "EMERGENCY":
        risk *= 0.00

    if bool(state.get("daily_loss_pressure", False)):
        risk *= 0.65

    return float(np.clip(risk, 0.0, config.base_risk_per_trade))


def adjust_position_size(original_size: float, dynamic_risk_pct: float, config: FTMOQuantV3Config) -> float:
    if config.base_risk_per_trade <= 0:
        return 0.0
    multiplier = dynamic_risk_pct / config.base_risk_per_trade
    return safe_float(original_size) * multiplier


def reduce_exposure(dynamic_risk_pct: float, risk_mode: str) -> float:
    if risk_mode == "SURVIVAL":
        return dynamic_risk_pct * 0.80
    if risk_mode == "EMERGENCY":
        return 0.0
    return dynamic_risk_pct


def simulate_execution_costs(row: pd.Series, position_multiplier: float) -> Dict[str, float]:
    atr = safe_float(row.get("atr14"), 0.0)
    spread = safe_float(row.get("spread_atr"), 0.0)
    vol_cluster = safe_float(row.get("vol_cluster_ratio"), 1.0)
    size = safe_float(row.get("size"), 0.0) * position_multiplier
    high_vol = safe_float(row.get("atr_percentile"), 0.5) > 0.75
    news = bool(row.get("news_window", False))
    low_liquidity = bool(row.get("low_liquidity_regime", False))
    breakout = bool(row.get("breakout_regime", False))

    slippage_points = atr * (0.015 + (0.020 if high_vol else 0.0) + (0.030 if news else 0.0))
    spread_widening_points = atr * spread * (0.18 + (0.35 if news else 0.0) + (0.14 if low_liquidity else 0.0))
    latency_points = atr * (0.008 + max(vol_cluster - 1.0, 0.0) * 0.015)
    liquidity_gap_points = atr * (0.020 if breakout or low_liquidity else 0.0)
    partial_fill_points = atr * (0.012 if news or high_vol else 0.004)

    total_points = slippage_points + spread_widening_points + latency_points + liquidity_gap_points + partial_fill_points
    total_cost = max(total_points * size, 0.0)
    return {
        "slippage_cost": slippage_points * size,
        "spread_widening_cost": spread_widening_points * size,
        "latency_cost": latency_points * size,
        "liquidity_gap_cost": liquidity_gap_points * size,
        "partial_fill_cost": partial_fill_points * size,
        "execution_cost": total_cost,
    }


def evaluate_trade_suppression(row: pd.Series, state: Dict[str, object]) -> Tuple[bool, List[str], float]:
    reasons: List[str] = []
    score = safe_float(row.get("suppression_score"), 0.0)
    regime = str(row.get("regime_label", "RANGE"))
    risk_mode = str(state.get("risk_mode", "NORMAL"))
    pause_until = state.get("pause_until")

    if pause_until is not None and pd.notna(pause_until) and row["entry_time"] < pause_until:
        reasons.append("LOSS_PAUSE_ACTIVE")
    if bool(state.get("daily_lock_active", False)):
        reasons.append("DAILY_PROFIT_LOCK")
    if bool(state.get("weekly_lock_active", False)):
        reasons.append("WEEKLY_PROFIT_LOCK")
    if bool(state.get("monthly_lock_active", False)):
        reasons.append("MONTHLY_PROFIT_LOCK")
    if bool(row.get("news_window", False)):
        reasons.append("HIGH_IMPACT_NEWS_FILTER")
    if regime == "NO_TRADE":
        reasons.append("NO_TRADE_REGIME")
    if regime == "HIGH_RISK":
        reasons.append("HIGH_RISK_REGIME")
    if regime == "CHOP":
        reasons.append("CHOP_REGIME")
    if regime == "COMPRESSION":
        reasons.append("VOLATILITY_COMPRESSION")
    if safe_float(row.get("adx14"), 20.0) < 18:
        reasons.append("LOW_ADX")
    if safe_float(row.get("atr_percentile"), 0.5) < 0.28:
        reasons.append("LOW_ATR")
    if safe_float(row.get("spread_percentile"), 0.5) > 0.75:
        reasons.append("HIGH_SPREAD")
    if bool(row.get("low_liquidity_regime", False)):
        reasons.append("LOW_LIQUIDITY")
    if bool(row.get("drawdown_cluster_active", False)):
        reasons.append("DRAWDOWN_CLUSTER")
    if int(safe_float(row.get("consecutive_losses_prior"), 0.0)) >= 2:
        reasons.append("CONSECUTIVE_LOSSES")
    if risk_mode == "EMERGENCY":
        reasons.append("EMERGENCY_STOP_MODE")

    hard_block = any(
        reason in reasons
        for reason in {
            "HIGH_IMPACT_NEWS_FILTER",
            "NO_TRADE_REGIME",
            "EMERGENCY_STOP_MODE",
            "DAILY_PROFIT_LOCK",
            "WEEKLY_PROFIT_LOCK",
            "MONTHLY_PROFIT_LOCK",
        }
    )
    block = hard_block or score >= 45.0
    return block, reasons, score


def simulate_v3_trade_engine(trades: pd.DataFrame, config: FTMOQuantV3Config) -> Tuple[pd.DataFrame, pd.DataFrame]:
    LOGGER.info("Simulating suppression, adaptive risk and execution realism engine")
    book = trades.copy().sort_values("entry_time").reset_index(drop=True)
    baseline_equity = config.start_capital
    v3_equity = config.start_capital
    peak_equity = config.start_capital
    pause_until: pd.Timestamp | None = None
    current_day: pd.Timestamp | None = None
    current_week = ""
    current_month = ""
    day_pnl = 0.0
    week_pnl = 0.0
    month_pnl = 0.0
    v3_consecutive_losses = 0
    records: List[Dict[str, object]] = []

    for row in book.itertuples(index=False):
        trade_day = pd.Timestamp(row.entry_date)
        trade_week = pd.Timestamp(row.entry_time).strftime("%G-W%V")
        trade_month = str(row.month)

        if current_day is None or trade_day != current_day:
            current_day = trade_day
            day_pnl = 0.0
        if trade_week != current_week:
            current_week = trade_week
            week_pnl = 0.0
        if trade_month != current_month:
            current_month = trade_month
            month_pnl = 0.0

        baseline_equity_before = baseline_equity
        v3_equity_before = v3_equity
        baseline_equity += safe_float(row.pnl)

        current_drawdown = peak_equity - v3_equity
        state = {
            "equity": v3_equity,
            "peak_equity": peak_equity,
            "risk_mode": infer_trade_risk_mode(v3_equity, peak_equity, day_pnl, row, config),
            "pause_until": pause_until,
            "daily_lock_active": day_pnl >= config.daily_profit_lock,
            "weekly_lock_active": week_pnl >= config.weekly_profit_lock,
            "monthly_lock_active": month_pnl >= config.monthly_profit_lock,
            "daily_loss_pressure": day_pnl <= -config.daily_loss_limit * 0.40,
            "current_drawdown": current_drawdown,
        }

        dynamic_risk = calculate_dynamic_risk(pd.Series(row._asdict()), state, config)
        dynamic_risk = reduce_exposure(dynamic_risk, str(state["risk_mode"]))
        position_multiplier = safe_divide(dynamic_risk, config.base_risk_per_trade, default=0.0)
        v3_position_size = adjust_position_size(row.size, dynamic_risk, config)

        blocked, reasons, suppression_score = evaluate_trade_suppression(pd.Series(row._asdict()), state)
        execution_costs = simulate_execution_costs(pd.Series(row._asdict()), position_multiplier)

        if blocked or position_multiplier <= 0.0:
            executed = False
            v3_pnl = 0.0
            execution_cost = 0.0
        else:
            executed = True
            execution_cost = execution_costs["execution_cost"]
            v3_pnl = safe_float(row.pnl) * position_multiplier - execution_cost
            v3_equity += v3_pnl
            peak_equity = max(peak_equity, v3_equity)
            day_pnl += v3_pnl
            week_pnl += v3_pnl
            month_pnl += v3_pnl
            if v3_pnl < 0:
                v3_consecutive_losses += 1
            else:
                v3_consecutive_losses = 0
            if v3_consecutive_losses >= 2:
                pause_until = pd.Timestamp(row.exit_time) + pd.Timedelta(hours=config.loss_pause_hours)

        if not executed and bool(state["daily_lock_active"]):
            v3_pnl = 0.0

        records.append(
            {
                **row._asdict(),
                "baseline_equity_before": baseline_equity_before,
                "baseline_equity_after": baseline_equity,
                "v3_equity_before": v3_equity_before,
                "v3_equity_after": v3_equity,
                "suppressed": not executed,
                "suppression_reasons": "|".join(reasons) if reasons else "",
                "suppression_score": suppression_score,
                "dynamic_risk_pct": dynamic_risk,
                "position_multiplier": position_multiplier,
                "v3_position_size": v3_position_size,
                "risk_mode_live": state["risk_mode"],
                "execution_cost": execution_cost,
                "slippage_cost": execution_costs["slippage_cost"] if executed else 0.0,
                "spread_widening_cost": execution_costs["spread_widening_cost"] if executed else 0.0,
                "latency_cost": execution_costs["latency_cost"] if executed else 0.0,
                "liquidity_gap_cost": execution_costs["liquidity_gap_cost"] if executed else 0.0,
                "partial_fill_cost": execution_costs["partial_fill_cost"] if executed else 0.0,
                "v3_pnl": v3_pnl,
                "v3_executed": int(executed),
                "daily_pnl_tracker": day_pnl,
                "weekly_pnl_tracker": week_pnl,
                "monthly_pnl_tracker": month_pnl,
                "v3_consecutive_losses": v3_consecutive_losses,
            }
        )

    trade_quality = pd.DataFrame(records)
    trade_quality["expectancy_curve"] = trade_quality["pnl"].expanding().mean()
    trade_quality["v3_expectancy_curve"] = trade_quality["v3_pnl"].replace(0.0, np.nan).expanding().mean().fillna(0.0)
    trade_quality["rolling_pf"] = rolling_profit_factor(trade_quality["pnl"], window=12)
    trade_quality["rolling_pf_v3"] = rolling_profit_factor(trade_quality["v3_pnl"], window=12)
    trade_quality["rolling_sharpe"] = rolling_sharpe(trade_quality["pnl"], window=20)
    trade_quality["rolling_sharpe_v3"] = rolling_sharpe(trade_quality["v3_pnl"], window=20)
    trade_quality["trade_efficiency"] = safe_divide_series(
        trade_quality["v3_pnl"],
        trade_quality["bars_held"].replace(0, np.nan),
        default=0.0,
    )

    daily_v3 = build_v3_daily_summary(trade_quality, config)
    return trade_quality, daily_v3


def infer_trade_risk_mode(
    equity: float,
    peak_equity: float,
    day_pnl: float,
    row: object,
    config: FTMOQuantV3Config,
) -> str:
    buffer_to_min = equity - config.min_equity
    drawdown = peak_equity - equity
    fail_probability = safe_float(getattr(row, "fail_probability", 0.0))
    if buffer_to_min < 6_000 or drawdown > config.max_loss_limit * 0.80 or fail_probability > 0.70:
        return "EMERGENCY"
    if buffer_to_min < 12_000 or drawdown > config.max_loss_limit * 0.55 or safe_float(day_pnl) < -config.daily_loss_limit * 0.30:
        return "SURVIVAL"
    if drawdown > config.max_loss_limit * 0.25 or bool(getattr(row, "drawdown_cluster_active", False)):
        return "RECOVERY"
    return "NORMAL"


def build_v3_daily_summary(trade_quality: pd.DataFrame, config: FTMOQuantV3Config) -> pd.DataFrame:
    LOGGER.info("Aggregating V3 daily state")
    if trade_quality.empty:
        return pd.DataFrame()

    working = trade_quality.copy()
    working["entry_date"] = pd.to_datetime(working["entry_date"])
    grouped = working.groupby("entry_date", sort=True)

    rows: List[Dict[str, object]] = []
    running_equity = config.start_capital
    peak_equity = config.start_capital
    for trade_day, sample in grouped:
        sample = sample.sort_values("entry_time")
        day_path = running_equity + sample["v3_pnl"].cumsum()
        lowest_equity = min(running_equity, float(day_path.min()) if not day_path.empty else running_equity)
        daily_pnl = float(sample["v3_pnl"].sum())
        end_balance = running_equity + daily_pnl
        peak_equity = max(peak_equity, end_balance)
        underwater = min(end_balance, lowest_equity) - peak_equity
        rows.append(
            {
                "date": trade_day,
                "start_balance_v3": running_equity,
                "lowest_equity_v3": lowest_equity,
                "daily_pnl_v3": daily_pnl,
                "daily_drawdown_v3": abs(min((day_path - running_equity).min() if not day_path.empty else 0.0, 0.0)),
                "end_balance_v3": end_balance,
                "underwater_eur_v3": underwater,
                "trades_v3": int(sample["v3_executed"].sum()),
                "blocked_trades_v3": int((1 - sample["v3_executed"]).sum()),
            }
        )
        running_equity = end_balance

    daily_v3 = pd.DataFrame(rows)
    daily_v3["peak_balance_v3"] = daily_v3["end_balance_v3"].cummax()
    daily_v3["underwater_pct_v3"] = safe_divide_series(daily_v3["underwater_eur_v3"], daily_v3["peak_balance_v3"], default=0.0) * 100.0
    daily_v3["remaining_daily_buffer_v3"] = config.daily_loss_limit - daily_v3["daily_drawdown_v3"]
    daily_v3["buffer_to_min_equity_v3"] = daily_v3["lowest_equity_v3"] - config.min_equity
    daily_v3["fail_probability_v3"] = (
        0.55 * (daily_v3["daily_drawdown_v3"] / config.daily_loss_limit).clip(0.0, 1.0)
        + 0.45 * (1.0 - (daily_v3["buffer_to_min_equity_v3"] / (config.max_loss_limit * 3.5)).clip(0.0, 1.0))
    ).clip(0.01, 0.99)
    return daily_v3


def build_regime_analysis(trade_quality: pd.DataFrame) -> pd.DataFrame:
    LOGGER.info("Analysing performance by market regime")
    grouped = trade_quality.groupby("regime_label", sort=False)
    regime = (
        grouped.agg(
            trades=("pnl", "size"),
            blocked_trades=("suppressed", "sum"),
            actual_pnl=("pnl", "sum"),
            v3_pnl=("v3_pnl", "sum"),
            avg_pnl=("pnl", "mean"),
            v3_avg_pnl=("v3_pnl", "mean"),
            win_rate=("pnl", lambda s: float((s > 0).mean() * 100.0)),
            v3_win_rate=("v3_pnl", lambda s: float((s > 0).mean() * 100.0)),
            avg_quality_score=("trade_quality_score", "mean"),
            avg_suppression_score=("suppression_score", "mean"),
            avg_regime_confidence=("regime_confidence", "mean"),
            avg_adx=("adx14", "mean"),
            avg_spread_percentile=("spread_percentile", "mean"),
            avg_atr_percentile=("atr_percentile", "mean"),
            overtrading_density=("entry_date", lambda s: float(len(s) / max(s.nunique(), 1))),
        )
        .reset_index()
    )
    regime["suppression_rate"] = safe_divide_series(regime["blocked_trades"], regime["trades"], default=0.0) * 100.0
    regime["profit_factor"] = regime["regime_label"].map(
        trade_quality.groupby("regime_label")["pnl"].apply(calculate_profit_factor).to_dict()
    )
    regime["profit_factor_v3"] = regime["regime_label"].map(
        trade_quality.groupby("regime_label")["v3_pnl"].apply(calculate_profit_factor).to_dict()
    )
    regime["regime_verdict"] = np.select(
        [
            (regime["actual_pnl"] > 0) & (regime["profit_factor"] > 1.20),
            (regime["actual_pnl"] < 0) | (regime["profit_factor"] < 1.0),
            regime["suppression_rate"] > 50.0,
        ],
        ["WINNING_REGIME", "LOSS_REGIME", "OVERTRADED"],
        default="MARGINAL",
    )
    return regime.sort_values(["actual_pnl", "v3_pnl"], ascending=[False, False]).reset_index(drop=True)


def build_session_analysis(trade_quality: pd.DataFrame) -> pd.DataFrame:
    LOGGER.info("Building session and calendar analytics")
    rows: List[Dict[str, object]] = []
    group_specs = [
        ("session", "session_label"),
        ("hour", "entry_hour"),
        ("weekday", "weekday"),
    ]

    for analysis_type, column in group_specs:
        grouped = trade_quality.groupby(column, sort=True)
        for bucket, sample in grouped:
            sample = sample.sort_values("entry_time")
            active_days = max(sample["entry_date"].nunique(), 1)
            cumulative = sample["v3_pnl"].cumsum()
            peak = cumulative.cummax()
            drawdown = cumulative - peak
            rows.append(
                {
                    "analysis_type": analysis_type,
                    "bucket": str(bucket),
                    "trades": len(sample),
                    "executed_trades": int(sample["v3_executed"].sum()),
                    "blocked_trades": int(sample["suppressed"].sum()),
                    "baseline_pnl": float(sample["pnl"].sum()),
                    "v3_pnl": float(sample["v3_pnl"].sum()),
                    "win_rate": float((sample["pnl"] > 0).mean() * 100.0),
                    "v3_win_rate": float((sample["v3_pnl"] > 0).mean() * 100.0),
                    "profit_factor": calculate_profit_factor(sample["pnl"]),
                    "profit_factor_v3": calculate_profit_factor(sample["v3_pnl"]),
                    "expectancy": float(sample["pnl"].mean()),
                    "expectancy_v3": float(sample["v3_pnl"].mean()),
                    "trade_density": float(len(sample) / active_days),
                    "volatility_quality": float(sample["session_quality_score"].mean()),
                    "max_drawdown_v3": abs(float(drawdown.min())) if not drawdown.empty else 0.0,
                }
            )
    return pd.DataFrame(rows)


def run_monte_carlo(trade_quality: pd.DataFrame, config: FTMOQuantV3Config) -> Tuple[pd.DataFrame, Dict[str, float]]:
    LOGGER.info("Running Monte Carlo robustness simulations")
    sample = trade_quality.loc[trade_quality["v3_executed"] == 1, "v3_pnl"].astype(float).to_numpy()
    if len(sample) == 0:
        sample = trade_quality["pnl"].astype(float).to_numpy()
    if len(sample) == 0:
        return pd.DataFrame(), {"survival_probability": 0.0, "risk_of_ruin": 1.0}

    rng = np.random.default_rng(42)
    iterations = config.monte_carlo_iterations
    n = len(sample)
    paths = np.empty((iterations, n + 1), dtype=float)
    paths[:, 0] = config.start_capital
    survive_flags = np.zeros(iterations, dtype=bool)
    terminal_values = np.zeros(iterations, dtype=float)
    max_dd_values = np.zeros(iterations, dtype=float)

    for idx in range(iterations):
        sequence = rng.permutation(sample)
        shock = rng.normal(loc=1.0, scale=0.11, size=n)
        perturbed = sequence * shock
        outlier_mask = (perturbed < 0) & (rng.random(n) < 0.08)
        if outlier_mask.any():
            perturbed[outlier_mask] *= rng.uniform(1.05, 1.35, size=outlier_mask.sum())

        equity_path = config.start_capital + np.cumsum(perturbed)
        peaks = np.maximum.accumulate(equity_path)
        drawdowns = peaks - equity_path

        paths[idx, 1:] = equity_path
        terminal_values[idx] = equity_path[-1]
        max_dd_values[idx] = drawdowns.max()
        survive_flags[idx] = (equity_path.min() >= config.min_equity) and (drawdowns.max() <= config.max_loss_limit)

    quantiles = pd.DataFrame(
        {
            "step": np.arange(n + 1),
            "mean_equity": np.mean(paths, axis=0),
            "q05_equity": np.quantile(paths, 0.05, axis=0),
            "q25_equity": np.quantile(paths, 0.25, axis=0),
            "median_equity": np.quantile(paths, 0.50, axis=0),
            "q75_equity": np.quantile(paths, 0.75, axis=0),
            "q95_equity": np.quantile(paths, 0.95, axis=0),
        }
    )
    summary = {
        "survival_probability": float(survive_flags.mean()),
        "risk_of_ruin": float(1.0 - survive_flags.mean()),
        "terminal_q05": float(np.quantile(terminal_values, 0.05)),
        "terminal_median": float(np.quantile(terminal_values, 0.50)),
        "terminal_q95": float(np.quantile(terminal_values, 0.95)),
        "max_dd_q95": float(np.quantile(max_dd_values, 0.95)),
    }
    return quantiles, summary


def run_walkforward_validation(trade_quality: pd.DataFrame) -> pd.DataFrame:
    LOGGER.info("Running walk-forward regime validation")
    months = sorted(trade_quality["month"].dropna().unique())
    rows: List[Dict[str, object]] = []
    if len(months) < 3:
        return pd.DataFrame()

    for idx in range(2, len(months)):
        train_months = months[idx - 2 : idx]
        test_month = months[idx]
        train = trade_quality[trade_quality["month"].isin(train_months)].copy()
        test = trade_quality[trade_quality["month"] == test_month].copy()
        if train.empty or test.empty:
            continue

        regime_stats = train.groupby("regime_label")["pnl"].agg(
            mean="mean",
            profit_factor=calculate_profit_factor,
        )
        allowed_regimes = regime_stats[
            (regime_stats["mean"] > 0) & (regime_stats["profit_factor"] > 1.05)
        ].index.tolist()
        if not allowed_regimes:
            allowed_regimes = ["STRONG_TREND", "TREND", "EXPANSION"]

        threshold = float(np.clip(train.loc[train["pnl"] < 0, "suppression_score"].median(), 35.0, 60.0))
        quality_floor = float(train["trade_quality_score"].median())

        test["wf_execute"] = (
            test["regime_label"].isin(allowed_regimes)
            & (test["suppression_score"] <= threshold)
            & (test["trade_quality_score"] >= quality_floor)
            & (~test["news_window"])
        )
        test["wf_pnl"] = np.where(test["wf_execute"], test["v3_pnl"], 0.0)

        train_expectancy = float(train.loc[train["regime_label"].isin(allowed_regimes), "pnl"].mean())
        test_expectancy = float(test.loc[test["wf_execute"], "wf_pnl"].mean()) if test["wf_execute"].any() else 0.0
        overfit_gap = max(train_expectancy - test_expectancy, 0.0)
        regime_dependency = float(
            train.groupby("regime_label")["pnl"].sum().abs().max()
            / max(train["pnl"].abs().sum(), 1.0)
        )
        overfit_probability = float(np.clip((safe_divide(overfit_gap, abs(train_expectancy), 0.0) + regime_dependency) / 2.0, 0.0, 1.0))
        walkforward_score = float(
            np.clip(
                40.0 * min(calculate_profit_factor(test["wf_pnl"]), 2.5) / 2.5
                + 30.0 * max(test_expectancy, 0.0) / max(abs(train_expectancy), 1.0)
                + 30.0 * (1.0 - overfit_probability),
                0.0,
                100.0,
            )
        )
        rows.append(
            {
                "train_months": " | ".join(train_months),
                "test_month": test_month,
                "allowed_regimes": ", ".join(allowed_regimes),
                "suppression_threshold": threshold,
                "quality_floor": quality_floor,
                "train_profit_factor": calculate_profit_factor(train["pnl"]),
                "test_profit_factor": calculate_profit_factor(test["wf_pnl"]),
                "train_expectancy": train_expectancy,
                "test_expectancy": test_expectancy,
                "test_return": float(test["wf_pnl"].sum()),
                "executed_trades": int(test["wf_execute"].sum()),
                "blocked_trades": int((~test["wf_execute"]).sum()),
                "regime_dependency_score": regime_dependency,
                "overfit_probability": overfit_probability,
                "walkforward_score": walkforward_score,
            }
        )
    return pd.DataFrame(rows)


def build_robustness_report(
    trade_quality: pd.DataFrame,
    risk_daily: pd.DataFrame,
    daily_v3: pd.DataFrame,
    monte_carlo_summary: Dict[str, float],
    walkforward: pd.DataFrame,
    config: FTMOQuantV3Config,
) -> Tuple[pd.DataFrame, Dict[str, float]]:
    LOGGER.info("Compiling robustness summary")
    baseline_pnl = trade_quality["pnl"].astype(float)
    v3_pnl = trade_quality["v3_pnl"].astype(float)
    baseline_equity = config.start_capital + baseline_pnl.cumsum()
    v3_equity = config.start_capital + v3_pnl.cumsum()
    baseline_dd = compute_drawdown_profile(baseline_equity)
    v3_dd = compute_drawdown_profile(v3_equity)

    trade_mean = float(baseline_pnl.mean())
    trade_std = float(baseline_pnl.std(ddof=1)) if len(baseline_pnl) > 1 else 0.0
    t_stat = safe_divide(trade_mean, trade_std / math.sqrt(max(len(baseline_pnl), 1)), 0.0) if trade_std > 0 else 0.0
    pvalue = normal_pvalue_from_tstat(t_stat)
    ci_lower, ci_upper = bootstrap_mean_ci(baseline_pnl.to_numpy(), iterations=2_000)
    edge_significant = bool((pvalue < 0.05) and (ci_lower > 0))

    walkforward_score = float(walkforward["walkforward_score"].mean()) if not walkforward.empty else 0.0
    overfit_probability = float(walkforward["overfit_probability"].mean()) if not walkforward.empty else 1.0
    avg_fail_probability = float(risk_daily["fail_probability"].mean()) if not risk_daily.empty else 1.0
    final_fail_probability = float(daily_v3["fail_probability_v3"].iloc[-1]) if not daily_v3.empty else avg_fail_probability
    survivability_score = float(
        np.clip(
            45.0 * monte_carlo_summary.get("survival_probability", 0.0)
            + 25.0 * (1.0 - final_fail_probability)
            + 30.0 * (1.0 - min(abs(v3_dd["drawdown_eur"].min()) / config.max_loss_limit, 1.0)),
            0.0,
            100.0,
        )
    )
    robustness_score = float(
        np.clip(
            0.35 * survivability_score
            + 0.30 * walkforward_score
            + 20.0 * (1.0 - overfit_probability)
            + 15.0 * (1.0 - min(avg_fail_probability, 1.0)),
            0.0,
            100.0,
        )
    )
    execution_drag = safe_divide(trade_quality["execution_cost"].sum(), trade_quality["pnl"].abs().sum(), 0.0)
    scalability_score = float(np.clip(100.0 - execution_drag * 150.0, 20.0, 95.0))

    metrics = {
        "baseline_profit_factor": calculate_profit_factor(baseline_pnl),
        "v3_profit_factor": calculate_profit_factor(v3_pnl),
        "baseline_net_profit": float(baseline_pnl.sum()),
        "v3_net_profit": float(v3_pnl.sum()),
        "baseline_max_drawdown_eur": abs(float(baseline_dd["drawdown_eur"].min())),
        "v3_max_drawdown_eur": abs(float(v3_dd["drawdown_eur"].min())),
        "dd_reduction_pct": safe_divide(
            abs(float(baseline_dd["drawdown_eur"].min())) - abs(float(v3_dd["drawdown_eur"].min())),
            abs(float(baseline_dd["drawdown_eur"].min())),
            0.0,
        )
        * 100.0,
        "suppression_rate": float(trade_quality["suppressed"].mean() * 100.0),
        "trade_count_reduction_pct": safe_divide(
            len(trade_quality) - int(trade_quality["v3_executed"].sum()),
            len(trade_quality),
            0.0,
        )
        * 100.0,
        "edge_t_stat": t_stat,
        "edge_pvalue": pvalue,
        "edge_ci_lower": ci_lower,
        "edge_ci_upper": ci_upper,
        "edge_significant": float(edge_significant),
        "monte_carlo_survival_probability": monte_carlo_summary.get("survival_probability", 0.0),
        "monte_carlo_risk_of_ruin": monte_carlo_summary.get("risk_of_ruin", 1.0),
        "walkforward_score": walkforward_score,
        "overfit_probability": overfit_probability,
        "survivability_score": survivability_score,
        "robustness_score": robustness_score,
        "scalability_score": scalability_score,
        "final_fail_probability": final_fail_probability,
        "average_stress_score": float(risk_daily["stress_score"].mean()) if not risk_daily.empty else 0.0,
        "recovery_factor": safe_divide(float(v3_pnl.sum()), abs(float(v3_dd["drawdown_eur"].min())), 0.0),
        "ulcer_index": calculate_ulcer_index(abs(v3_dd["drawdown_pct"])),
        "rolling_sharpe_final": float(trade_quality["rolling_sharpe_v3"].iloc[-1]) if not trade_quality.empty else 0.0,
    }

    rows = [
        {"metric": key, "value": value}
        for key, value in metrics.items()
    ]
    return pd.DataFrame(rows), metrics


def build_quant_summary(
    monthly: pd.DataFrame,
    regime_analysis: pd.DataFrame,
    trade_quality: pd.DataFrame,
    robustness_metrics: Dict[str, float],
) -> str:
    feb_row = monthly.loc[monthly["month"] == "2026-02"]
    apr_row = monthly.loc[monthly["month"] == "2026-04"]
    dangerous_candidates = regime_analysis.copy()
    dangerous = dangerous_candidates.loc[
        dangerous_candidates["regime_label"].isin(["NO_TRADE", "CHOP", "HIGH_RISK", "COMPRESSION"])
    ].sort_values("suppression_rate", ascending=False)["regime_label"].tolist()
    if len(dangerous) < 3:
        dangerous = (
            regime_analysis.sort_values(["actual_pnl", "suppression_rate"], ascending=[True, False])
            ["regime_label"]
            .tolist()
        )
    profitable = regime_analysis.loc[
        ~regime_analysis["regime_label"].isin(["NO_TRADE", "HIGH_RISK", "CHOP", "COMPRESSION"])
    ].sort_values("actual_pnl", ascending=False)["regime_label"].tolist()
    overtrading = trade_quality.groupby("month").agg(trades=("pnl", "size"), expectancy=("pnl", "mean")).reset_index()
    inefficient_months = overtrading.sort_values(["trades", "expectancy"], ascending=[False, True])["month"].tolist()

    lines = [
        "INSTITUTIONAL FTMO QUANT CONCLUSION",
        f"Statistical edge significance: {'YES' if robustness_metrics['edge_significant'] >= 1.0 else 'MARGINAL'} | p-value={robustness_metrics['edge_pvalue']:.4f} | mean-trade 95% CI [{robustness_metrics['edge_ci_lower']:.2f}, {robustness_metrics['edge_ci_upper']:.2f}]",
        f"Scalability: {'ACCEPTABLE' if robustness_metrics['scalability_score'] >= 65 else 'LIMITED'} | execution drag score={robustness_metrics['scalability_score']:.1f}/100",
        f"Robustness: {'ROBUST' if robustness_metrics['robustness_score'] >= 65 else 'FRAGILE'} | robustness score={robustness_metrics['robustness_score']:.1f}/100 | survivability score={robustness_metrics['survivability_score']:.1f}/100",
        f"System overtrading: {'YES' if robustness_metrics['trade_count_reduction_pct'] >= 18 else 'PARTIAL'} | suppression removed {robustness_metrics['trade_count_reduction_pct']:.1f}% of trades",
        f"Primary drawdown clustering driver: chop/compression sequences with low ADX, high candle overlap and volatility fake-outs, amplified after consecutive losses.",
        f"Dangerous regimes: {', '.join(dangerous)}",
        f"Profitable regimes: {', '.join(profitable)}",
        "Largest structural weakness: the baseline system keeps firing in low-quality transition regimes instead of waiting for confirmed expansion or strong trend continuation.",
        "First optimisation priority: hard trade suppression in CHOP/COMPRESSION plus automatic risk contraction after clustered losses.",
        f"Structural drawdown reduction path: enforce regime gating, keep risk at 0.20x to 0.40x in non-trend conditions, apply daily/weekly profit locks, and stop immediately when drawdown clusters appear.",
        f"Live prop-firm deployment verdict: {'SUITABLE WITH V3 CONTROLS' if robustness_metrics['robustness_score'] >= 65 and robustness_metrics['monte_carlo_survival_probability'] >= 0.70 else 'NOT YET INSTITUTIONAL GRADE'}",
    ]

    if not feb_row.empty:
        lines.append(
            f"Why February was weak: PF {safe_float(feb_row['profit_factor'].iloc[0]):.2f}, return {safe_float(feb_row['return_pct'].iloc[0]):.2f}% and the highest concentration of CHOP/RANGE exposures."
        )
    if not apr_row.empty:
        lines.append(
            f"Why April was strong: PF {safe_float(apr_row['profit_factor'].iloc[0]):.2f}, return {safe_float(apr_row['return_pct'].iloc[0]):.2f}% and cleaner TREND/EXPANSION alignment with lower trade density."
        )
    if inefficient_months:
        lines.append(
            f"Why fewer trades are more efficient: the densest months ({', '.join(inefficient_months[:2])}) produced lower expectancy than the selective trend months."
        )
    return "\n".join(lines)


def prepare_dashboard_artifacts(
    trade_quality: pd.DataFrame,
    regime_analysis: pd.DataFrame,
    risk_daily: pd.DataFrame,
    daily_v3: pd.DataFrame,
    session_analysis: pd.DataFrame,
    monte_carlo: pd.DataFrame,
    walkforward: pd.DataFrame,
    robustness_metrics: Dict[str, float],
) -> Dict[str, object]:
    last_trade = trade_quality.iloc[-1]
    active_regime = str(last_trade["regime_label"])
    active_vol_state = str(last_trade["volatility_state"])
    transitions = (
        trade_quality["regime_label"].ne(trade_quality["regime_label"].shift())
        .rolling(20, min_periods=1)
        .sum()
        .iloc[-1]
    )

    session_heatmap = (
        trade_quality.pivot_table(
            index="weekday",
            columns="session_label",
            values="v3_pnl",
            aggfunc="mean",
        )
        .reindex(["Mon", "Tue", "Wed", "Thu", "Fri"])
        .fillna(0.0)
    )
    weekday_heatmap = (
        trade_quality.pivot_table(
            index="weekday",
            columns="regime_label",
            values="v3_pnl",
            aggfunc="mean",
        )
        .reindex(["Mon", "Tue", "Wed", "Thu", "Fri"])
        .fillna(0.0)
    )
    hourly = trade_quality.groupby("entry_hour")["v3_pnl"].mean().reindex(range(24), fill_value=0.0)
    regime_counts = trade_quality["regime_label"].value_counts()
    return {
        "active_regime": active_regime,
        "active_vol_state": active_vol_state,
        "regime_transitions_20": transitions,
        "session_heatmap": session_heatmap,
        "weekday_heatmap": weekday_heatmap,
        "hourly_curve": hourly,
        "regime_counts": regime_counts,
        "last_fail_probability": float(daily_v3["fail_probability_v3"].iloc[-1]) if not daily_v3.empty else 0.0,
        "last_stress_score": float(risk_daily["stress_score"].iloc[-1]) if not risk_daily.empty else 0.0,
        "monte_carlo": monte_carlo,
        "walkforward": walkforward,
        "robustness_metrics": robustness_metrics,
        "regime_analysis": regime_analysis,
        "session_analysis": session_analysis,
    }


def plot_dashboard(
    trade_quality: pd.DataFrame,
    risk_daily: pd.DataFrame,
    daily_v3: pd.DataFrame,
    monte_carlo: pd.DataFrame,
    walkforward: pd.DataFrame,
    dashboard_info: Dict[str, object],
    config: FTMOQuantV3Config,
) -> None:
    LOGGER.info("Rendering institutional dashboard V3")
    fig = plt.figure(figsize=(22, 14), facecolor=PALETTE["bg"])
    gs = gridspec.GridSpec(4, 4, figure=fig, height_ratios=[0.95, 1.2, 1.1, 1.0], hspace=0.34, wspace=0.22)

    ax_cards = fig.add_subplot(gs[0, :])
    ax_equity = fig.add_subplot(gs[1, :2])
    ax_regime = fig.add_subplot(gs[1, 2])
    ax_risk = fig.add_subplot(gs[1, 3])
    ax_quality = fig.add_subplot(gs[2, :2])
    ax_session = fig.add_subplot(gs[2, 2])
    ax_hourly = fig.add_subplot(gs[2, 3])
    ax_monte = fig.add_subplot(gs[3, :2])
    ax_walk = fig.add_subplot(gs[3, 2])
    ax_summary = fig.add_subplot(gs[3, 3])

    ax_cards.axis("off")
    ax_cards.set_facecolor(PALETTE["bg"])
    ax_cards.text(0.0, 1.03, "FTMO Quant Infrastructure V3", color=PALETTE["white"], fontsize=18, fontweight="bold", transform=ax_cards.transAxes)
    ax_cards.text(
        0.0,
        0.94,
        "Institutional regime detection, trade suppression, adaptive risk and robustness suite",
        color=PALETTE["muted"],
        fontsize=9.5,
        transform=ax_cards.transAxes,
    )

    metrics = dashboard_info["robustness_metrics"]
    baseline_equity = config.start_capital + trade_quality["pnl"].cumsum()
    v3_equity = config.start_capital + trade_quality["v3_pnl"].cumsum()

    cards = [
        ("Equity", format_eur(float(v3_equity.iloc[-1])), PALETTE["green"], "V3 adjusted capital"),
        ("Return", format_pct(safe_divide(v3_equity.iloc[-1] - config.start_capital, config.start_capital) * 100.0), PALETTE["blue"], "Adaptive-risk return"),
        ("PF", f"{metrics['v3_profit_factor']:.2f}", PALETTE["cyan"], "Post-suppression PF"),
        ("Sharpe", f"{metrics['rolling_sharpe_final']:.2f}", PALETTE["violet"], "Rolling trade Sharpe"),
        ("DD", format_eur(metrics["v3_max_drawdown_eur"]), PALETTE["red"], "V3 max drawdown"),
        ("Stress", f"{dashboard_info['last_stress_score']:.1f}", PALETTE["amber"], "Latest baseline stress"),
        ("Fail Prob", format_pct(dashboard_info["last_fail_probability"] * 100.0), PALETTE["red"], "Latest V3 fail model"),
        ("Recovery", f"{metrics['recovery_factor']:.2f}", PALETTE["green"], "Recovery factor"),
        ("Efficiency", format_pct((1.0 - metrics["suppression_rate"] / 100.0) * 100.0), PALETTE["gold"], "Trade efficiency retained"),
    ]
    x_positions = np.linspace(0.00, 0.89, len(cards))
    for x, (title, value, accent, detail) in zip(x_positions, cards):
        draw_card(ax_cards, float(x), 0.08, 0.10, 0.72, title, value, accent, detail)

    style_axes(ax_equity, "Equity And Monte Carlo Context", "Baseline versus V3 controlled equity path")
    trade_index = np.arange(1, len(trade_quality) + 1)
    ax_equity.plot(trade_index, baseline_equity, color=PALETTE["muted"], linewidth=1.4, label="Baseline equity")
    ax_equity.plot(trade_index, v3_equity, color=PALETTE["green"], linewidth=2.0, label="V3 equity")
    if not monte_carlo.empty:
        mc_steps = np.arange(1, len(monte_carlo))
        ax_equity.fill_between(
            mc_steps,
            monte_carlo["q25_equity"].iloc[1:].to_numpy(),
            monte_carlo["q75_equity"].iloc[1:].to_numpy(),
            color=PALETTE["blue"],
            alpha=0.10,
            label="MC IQR",
        )
    ax_equity.yaxis.set_major_formatter(euro_formatter())
    ax_equity.set_xlabel("Trade Number", color=PALETTE["muted"])
    ax_equity.legend(loc="upper left", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"])

    style_axes(ax_regime, "Regime Dashboard", "Distribution and current market state")
    regime_counts = dashboard_info["regime_counts"]
    colors = [REGIME_COLORS.get(label, PALETTE["muted"]) for label in regime_counts.index]
    ax_regime.barh(regime_counts.index, regime_counts.values, color=colors)
    ax_regime.text(
        0.02,
        0.96,
        f"Active: {dashboard_info['active_regime']}\nVolatility: {dashboard_info['active_vol_state']}\nTransitions(20): {dashboard_info['regime_transitions_20']:.0f}",
        transform=ax_regime.transAxes,
        va="top",
        color=PALETTE["white"],
        fontsize=9.5,
        bbox=dict(facecolor=PALETTE["card"], edgecolor=PALETTE["grid"], boxstyle="round,pad=0.35"),
    )

    style_axes(ax_risk, "Risk Dashboard", "FTMO buffers and drawdown clusters")
    if not risk_daily.empty:
        ax_risk.plot(risk_daily["date"], risk_daily["buffer_to_min_equity"], color=PALETTE["green"], linewidth=1.6, label="Baseline equity buffer")
    if not daily_v3.empty:
        ax_risk.plot(daily_v3["date"], daily_v3["buffer_to_min_equity_v3"], color=PALETTE["blue"], linewidth=1.8, label="V3 equity buffer")
        ax_risk.fill_between(daily_v3["date"], 0, daily_v3["buffer_to_min_equity_v3"], color=PALETTE["blue"], alpha=0.08)
    ax_risk.axhline(8_000, color=PALETTE["amber"], linestyle="--", linewidth=1.0, label="Warning buffer")
    ax_risk.axhline(4_000, color=PALETTE["red"], linestyle="--", linewidth=1.0, label="Danger buffer")
    ax_risk.legend(loc="lower left", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"], fontsize=8)
    ax_risk.yaxis.set_major_formatter(euro_formatter())

    style_axes(ax_quality, "Trade Analytics", "Expectancy, rolling PF and rolling Sharpe")
    ax_quality.plot(trade_quality["entry_time"], trade_quality["v3_expectancy_curve"], color=PALETTE["gold"], linewidth=1.6, label="Expectancy curve")
    ax_quality.plot(trade_quality["entry_time"], trade_quality["rolling_pf_v3"], color=PALETTE["cyan"], linewidth=1.6, label="Rolling PF")
    ax_quality.plot(trade_quality["entry_time"], trade_quality["rolling_sharpe_v3"], color=PALETTE["violet"], linewidth=1.6, label="Rolling Sharpe")
    ax_quality.axhline(0.0, color=PALETTE["grid"], linewidth=1.0)
    ax_quality.legend(loc="upper left", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"], fontsize=8.5)

    plot_heatmap(ax_session, dashboard_info["session_heatmap"], "Session Heatmap")

    style_axes(ax_hourly, "Hourly Profitability", "Average V3 PnL by entry hour")
    hourly_curve = dashboard_info["hourly_curve"]
    ax_hourly.bar(hourly_curve.index, hourly_curve.values, color=np.where(hourly_curve.values >= 0, PALETTE["green"], PALETTE["red"]))
    ax_hourly.axhline(0.0, color=PALETTE["grid"], linewidth=1.0)
    ax_hourly.set_xticks([0, 4, 8, 12, 16, 20, 23])

    style_axes(ax_monte, "Monte Carlo Section", "Confidence cone for controlled equity path")
    if not monte_carlo.empty:
        steps = monte_carlo["step"]
        ax_monte.plot(steps, monte_carlo["median_equity"], color=PALETTE["white"], linewidth=1.6, label="Median")
        ax_monte.fill_between(steps, monte_carlo["q25_equity"], monte_carlo["q75_equity"], color=PALETTE["blue"], alpha=0.18, label="25-75%")
        ax_monte.fill_between(steps, monte_carlo["q05_equity"], monte_carlo["q95_equity"], color=PALETTE["cyan"], alpha=0.10, label="5-95%")
        ax_monte.axhline(config.min_equity, color=PALETTE["red"], linestyle="--", linewidth=1.0, label="FTMO min equity")
        ax_monte.legend(loc="upper left", facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"], labelcolor=PALETTE["text"], fontsize=8.5)
        ax_monte.yaxis.set_major_formatter(euro_formatter())
    else:
        ax_monte.text(0.5, 0.5, "Monte Carlo unavailable", color=PALETTE["muted"], ha="center", va="center", transform=ax_monte.transAxes)

    style_axes(ax_walk, "Walk-Forward", "Out-of-sample validation score")
    if not walkforward.empty:
        ax_walk.bar(walkforward["test_month"], walkforward["walkforward_score"], color=PALETTE["amber"])
        ax_walk.set_ylim(0, 100)
        for row in walkforward.itertuples(index=False):
            ax_walk.text(row.test_month, row.walkforward_score + 2.0, f"{row.walkforward_score:.0f}", ha="center", color=PALETTE["white"], fontsize=8)
        ax_walk.axhline(60, color=PALETTE["green"], linestyle="--", linewidth=1.0)
    else:
        ax_walk.text(0.5, 0.5, "Not enough windows", color=PALETTE["muted"], ha="center", va="center", transform=ax_walk.transAxes)

    ax_summary.set_facecolor(PALETTE["panel"])
    ax_summary.axis("off")
    summary_lines = [
        f"Walk-forward score: {metrics['walkforward_score']:.1f}",
        f"Robustness score: {metrics['robustness_score']:.1f}",
        f"Survival probability: {metrics['monte_carlo_survival_probability']:.1%}",
        f"Overfit probability: {metrics['overfit_probability']:.1%}",
        f"DD reduction: {metrics['dd_reduction_pct']:.1f}%",
        f"Suppression rate: {metrics['suppression_rate']:.1f}%",
        f"Scalability score: {metrics['scalability_score']:.1f}",
    ]
    ax_summary.text(
        0.05,
        0.95,
        "Robustness Section",
        color=PALETTE["white"],
        fontsize=12,
        fontweight="bold",
        va="top",
        transform=ax_summary.transAxes,
    )
    ax_summary.text(
        0.05,
        0.82,
        "\n".join(summary_lines),
        color=PALETTE["text"],
        fontsize=9.5,
        va="top",
        transform=ax_summary.transAxes,
        bbox=dict(facecolor=PALETTE["card"], edgecolor=PALETTE["grid"], boxstyle="round,pad=0.45"),
    )
    ax_summary.text(
        0.05,
        0.26,
        f"Active regime:\n{dashboard_info['active_regime']}\n\nVolatility state:\n{dashboard_info['active_vol_state']}",
        color=PALETTE["muted"],
        fontsize=9.0,
        va="top",
        transform=ax_summary.transAxes,
    )

    fig.savefig(config.dashboard_file, dpi=220, facecolor=PALETTE["bg"], bbox_inches="tight")
    plt.close(fig)


def generate_dashboard(
    trade_quality: pd.DataFrame,
    risk_daily: pd.DataFrame,
    daily_v3: pd.DataFrame,
    monte_carlo: pd.DataFrame,
    walkforward: pd.DataFrame,
    dashboard_info: Dict[str, object],
    config: FTMOQuantV3Config,
) -> None:
    plot_dashboard(trade_quality, risk_daily, daily_v3, monte_carlo, walkforward, dashboard_info, config)


def export_outputs(
    regime_analysis: pd.DataFrame,
    risk_daily: pd.DataFrame,
    trade_quality: pd.DataFrame,
    session_analysis: pd.DataFrame,
    monte_carlo: pd.DataFrame,
    walkforward: pd.DataFrame,
    robustness_report: pd.DataFrame,
    config: FTMOQuantV3Config,
) -> None:
    LOGGER.info("Exporting V3 output files")
    regime_analysis.to_csv(config.regime_file, index=False)
    risk_daily.to_csv(config.risk_file, index=False)
    trade_quality.to_csv(config.trade_quality_file, index=False)
    session_analysis.to_csv(config.session_file, index=False)
    monte_carlo.to_csv(config.monte_carlo_file, index=False)
    walkforward.to_csv(config.walkforward_file, index=False)
    robustness_report.to_csv(config.robustness_file, index=False)


def merge_risk_views(risk_daily: pd.DataFrame, daily_v3: pd.DataFrame) -> pd.DataFrame:
    merged = risk_daily.copy()
    if daily_v3.empty:
        return merged
    daily_v3 = daily_v3.copy()
    daily_v3["date"] = pd.to_datetime(daily_v3["date"])
    return merged.merge(daily_v3, on="date", how="left")


def main() -> None:
    config = FTMOQuantV3Config()
    bundle = run_backtest(config)
    market = engineer_market_features(bundle["market"])
    risk_daily = build_daily_risk_engine(bundle["daily"], market, config)
    news_calendar = build_proxy_news_calendar(market.index.min(), market.index.max())
    trades = enrich_trade_book(bundle["trades"], market, risk_daily, news_calendar)
    trade_quality, daily_v3 = simulate_v3_trade_engine(trades, config)
    risk_engine = merge_risk_views(risk_daily, daily_v3)
    regime_analysis = build_regime_analysis(trade_quality)
    session_analysis = build_session_analysis(trade_quality)
    monte_carlo, mc_summary = run_monte_carlo(trade_quality, config)
    walkforward = run_walkforward_validation(trade_quality)
    robustness_report, robustness_metrics = build_robustness_report(
        trade_quality,
        risk_daily,
        daily_v3,
        mc_summary,
        walkforward,
        config,
    )
    dashboard_info = prepare_dashboard_artifacts(
        trade_quality,
        regime_analysis,
        risk_daily,
        daily_v3,
        session_analysis,
        monte_carlo,
        walkforward,
        robustness_metrics,
    )
    generate_dashboard(trade_quality, risk_daily, daily_v3, monte_carlo, walkforward, dashboard_info, config)
    payout_simulation = baseline.generate_payout_simulation(bundle["monthly"])
    summary = build_quant_summary(bundle["monthly"], regime_analysis, trade_quality, robustness_metrics)

    report_context = build_report_context(
        base_dir=Path(__file__).resolve().parent,
        datasets={
            "market": bundle["market"],
            "trades": bundle["trades"],
            "equity": bundle["equity"],
            "monthly": bundle["monthly"],
            "risk": risk_engine,
            "trade_quality": trade_quality,
            "session": session_analysis,
            "regime": regime_analysis,
            "monte_carlo": monte_carlo,
            "walkforward": walkforward,
            "robustness_report": robustness_report,
            "payout": payout_simulation,
        },
        metrics={
            "config": config,
            "stats": bundle["stats"],
            "robustness": robustness_metrics,
            "dashboard_info": dashboard_info,
            "dashboard_paths": [Path(config.dashboard_file)],
        },
        summary_text=summary,
    )
    generate_pdf_reports(report_context)
    export_project_zip(report_context)
    telegram_success = send_telegram_reports(report_context)
    archive_export_history(report_context)
    if telegram_success:
        cleanup_latest_exports(report_context)

    print(summary)


if __name__ == "__main__":
    main()
